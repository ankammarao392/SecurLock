# 🛡️ TrustVault — Your Documents. Your Control.

> **Production-Minded Enterprise Document Management, Access Control & Forensic Audit Platform**

TrustVault is engineered for organizations that share highly sensitive, confidential, and restricted documents with employees, clients, external partners, and auditors. It prioritizes **real-world application security** (IDOR/BOLA prevention, magic byte verification, instant permission revocation, tamper-resistant append-only audit logging, and strict least privilege) coupled with a distinctive **cybersecurity operations control center UI** (Midnight Navy `#080C16`, Electric Teal `#00F2FE`, and Cyber Cyan).

---

## 🌟 Key Features & Security Architecture

1. **Role-Based Access Control (RBAC)**:
   - **Administrator**: User identity provisioning, security audit monitoring, and retention enforcement. Cannot read or download confidential documents without explicit permission (Least Privilege).
   - **Document Owner**: Full control over deposited documents, metadata updates, category assignment, and collaborator permission delegation.
   - **Viewer**: Read-only (view & download) or Editor rights strictly limited to explicitly shared documents.
2. **Document-Level Permissions & Instant Revocation**:
   - Grant `read` or `edit` rights with optional expiration dates to registered users.
   - Immediate server-side revocation on the next request without relying on stale tokens.
3. **Cryptographic Upload & Storage Pipeline**:
   - Magic byte signature verification for PDF, DOCX, XLSX, PPTX, PNG, and JPEG (prevents extension spoofing).
   - 10 MB strict memory threshold.
   - SHA-256 fingerprinting calculated at upload.
   - Random UUID storage keys in private, non-static storage.
   - Zero public URLs; authenticated streaming download with `X-Content-Type-Options: nosniff`.
4. **Append-Only Audit Trail**:
   - Mongoose schema-level update and deletion prevention hooks.
   - Correlated request tracking (`X-Correlation-ID`).
   - Forensic Audit Explorer with search, outcome filters, timeline view, and CSV export.
5. **Automated Security Verification**:
   - Complete 17-scenario automated test suite verifying IDOR prevention, upload rejection, instant revocation, session invalidation on disabled users, and least privilege.

---

## 🚀 Quick Start Guide

### 1. Prerequisites
- **Node.js**: v18+ (tested on Node v24)
- **MongoDB Atlas** connection string (or local MongoDB)

### 2. Installation
Dependencies are already installed in this workspace. To install fresh in both directories:
```bash
# Server dependencies
cd server && npm install

# Client dependencies
cd ../client && npm install
```

### 3. Environment Configuration
Copy the provided `.env.example` in `server/.env.example` to `server/.env`:
```bash
cp server/.env.example server/.env
```
Edit `server/.env` and paste your MongoDB Atlas connection string:
```env
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb+srv://<username>:<password>@cluster0.abcde.mongodb.net/trustvault?retryWrites=true&w=majority
JWT_SECRET=super_secret_jwt_key_trustvault_secure_token_change_in_production
JWT_EXPIRES_IN=24h
COOKIE_NAME=trustvault_token
COOKIE_SECURE=false
CORS_ORIGIN=http://localhost:5173
```

### 4. Seed Realistic Demonstration Data
Populate realistic enterprise demo users and documents across Financial, Legal, Security, and Engineering categories:
```bash
cd server
npm run seed
```

Or provision an administrator account directly:
```bash
cd server
npm run seed:admin
```

### 5. Running the Application

In terminal 1 (Backend Server):
```bash
cd server
npm run dev
# Server starts at http://localhost:5000
```

In terminal 2 (Frontend Client):
```bash
cd client
npm run dev
# Client runs at http://localhost:5173
```

Open your browser to `http://localhost:5173`.

---

## 👥 Demo Accounts (One-Click Switcher Available in UI)

The frontend includes a **Demo Switcher** on the login page and sidebar to effortlessly test and verify role restrictions across all 3 roles:

| Role | Email | Password | Intended Capabilities |
| :--- | :--- | :--- | :--- |
| **Administrator** | `admin@trustvault.io` | `TrustVault@Admin2026!` | User management, global audit explorer, system KPIs. Cannot download unshared confidential docs. |
| **Document Owner** | `sarah.owner@trustvault.io` | `SarahOwner@2026!` | Owns Q3 Financial Audit & Phoenix Term Sheet. Manages permissions, uploads, and versions. |
| **Document Owner** | `marcus.sec@trustvault.io` | `MarcusSec@2026!` | Owns Zero-Trust Spec and Cyber Threat Assessment reports. |
| **Viewer / Auditor** | `alex.viewer@trustvault.io` | `AlexViewer@2026!` | Read access to Sarah's Financial Audit doc; Edit access to Zero-Trust Spec. |

---

## 🧪 Automated Security Tests

Run the Vitest security verification suite with isolated in-memory database:
```bash
cd server
npm test
```

### Verified Test Scenarios (17/17 Passing):
1. Unauthenticated requests to protected endpoints are rejected with `401 Unauthorized`.
2. User B cannot read User A's private document (`403 Forbidden`).
3. User B cannot download User A's private document (`403 Forbidden`).
4. User B cannot update or delete User A's document (`403 Forbidden`).
5. Viewer with read permission can read metadata and download the authorized document.
6. Viewer with read permission cannot modify or delete the document (`403 Forbidden`).
7. Editor with edit permission can edit metadata but cannot delete another owner's document (`403 Forbidden`).
8. Revoked users immediately lose read and download access on subsequent requests (`403 Forbidden`).
9. Expired permissions are automatically rejected (`403 Forbidden`).
10. Administrator can query audit records but cannot download confidential files (Least Privilege).
11. A user cannot grant themselves permissions to another user's document.
12. Non-owner cannot grant or modify permissions for other users.
13. Rejects invalid magic bytes, spoofed extensions, and oversized uploads (`400 Bad Request`).
14. Denied access attempts produce audit events with `outcome: "denied"`.
15. Schema-level hooks protect audit logs from updates or deletions (Append-Only).
16. Disabled users are immediately rejected even with an unexpired session token.
17. Search and pagination never disclose unauthorized document titles or counts.

---

## 🌐 Deploy to Render

TrustVault is pre-configured for 1-click or blueprint deployment to [Render](https://render.com).

### Option A: Render Blueprint (Recommended)
1. Fork or push this repository to your GitHub account (`https://github.com/dinesh34318/TrustValut`).
2. Log in to [Render](https://dashboard.render.com).
3. Click **New +** -> **Blueprint**.
4. Connect your `TrustValut` repository. Render will automatically detect [`render.yaml`](render.yaml).
5. In the configuration prompt, provide your `MONGODB_URI` (from MongoDB Atlas).
6. Click **Apply**. Render will automatically run `npm run build` and start the server with static frontend serving.

### Option B: Manual Web Service
1. In Render Dashboard, click **New +** -> **Web Service**.
2. Connect your `TrustValut` repository.
3. Configure the settings:
   - **Environment**: `Node`
   - **Build Command**: `npm run build`
   - **Start Command**: `npm run start`
4. Under **Environment Variables**, add:
   - `NODE_ENV` = `production`
   - `PORT` = `10000`
   - `MONGODB_URI` = `mongodb+srv://<username>:<password>@cluster0.ubcrkoo.mongodb.net/trustvault`
   - `JWT_SECRET` = *(generate a secure random 64-char string)*
   - `JWT_EXPIRES_IN` = `24h`
   - `COOKIE_NAME` = `trustvault_token`
   - `COOKIE_SECURE` = `true`
   - `UPLOAD_DIR` = `private-uploads`
   - `MAX_FILE_SIZE_BYTES` = `10485760`
5. Click **Deploy Web Service**.

---

## 📁 Repository Structure

```
trustvault/
├── client/                     # React 19 + TypeScript + Vite + Tailwind CSS
│   ├── src/
│   │   ├── components/         # BrandLogo, Sidebar, TopBar, DocumentTable, DocumentDrawer, UploadModal, AccessModal
│   │   ├── layouts/            # AuthLayout, DashboardLayout
│   │   ├── pages/              # Overview, MyVault, SharedWithMe, AccessManagement, AuditExplorer, Categories, Users, Settings, 403, 404
│   │   ├── context/            # AuthContext, ToastContext
│   │   ├── services/           # Axios API client
│   │   ├── types/              # TypeScript interfaces
│   │   └── index.css           # Midnight-navy & cyber scrollbars
│   └── package.json
├── server/                     # Node.js + Express + TypeScript + Mongoose
│   ├── src/
│   │   ├── config/             # Database connection, env parser
│   │   ├── controllers/        # Auth, Documents, Permissions, Audit, Admin
│   │   ├── middleware/         # Auth, Role guards, Error handling, Multer upload
│   │   ├── models/             # User, Document, DocumentPermission, AuditLog, DocumentVersion
│   │   ├── policies/           # Centralized authorization policies (Least Privilege)
│   │   ├── routes/             # REST API routers
│   │   ├── services/           # Audit service, File storage service
│   │   ├── utils/              # File signature (magic bytes) verification, SHA-256
│   │   └── validators/         # Zod request payload schemas
│   ├── tests/                  # 17 automated security test scenarios
│   ├── private-uploads/        # Non-static, authorization-gated file storage
│   └── package.json
└── docs/                       # Architecture, Threat Model, Permissions Matrix, API Docs
    ├── architecture.md
    ├── threat-model.md
    ├── permissions-matrix.md
    └── api-documentation.md
```

---

## 📜 License
TrustVault is proprietary enterprise document security software.
