import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import { ENV } from '../config/env';

export interface IFileStorageService {
  saveFile(storageKey: string, buffer: Buffer): Promise<string>;
  getFileStream(storageKey: string): fsSync.ReadStream;
  getFileBuffer(storageKey: string): Promise<Buffer>;
  deleteFile(storageKey: string): Promise<boolean>;
  fileExists(storageKey: string): Promise<boolean>;
}

export class LocalDiskStorageService implements IFileStorageService {
  private baseDir: string;

  constructor(baseDir?: string) {
    this.baseDir = baseDir || ENV.UPLOAD_DIR;
    this.ensureStorageDir();
  }

  private ensureStorageDir(): void {
    if (!fsSync.existsSync(this.baseDir)) {
      fsSync.mkdirSync(this.baseDir, { recursive: true, mode: 0o700 });
    }
  }

  private resolvePath(storageKey: string): string {
    // Prevent path traversal
    const safeKey = path.basename(storageKey);
    return path.join(this.baseDir, safeKey);
  }

  async saveFile(storageKey: string, buffer: Buffer): Promise<string> {
    const filePath = this.resolvePath(storageKey);
    await fs.writeFile(filePath, buffer, { mode: 0o600 });
    return filePath;
  }

  getFileStream(storageKey: string): fsSync.ReadStream {
    const filePath = this.resolvePath(storageKey);
    if (!fsSync.existsSync(filePath)) {
      throw new Error(`File with storage key '${storageKey}' not found in storage.`);
    }
    return fsSync.createReadStream(filePath);
  }

  async getFileBuffer(storageKey: string): Promise<Buffer> {
    const filePath = this.resolvePath(storageKey);
    return await fs.readFile(filePath);
  }

  async deleteFile(storageKey: string): Promise<boolean> {
    const filePath = this.resolvePath(storageKey);
    try {
      if (fsSync.existsSync(filePath)) {
        await fs.unlink(filePath);
        return true;
      }
      return false;
    } catch (err) {
      console.error(`Error deleting storage file ${storageKey}:`, err);
      return false;
    }
  }

  async fileExists(storageKey: string): Promise<boolean> {
    const filePath = this.resolvePath(storageKey);
    return fsSync.existsSync(filePath);
  }
}

export const fileStorageService = new LocalDiskStorageService();
