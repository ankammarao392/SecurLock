import { Types } from 'mongoose';
import { AuditLog, IAuditLog } from '../models/AuditLog';
import { AuditAction, AuditOutcome } from '../types';

export interface AuditEventParams {
  actorId?: string | Types.ObjectId | null;
  actorEmail?: string | null;
  actorRole?: string | null;
  action: AuditAction;
  documentId?: string | Types.ObjectId | null;
  targetUserId?: string | Types.ObjectId | null;
  outcome: AuditOutcome;
  correlationId?: string;
  ipAddress?: string;
  userAgent?: string;
  reason?: string;
  metadata?: Record<string, any>;
}

export class AuditService {
  /**
   * Records an immutable audit log entry
   */
  async record(params: AuditEventParams): Promise<IAuditLog> {
    try {
      // Sanitize metadata: strip any fields that could contain secrets
      const safeMetadata: Record<string, any> = { ...params.metadata };
      const disallowedKeys = ['password', 'token', 'secret', 'authorization', 'cookie', 'fileBuffer'];
      for (const key of Object.keys(safeMetadata)) {
        if (disallowedKeys.some((bad) => key.toLowerCase().includes(bad))) {
          safeMetadata[key] = '[REDACTED]';
        }
      }

      const log = new AuditLog({
        actorId: params.actorId ? new Types.ObjectId(params.actorId.toString()) : null,
        actorEmail: params.actorEmail || null,
        actorRole: params.actorRole || null,
        action: params.action,
        documentId: params.documentId ? new Types.ObjectId(params.documentId.toString()) : null,
        targetUserId: params.targetUserId ? new Types.ObjectId(params.targetUserId.toString()) : null,
        outcome: params.outcome,
        correlationId: params.correlationId,
        ipAddress: params.ipAddress,
        userAgent: params.userAgent,
        reason: params.reason,
        metadata: safeMetadata,
        timestamp: new Date(),
      });

      return await log.save();
    } catch (err: any) {
      console.error('[AuditService Error] Failed to write audit event:', err.message);
      // Even if writing audit log throws an error, we capture and re-throw safely
      throw err;
    }
  }

  /**
   * Helper to log denied actions
   */
  async recordDenied(
    action: AuditAction,
    reason: string,
    params: Omit<AuditEventParams, 'action' | 'outcome' | 'reason'>
  ): Promise<IAuditLog> {
    return this.record({
      ...params,
      action,
      outcome: 'denied',
      reason,
    });
  }

  /**
   * Helper to log successful actions
   */
  async recordSuccess(
    action: AuditAction,
    params: Omit<AuditEventParams, 'action' | 'outcome'>
  ): Promise<IAuditLog> {
    return this.record({
      ...params,
      action,
      outcome: 'success',
    });
  }
}

export const auditService = new AuditService();
