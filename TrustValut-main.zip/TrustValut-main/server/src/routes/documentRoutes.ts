import { Router } from 'express';
import {
  uploadDocument,
  getDocuments,
  getDocumentById,
  downloadDocument,
  updateDocumentMetadata,
  getDocumentVersions,
  uploadNewVersion,
  deleteDocument,
  restoreDocument,
} from '../controllers/documentController';
import {
  getDocumentPermissions,
  grantPermission,
  updatePermission,
  revokePermission,
} from '../controllers/permissionController';
import { getDocumentAuditLogs } from '../controllers/auditController';
import { authenticate } from '../middleware/authMiddleware';
import { upload } from '../middleware/uploadMiddleware';

const router = Router();

// All document operations require authentication
router.use(authenticate);

// Document CRUD & versions
router.post('/', upload.single('file'), uploadDocument);
router.get('/', getDocuments);
router.get('/:id', getDocumentById);
router.patch('/:id', updateDocumentMetadata);
router.get('/:id/download', downloadDocument);
router.get('/:id/versions', getDocumentVersions);
router.post('/:id/versions', upload.single('file'), uploadNewVersion);
router.delete('/:id', deleteDocument);
router.post('/:id/restore', restoreDocument);

// Document-specific permissions
router.get('/:id/permissions', getDocumentPermissions);
router.post('/:id/permissions', grantPermission);
router.patch('/:id/permissions/:permissionId', updatePermission);
router.delete('/:id/permissions/:permissionId', revokePermission);

// Document-specific audit history
router.get('/:id/audit', getDocumentAuditLogs);

export default router;
