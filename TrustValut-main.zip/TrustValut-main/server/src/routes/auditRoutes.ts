import { Router } from 'express';
import { getAuditLogs } from '../controllers/auditController';
import { authenticate, requireRoles } from '../middleware/authMiddleware';

const router = Router();

// Global audit exploration requires admin role
router.use(authenticate);
router.get('/', requireRoles('admin'), getAuditLogs);

export default router;
