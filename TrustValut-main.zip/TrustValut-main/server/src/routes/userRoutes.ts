import { Router, Response } from 'express';
import { User } from '../models/User';
import { authenticate } from '../middleware/authMiddleware';
import { AuthenticatedRequest } from '../types';

const router = Router();

router.use(authenticate);

// Autocomplete lookup for registered users to grant permissions
router.get('/search', async (req: AuthenticatedRequest, res: Response): Promise<void> => {
  const query = (req.query.q as string) || '';
  if (!query || query.trim().length < 2) {
    res.status(200).json({ success: true, data: { users: [] } });
    return;
  }

  const cleanQuery = query.trim();
  const users = await User.find({
    status: 'active',
    $or: [
      { email: { $regex: cleanQuery, $options: 'i' } },
      { name: { $regex: cleanQuery, $options: 'i' } },
    ],
  })
    .select('name email role')
    .limit(10)
    .lean();

  res.status(200).json({
    success: true,
    data: {
      users: users.map((u) => ({
        id: u._id,
        name: u.name,
        email: u.email,
        role: u.role,
      })),
    },
  });
});

export default router;
