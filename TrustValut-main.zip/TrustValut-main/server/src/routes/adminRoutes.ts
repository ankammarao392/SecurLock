import { Router } from 'express';
import {
  getAdminDashboard,
  getAdminUsers,
  createAdminUser,
  updateAdminUser,
} from '../controllers/adminController';
import { getAuditLogs } from '../controllers/auditController';
import { authenticate, requireRoles } from '../middleware/authMiddleware';

const router = Router();

router.use(authenticate);
router.use(requireRoles('admin'));

router.get('/dashboard', getAdminDashboard);
router.get('/users', getAdminUsers);
router.post('/users', createAdminUser);
router.patch('/users/:id', updateAdminUser);
router.get('/audit', getAuditLogs);

export default router;
