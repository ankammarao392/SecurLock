import express, { Application, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import path from 'path';
import fs from 'fs';
import mongoose from 'mongoose';
import { ENV } from './config/env';
import authRoutes from './routes/authRoutes';
import documentRoutes from './routes/documentRoutes';
import auditRoutes from './routes/auditRoutes';
import adminRoutes from './routes/adminRoutes';
import userRoutes from './routes/userRoutes';
import { errorHandler } from './middleware/errorHandler';

export function createApp(): Application {
  const app: Application = express();

  // 1. Security Headers with Helmet
  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
    })
  );

  // 2. Strict CORS Configuration
  app.use(
    cors({
      origin: (origin, callback) => {
        // Allow requests with no origin (like mobile apps, curl, Postman, test runners)
        if (!origin) return callback(null, true);
        const allowedOrigins = [
          ENV.CORS_ORIGIN,
          'http://localhost:5173',
          'http://127.0.0.1:5173',
          'http://localhost:3000',
        ];
        if (
          allowedOrigins.includes(origin) ||
          origin.includes('onrender.com') ||
          process.env.NODE_ENV !== 'production'
        ) {
          return callback(null, true);
        }
        return callback(new Error('CORS policy: Not allowed by Access-Control-Allow-Origin'));
      },
      credentials: true,
      methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type', 'Authorization', 'X-Correlation-ID', 'X-CSRF-Token'],
      exposedHeaders: ['Content-Disposition', 'X-Correlation-ID'],
    })
  );

  // 3. Request parsing
  app.use(express.json({ limit: '2mb' }));
  app.use(express.urlencoded({ extended: true, limit: '2mb' }));
  app.use(cookieParser());

  // 4. Request Correlation ID
  app.use((req: Request, res: Response, next: NextFunction) => {
    const correlationId = (req.headers['x-correlation-id'] as string) || crypto.randomUUID();
    (req as any).correlationId = correlationId;
    res.setHeader('X-Correlation-ID', correlationId);
    next();
  });

  // 5. System Health Check
  app.get('/api/health', (req: Request, res: Response) => {
    const dbStatus = mongoose.connection.readyState === 1 ? 'connected' : 'disconnected';
    res.status(200).json({
      status: 'operational',
      name: 'TrustVault API',
      version: '1.0.0',
      database: dbStatus,
      timestamp: new Date().toISOString(),
      correlationId: (req as any).correlationId,
    });
  });

  // 6. API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/documents', documentRoutes);
  app.use('/api/audit', auditRoutes);
  app.use('/api/admin', adminRoutes);
  app.use('/api/users', userRoutes);

  // 7. Serve frontend static assets in production (Render deployment support)
  const candidateDistPaths = [
    path.resolve(process.cwd(), '../client/dist'),
    path.resolve(process.cwd(), 'client/dist'),
    path.resolve(__dirname, '../../client/dist'),
    path.resolve(__dirname, '../../../client/dist'),
  ];

  let clientDistPath: string | null = null;
  for (const p of candidateDistPaths) {
    if (fs.existsSync(p)) {
      clientDistPath = p;
      break;
    }
  }

  if (clientDistPath) {
    app.use(express.static(clientDistPath));
    app.get('*', (req: Request, res: Response, next: NextFunction) => {
      if (req.originalUrl.startsWith('/api')) {
        return next();
      }
      res.sendFile(path.join(clientDistPath!, 'index.html'));
    });
  }

  // 8. Unknown API route handler
  app.use('/api', (req: Request, res: Response) => {
    res.status(404).json({
      success: false,
      error: {
        code: 'ROUTE_NOT_FOUND',
        message: `Endpoint '${req.method} ${req.originalUrl}' does not exist on TrustVault API.`,
        correlationId: (req as any).correlationId,
      },
    });
  });

  // 9. Global Error Handler
  app.use(errorHandler);

  return app;
}

export const app = createApp();
