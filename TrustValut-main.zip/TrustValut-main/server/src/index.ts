import { app } from './app';
import { ENV } from './config/env';
import { connectDatabase, disconnectDatabase } from './config/db';

async function startServer(): Promise<void> {
  console.log('========================================================================');
  console.log('  🛡️   TRUSTVAULT - Enterprise Document Security & Audit Platform');
  console.log('========================================================================');
  console.log(`[Config] Environment: ${ENV.NODE_ENV}`);
  console.log(`[Config] Server Port: ${ENV.PORT}`);
  console.log(`[Config] Private Uploads Directory: ${ENV.UPLOAD_DIR}`);

  try {
    await connectDatabase();
  } catch (err: any) {
    console.error(`[Startup Notice] Database initialization: ${err.message}`);
  }

  const server = app.listen(ENV.PORT, () => {
    console.log(`[TrustVault Server] Running at http://localhost:${ENV.PORT}`);
    console.log(`[TrustVault Server] Health Endpoint: http://localhost:${ENV.PORT}/api/health`);
    console.log('========================================================================\n');
  });

  const handleShutdown = async (signal: string) => {
    console.log(`\n[Shutdown] Received ${signal}. Gracefully stopping TrustVault server...`);
    server.close(async () => {
      console.log('[Shutdown] HTTP server closed.');
      await disconnectDatabase();
      console.log('[Shutdown] Database connection closed.');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => handleShutdown('SIGTERM'));
  process.on('SIGINT', () => handleShutdown('SIGINT'));
}

startServer().catch((err) => {
  console.error('[Fatal Error] Failed to launch TrustVault server:', err);
  process.exit(1);
});
