import bcrypt from 'bcryptjs';
import { User } from '../models/User';
import { connectDatabase, disconnectDatabase } from '../config/db';

async function createAdmin(): Promise<void> {
  const email = process.env.ADMIN_EMAIL || process.argv[2] || 'admin@trustvault.io';
  const name = process.env.ADMIN_NAME || process.argv[3] || 'Security Administrator';
  const password = process.env.ADMIN_PASSWORD || process.argv[4] || 'TrustVault@Admin2026!';

  console.log(`[Admin Provisioning] Connecting to database...`);
  await connectDatabase();

  const existing = await User.findOne({ email: email.toLowerCase().trim() });
  if (existing) {
    console.log(`[Admin Provisioning] User with email ${email} already exists. Updating role to 'admin'...`);
    existing.role = 'admin';
    existing.status = 'active';
    await existing.save();
    console.log(`[Admin Provisioning] User ${email} is now an active administrator.`);
  } else {
    const salt = await bcrypt.genSalt(12);
    const passwordHash = await bcrypt.hash(password, salt);

    const admin = new User({
      name,
      email: email.toLowerCase().trim(),
      passwordHash,
      role: 'admin',
      status: 'active',
      lastLoginAt: new Date(),
    });

    await admin.save();
    console.log(`[Admin Provisioning] Successfully created administrator: ${email}`);
  }

  await disconnectDatabase();
}

createAdmin()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('[Admin Provisioning Error]', err);
    process.exit(1);
  });
