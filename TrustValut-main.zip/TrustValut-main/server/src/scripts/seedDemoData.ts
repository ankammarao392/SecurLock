import bcrypt from 'bcryptjs';
import mongoose, { Types } from 'mongoose';
import { User } from '../models/User';
import { DocumentModel } from '../models/Document';
import { DocumentPermission } from '../models/DocumentPermission';
import { DocumentVersion } from '../models/DocumentVersion';
import { AuditLog } from '../models/AuditLog';
import { fileStorageService } from '../services/fileStorageService';
import { calculateSha256, generateStorageKey } from '../utils/fileValidator';
import { connectDatabase, disconnectDatabase } from '../config/db';

// Minimal valid PDF binary generator
function createMockPdfBuffer(title: string): Buffer {
  const content = `%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >> endobj
4 0 obj << /Length 65 >> stream
BT /F1 18 Tf 50 720 Td (TRUSTVAULT CONFIDENTIAL DOCUMENT: ${title}) Tj ET
endstream
endobj
xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000216 00000 n 
trailer << /Size 5 /Root 1 0 R >>
startxref
332
%%EOF`;
  return Buffer.from(content, 'utf-8');
}

// Minimal valid PNG binary
function createMockPngBuffer(): Buffer {
  return Buffer.from([
    0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
    0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52,
    0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
    0x08, 0x06, 0x00, 0x00, 0x00, 0x1f, 0x15, 0xc4,
    0x89, 0x00, 0x00, 0x00, 0x0a, 0x49, 0x44, 0x41,
    0x54, 0x78, 0x9c, 0x63, 0x00, 0x01, 0x00, 0x00,
    0x05, 0x00, 0x01, 0x0d, 0x0a, 0x2d, 0xb4, 0x00,
    0x00, 0x00, 0x00, 0x49, 0x45, 0x4e, 0x44, 0xae,
    0x42, 0x60, 0x82,
  ]);
}

// Minimal valid ZIP binary for docx/xlsx (PK\x03\x04 ...)
function createMockZipBuffer(label: string): Buffer {
  const header = Buffer.from([0x50, 0x4b, 0x03, 0x04, 0x0a, 0x00, 0x00, 0x00, 0x00, 0x00]);
  const text = Buffer.from(`TrustVault Document Package: ${label}`, 'utf-8');
  return Buffer.concat([header, text]);
}

export async function seedDemoData(): Promise<void> {
  console.log('[Seed] Connecting to database...');
  await connectDatabase();

  console.log('[Seed] Clearing existing demonstration collections...');
  await Promise.all([
    User.deleteMany({}),
    DocumentModel.deleteMany({}),
    DocumentPermission.deleteMany({}),
    DocumentVersion.deleteMany({}),
    (AuditLog as any).deleteMany({}, { skipAuditLock: true }),
  ]);

  console.log('[Seed] Provisioning demo users with secure bcrypt hashes...');
  const salt = await bcrypt.genSalt(12);

  const adminPass = await bcrypt.hash('TrustVault@Admin2026!', salt);
  const sarahPass = await bcrypt.hash('SarahOwner@2026!', salt);
  const marcusPass = await bcrypt.hash('MarcusSec@2026!', salt);
  const alexPass = await bcrypt.hash('AlexViewer@2026!', salt);
  const elenaPass = await bcrypt.hash('ElenaPartner@2026!', salt);

  const [admin, sarah, marcus, alex, elena] = await User.create([
    {
      name: 'Victoria Vance (Chief Information Security Officer)',
      email: 'admin@trustvault.io',
      passwordHash: adminPass,
      role: 'admin',
      status: 'active',
      lastLoginAt: new Date(),
    },
    {
      name: 'Sarah Chen (VP of Legal & Compliance)',
      email: 'sarah.owner@trustvault.io',
      passwordHash: sarahPass,
      role: 'owner',
      status: 'active',
      lastLoginAt: new Date(Date.now() - 3600000),
    },
    {
      name: 'Marcus Brody (Principal Security Architect)',
      email: 'marcus.sec@trustvault.io',
      passwordHash: marcusPass,
      role: 'owner',
      status: 'active',
      lastLoginAt: new Date(Date.now() - 7200000),
    },
    {
      name: 'Alex Rivera (Senior Financial Auditor)',
      email: 'alex.viewer@trustvault.io',
      passwordHash: alexPass,
      role: 'viewer',
      status: 'active',
      lastLoginAt: new Date(Date.now() - 14400000),
    },
    {
      name: 'Elena Rostova (External Audit Partner)',
      email: 'elena.partner@external-advisory.com',
      passwordHash: elenaPass,
      role: 'viewer',
      status: 'active',
      lastLoginAt: new Date(Date.now() - 86400000),
    },
  ]);

  console.log('[Seed] Seeding sample enterprise documents & physical storage files...');

  const docsToSeed = [
    {
      title: 'FY2026 Q3 Board Audit & Revenue Forecast',
      description: 'Comprehensive quarterly financial audit, margin projections, and confidential balance sheet statements.',
      category: 'Financial' as const,
      originalFilename: 'FY2026_Q3_Financial_Audit.pdf',
      mimeType: 'application/pdf',
      sensitivity: 'Confidential' as const,
      ownerId: sarah._id,
      buffer: createMockPdfBuffer('FY2026 Q3 Board Audit & Revenue Forecast'),
    },
    {
      title: 'Strategic Mergers & Acquisition Term Sheet - Project Phoenix',
      description: 'Highly sensitive non-disclosure agreement and valuation term sheet for the pending cross-border acquisition.',
      category: 'Legal' as const,
      originalFilename: 'Project_Phoenix_Term_Sheet.docx',
      mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      sensitivity: 'Restricted' as const,
      ownerId: sarah._id,
      buffer: createMockZipBuffer('Project Phoenix Term Sheet'),
    },
    {
      title: 'Zero-Trust Architecture & Bastion Access Control Model',
      description: 'Detailed cryptographic engineering specs, PKI certificate hierarchy, and perimeter segmentation guidelines.',
      category: 'Security & Compliance' as const,
      originalFilename: 'ZeroTrust_Bastion_Spec_v2.pdf',
      mimeType: 'application/pdf',
      sensitivity: 'Restricted' as const,
      ownerId: marcus._id,
      buffer: createMockPdfBuffer('Zero-Trust Architecture Specification'),
    },
    {
      title: 'Enterprise Cyber Threat Assessment & Penetration Report',
      description: 'External red-team audit findings, attack surface analysis, and cryptographic remediation roadmap.',
      category: 'Security & Compliance' as const,
      originalFilename: 'Cyber_Threat_Assessment_2026.pdf',
      mimeType: 'application/pdf',
      sensitivity: 'Confidential' as const,
      ownerId: marcus._id,
      buffer: createMockPdfBuffer('Cyber Threat Assessment 2026'),
    },
    {
      title: 'TrustVault Identity Provider (IdP) Architectural Diagram',
      description: 'System interaction schematic illustrating OIDC token issuance, RBAC gateway, and audit message queuing.',
      category: 'Engineering' as const,
      originalFilename: 'IdP_Architecture_Topology.png',
      mimeType: 'image/png',
      sensitivity: 'Internal' as const,
      ownerId: marcus._id,
      buffer: createMockPngBuffer(),
    },
    {
      title: 'Global Employee Equity & Bonus Allocation Model',
      description: 'Confidential breakdown of executive RSUs, retention grants, and organizational compensation tiers.',
      category: 'Human Resources' as const,
      originalFilename: 'Equity_Distribution_2026.xlsx',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      sensitivity: 'Confidential' as const,
      ownerId: sarah._id,
      buffer: createMockZipBuffer('Equity Distribution Matrix'),
    },
  ];

  const createdDocs = [];
  for (const docSpec of docsToSeed) {
    const storageKey = generateStorageKey();
    const checksum = calculateSha256(docSpec.buffer);

    await fileStorageService.saveFile(storageKey, docSpec.buffer);

    const doc = await DocumentModel.create({
      title: docSpec.title,
      description: docSpec.description,
      category: docSpec.category,
      originalFilename: docSpec.originalFilename,
      storageKey,
      mimeType: docSpec.mimeType,
      fileSize: docSpec.buffer.length,
      sha256Checksum: checksum,
      ownerId: docSpec.ownerId,
      sensitivity: docSpec.sensitivity,
      version: 1,
      deletedAt: null,
    });

    await DocumentVersion.create({
      documentId: doc._id,
      versionNumber: 1,
      storageKey,
      checksum,
      changedBy: docSpec.ownerId,
      fileSize: docSpec.buffer.length,
      mimeType: docSpec.mimeType,
      originalFilename: docSpec.originalFilename,
      description: 'Initial secure vault deposit',
    });

    createdDocs.push(doc);
  }

  console.log('[Seed] Creating granular document permissions...');
  // Grant Alex Rivera (Viewer) Read access to Sarah's Financial Audit doc
  await DocumentPermission.create({
    documentId: createdDocs[0]._id,
    userId: alex._id,
    permission: 'read',
    grantedBy: sarah._id,
    grantedAt: new Date(Date.now() - 86400000),
    expiresAt: new Date(Date.now() + 30 * 24 * 3600000), // 30 days
    isActive: true,
  });

  // Grant Elena Rostova (Viewer) Read access to Project Phoenix Term Sheet with 7 day expiry
  await DocumentPermission.create({
    documentId: createdDocs[1]._id,
    userId: elena._id,
    permission: 'read',
    grantedBy: sarah._id,
    grantedAt: new Date(Date.now() - 43200000),
    expiresAt: new Date(Date.now() + 7 * 24 * 3600000),
    isActive: true,
  });

  // Grant Alex Rivera Edit access to Zero-Trust Spec
  await DocumentPermission.create({
    documentId: createdDocs[2]._id,
    userId: alex._id,
    permission: 'edit',
    grantedBy: marcus._id,
    grantedAt: new Date(Date.now() - 21600000),
    expiresAt: null,
    isActive: true,
  });

  console.log('[Seed] Seeding audit log events...');
  await AuditLog.create([
    {
      actorId: admin._id,
      actorEmail: admin.email,
      actorRole: admin.role,
      action: 'auth.login.success',
      timestamp: new Date(Date.now() - 3600000 * 2),
      outcome: 'success',
      ipAddress: '192.168.1.10',
      userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
      correlationId: 'corr-seed-01',
    },
    {
      actorId: sarah._id,
      actorEmail: sarah.email,
      actorRole: sarah.role,
      action: 'document.upload',
      documentId: createdDocs[0]._id,
      timestamp: new Date(Date.now() - 86400000),
      outcome: 'success',
      ipAddress: '10.0.4.15',
      userAgent: 'TrustVault Enterprise Client/1.0',
      correlationId: 'corr-seed-02',
      metadata: { title: createdDocs[0].title, sensitivity: 'Confidential' },
    },
    {
      actorId: sarah._id,
      actorEmail: sarah.email,
      actorRole: sarah.role,
      action: 'permission.grant',
      documentId: createdDocs[0]._id,
      targetUserId: alex._id,
      timestamp: new Date(Date.now() - 86400000 + 120000),
      outcome: 'success',
      ipAddress: '10.0.4.15',
      correlationId: 'corr-seed-03',
      metadata: { targetEmail: alex.email, permission: 'read' },
    },
    {
      actorId: alex._id,
      actorEmail: alex.email,
      actorRole: alex.role,
      action: 'document.download',
      documentId: createdDocs[0]._id,
      timestamp: new Date(Date.now() - 86400000 + 360000),
      outcome: 'success',
      ipAddress: '10.0.4.88',
      correlationId: 'corr-seed-04',
      metadata: { title: createdDocs[0].title, fileSize: createdDocs[0].fileSize },
    },
    {
      actorId: alex._id,
      actorEmail: alex.email,
      actorRole: alex.role,
      action: 'document.download',
      documentId: createdDocs[1]._id,
      timestamp: new Date(Date.now() - 3600000),
      outcome: 'denied',
      reason: 'Access denied: You do not have permission to download this document.',
      ipAddress: '10.0.4.88',
      correlationId: 'corr-seed-05',
      metadata: { title: createdDocs[1].title },
    },
  ]);

  console.log('\n========================================================================');
  console.log('✅  DEMO SEED COMPLETED SUCCESSFULLY');
  console.log('========================================================================');
  console.log('Available Demo Accounts:');
  console.log('1. Administrator:   admin@trustvault.io        / TrustVault@Admin2026!');
  console.log('2. Document Owner:  sarah.owner@trustvault.io  / SarahOwner@2026!');
  console.log('3. Document Owner:  marcus.sec@trustvault.io   / MarcusSec@2026!');
  console.log('4. Viewer/Auditor:  alex.viewer@trustvault.io   / AlexViewer@2026!');
  console.log('5. External Viewer: elena.partner@external-advisory.com / ElenaPartner@2026!');
  console.log('========================================================================\n');

  await disconnectDatabase();
}

if (process.argv[1]?.includes('seedDemoData')) {
  seedDemoData()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error('[Seed Error]', err);
      process.exit(1);
    });
}
