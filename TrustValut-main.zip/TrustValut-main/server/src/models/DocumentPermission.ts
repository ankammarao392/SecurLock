import mongoose, { Schema, Document as MongooseDocument, Types } from 'mongoose';
import { PermissionType } from '../types';

export interface IDocumentPermission extends MongooseDocument {
  documentId: Types.ObjectId;
  userId: Types.ObjectId;
  permission: PermissionType;
  grantedBy: Types.ObjectId;
  grantedAt: Date;
  expiresAt?: Date | null;
  revokedAt?: Date | null;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

const DocumentPermissionSchema = new Schema<IDocumentPermission>(
  {
    documentId: {
      type: Schema.Types.ObjectId,
      ref: 'Document',
      required: true,
      index: true,
    },
    userId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    permission: {
      type: String,
      enum: ['read', 'edit'],
      required: true,
    },
    grantedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    grantedAt: {
      type: Date,
      default: Date.now,
    },
    expiresAt: {
      type: Date,
      default: null,
      index: true,
    },
    revokedAt: {
      type: Date,
      default: null,
    },
    isActive: {
      type: Boolean,
      default: true,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

// Enforce unique active permission per document-user pair while preserving historical records
DocumentPermissionSchema.index(
  { documentId: 1, userId: 1 },
  {
    unique: true,
    partialFilterExpression: { isActive: true },
  }
);

export const DocumentPermission = mongoose.model<IDocumentPermission>(
  'DocumentPermission',
  DocumentPermissionSchema
);
