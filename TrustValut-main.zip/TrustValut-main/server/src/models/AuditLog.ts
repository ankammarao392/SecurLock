import mongoose, { Schema, Document as MongooseDocument, Types } from 'mongoose';
import { AuditAction, AuditOutcome } from '../types';

export interface IAuditLog extends MongooseDocument {
  actorId?: Types.ObjectId | null;
  actorEmail?: string;
  actorRole?: string;
  action: AuditAction;
  documentId?: Types.ObjectId | null;
  targetUserId?: Types.ObjectId | null;
  timestamp: Date;
  outcome: AuditOutcome;
  correlationId?: string;
  ipAddress?: string;
  userAgent?: string;
  reason?: string;
  metadata?: Record<string, any>;
  createdAt: Date;
}

const AuditLogSchema = new Schema<IAuditLog>(
  {
    actorId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
      index: true,
    },
    actorEmail: {
      type: String,
      default: null,
    },
    actorRole: {
      type: String,
      default: null,
    },
    action: {
      type: String,
      required: true,
      index: true,
    },
    documentId: {
      type: Schema.Types.ObjectId,
      ref: 'Document',
      default: null,
      index: true,
    },
    targetUserId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      default: null,
      index: true,
    },
    timestamp: {
      type: Date,
      default: Date.now,
      index: true,
    },
    outcome: {
      type: String,
      enum: ['success', 'denied'],
      required: true,
      index: true,
    },
    correlationId: {
      type: String,
      index: true,
    },
    ipAddress: {
      type: String,
    },
    userAgent: {
      type: String,
    },
    reason: {
      type: String,
    },
    metadata: {
      type: Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false }, // Immutable append-only: no updatedAt
  }
);

// Block any mongoose update/remove hooks at schema level to defend immutability
AuditLogSchema.pre('updateOne', function () {
  if ((this as any).getOptions()?.skipAuditLock) return;
  throw new Error('Audit logs are append-only and cannot be modified.');
});
AuditLogSchema.pre('updateMany', function () {
  if ((this as any).getOptions()?.skipAuditLock) return;
  throw new Error('Audit logs are append-only and cannot be modified.');
});
AuditLogSchema.pre('findOneAndUpdate', function () {
  if ((this as any).getOptions()?.skipAuditLock) return;
  throw new Error('Audit logs are append-only and cannot be modified.');
});
AuditLogSchema.pre('deleteOne', function () {
  if ((this as any).getOptions()?.skipAuditLock) return;
  throw new Error('Audit logs are append-only and cannot be deleted.');
});
AuditLogSchema.pre('deleteMany', function () {
  if ((this as any).getOptions()?.skipAuditLock) return;
  throw new Error('Audit logs are append-only and cannot be deleted.');
});

AuditLogSchema.index({ timestamp: -1 });
AuditLogSchema.index({ documentId: 1, timestamp: -1 });
AuditLogSchema.index({ actorId: 1, timestamp: -1 });

export const AuditLog = mongoose.model<IAuditLog>('AuditLog', AuditLogSchema);
