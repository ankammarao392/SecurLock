import mongoose, { Schema, Document as MongooseDocument, Types } from 'mongoose';
import { DocumentCategory, DocumentSensitivity } from '../types';

export interface IDocument extends MongooseDocument {
  title: string;
  description?: string;
  category: DocumentCategory;
  originalFilename: string;
  storageKey: string;
  mimeType: string;
  fileSize: number;
  sha256Checksum: string;
  ownerId: Types.ObjectId;
  sensitivity: DocumentSensitivity;
  version: number;
  deletedAt?: Date | null;
  createdAt: Date;
  updatedAt: Date;
}

const DocumentSchema = new Schema<IDocument>(
  {
    title: {
      type: String,
      required: true,
      trim: true,
      maxlength: 255,
    },
    description: {
      type: String,
      trim: true,
      maxlength: 2000,
      default: '',
    },
    category: {
      type: String,
      enum: ['Legal', 'Financial', 'Human Resources', 'Security & Compliance', 'Engineering', 'Executive', 'Operations', 'Other'],
      default: 'Other',
      index: true,
    },
    originalFilename: {
      type: String,
      required: true,
    },
    storageKey: {
      type: String,
      required: true,
      unique: true,
      index: true,
    },
    mimeType: {
      type: String,
      required: true,
    },
    fileSize: {
      type: Number,
      required: true,
      min: 0,
    },
    sha256Checksum: {
      type: String,
      required: true,
    },
    ownerId: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true,
    },
    sensitivity: {
      type: String,
      enum: ['Public', 'Internal', 'Confidential', 'Restricted'],
      default: 'Internal',
      index: true,
    },
    version: {
      type: Number,
      default: 1,
      min: 1,
    },
    deletedAt: {
      type: Date,
      default: null,
      index: true,
    },
  },
  {
    timestamps: true,
  }
);

DocumentSchema.index({ title: 'text', description: 'text' });
DocumentSchema.index({ ownerId: 1, deletedAt: 1, createdAt: -1 });

export const DocumentModel = mongoose.model<IDocument>('Document', DocumentSchema);
