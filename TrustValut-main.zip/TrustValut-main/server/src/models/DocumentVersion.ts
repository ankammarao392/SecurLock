import mongoose, { Schema, Document as MongooseDocument, Types } from 'mongoose';

export interface IDocumentVersion extends MongooseDocument {
  documentId: Types.ObjectId;
  versionNumber: number;
  storageKey: string;
  checksum: string;
  changedBy: Types.ObjectId;
  fileSize: number;
  mimeType: string;
  originalFilename: string;
  description?: string;
  createdAt: Date;
}

const DocumentVersionSchema = new Schema<IDocumentVersion>(
  {
    documentId: {
      type: Schema.Types.ObjectId,
      ref: 'Document',
      required: true,
      index: true,
    },
    versionNumber: {
      type: Number,
      required: true,
      min: 1,
    },
    storageKey: {
      type: String,
      required: true,
    },
    checksum: {
      type: String,
      required: true,
    },
    changedBy: {
      type: Schema.Types.ObjectId,
      ref: 'User',
      required: true,
    },
    fileSize: {
      type: Number,
      required: true,
    },
    mimeType: {
      type: String,
      required: true,
    },
    originalFilename: {
      type: String,
      required: true,
    },
    description: {
      type: String,
      default: '',
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
  }
);

DocumentVersionSchema.index({ documentId: 1, versionNumber: -1 }, { unique: true });

export const DocumentVersion = mongoose.model<IDocumentVersion>(
  'DocumentVersion',
  DocumentVersionSchema
);
