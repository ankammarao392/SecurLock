import { IDocument } from '../models/Document';
import { IDocumentPermission, DocumentPermission } from '../models/DocumentPermission';
import { AuthUserPayload } from '../types';

export interface AuthorizationResult {
  allowed: boolean;
  reason?: string;
  activePermission?: IDocumentPermission | null;
}

/**
 * Checks if a permission is currently valid and not expired
 */
export function isPermissionValid(perm: IDocumentPermission | null): boolean {
  if (!perm || !perm.isActive) return false;
  if (perm.expiresAt && new Date(perm.expiresAt).getTime() <= Date.now()) {
    return false;
  }
  return true;
}

/**
 * Retrieves the currently active, unexpired permission for a given user and document
 */
export async function getActivePermission(
  documentId: string,
  userId: string
): Promise<IDocumentPermission | null> {
  const perm = await DocumentPermission.findOne({
    documentId,
    userId,
    isActive: true,
  });

  if (!perm) return null;

  // Check if expired
  if (perm.expiresAt && new Date(perm.expiresAt).getTime() <= Date.now()) {
    // If expired, treat as inactive
    return null;
  }

  return perm;
}

/**
 * Policy: Can user read document metadata / view document?
 * - Document owner: YES (if not permanently deleted)
 * - Explicit active permission (read or edit): YES
 * - Admin: Can view metadata in admin overview, but cannot read private document content unless permitted.
 */
export async function canReadDocument(
  user: AuthUserPayload,
  document: IDocument
): Promise<AuthorizationResult> {
  // If soft-deleted, only owner can view details
  if (document.deletedAt) {
    if (document.ownerId.toString() === user.userId) {
      return { allowed: true };
    }
    return { allowed: false, reason: 'Document is deleted and not accessible.' };
  }

  // Document owner always has read access
  if (document.ownerId.toString() === user.userId) {
    return { allowed: true };
  }

  // Check active granted permission
  const activePerm = await getActivePermission(document._id.toString(), user.userId);
  if (activePerm && isPermissionValid(activePerm)) {
    return { allowed: true, activePermission: activePerm };
  }

  return {
    allowed: false,
    reason: 'Access denied: You do not have an active read permission for this document.',
  };
}

/**
 * Policy: Can user download the document file stream?
 * Strict least-privilege: Admins CANNOT automatically download confidential files!
 * Only owner OR user with active read/edit permission can download.
 */
export async function canDownloadDocument(
  user: AuthUserPayload,
  document: IDocument
): Promise<AuthorizationResult> {
  if (document.deletedAt) {
    return { allowed: false, reason: 'Document is deleted and cannot be downloaded.' };
  }

  // Owner can download
  if (document.ownerId.toString() === user.userId) {
    return { allowed: true };
  }

  // User with active permission (read or edit) can download
  const activePerm = await getActivePermission(document._id.toString(), user.userId);
  if (activePerm && isPermissionValid(activePerm)) {
    return { allowed: true, activePermission: activePerm };
  }

  return {
    allowed: false,
    reason: 'Access denied: You do not have permission to download this document.',
  };
}

/**
 * Policy: Can user edit document metadata or upload new version?
 * - Document owner: YES
 * - User with explicit active 'edit' permission: YES
 * - Others (including read-only and admin): NO
 */
export async function canEditDocument(
  user: AuthUserPayload,
  document: IDocument
): Promise<AuthorizationResult> {
  if (document.deletedAt) {
    return { allowed: false, reason: 'Cannot edit a deleted document.' };
  }

  if (document.ownerId.toString() === user.userId) {
    return { allowed: true };
  }

  const activePerm = await getActivePermission(document._id.toString(), user.userId);
  if (activePerm && isPermissionValid(activePerm) && activePerm.permission === 'edit') {
    return { allowed: true, activePermission: activePerm };
  }

  return {
    allowed: false,
    reason: 'Access denied: Requires edit permission from the document owner.',
  };
}

/**
 * Policy: Can user delete (soft-delete) or restore the document?
 * - Document owner: YES
 * - Others: NO
 */
export function canDeleteDocument(
  user: AuthUserPayload,
  document: IDocument
): AuthorizationResult {
  if (document.ownerId.toString() === user.userId) {
    return { allowed: true };
  }

  return {
    allowed: false,
    reason: 'Access denied: Only the document owner can delete or restore this document.',
  };
}

/**
 * Policy: Can user permanently purge document from retention?
 * - Document owner: YES (when already soft-deleted)
 * - Admin: YES (administrative retention enforcement)
 */
export function canPurgeDocument(
  user: AuthUserPayload,
  document: IDocument
): AuthorizationResult {
  if (document.ownerId.toString() === user.userId || user.role === 'admin') {
    return { allowed: true };
  }

  return {
    allowed: false,
    reason: 'Access denied: Requires document owner or administrator retention privileges.',
  };
}

/**
 * Policy: Can user manage permissions (grant/revoke/update)?
 * - Document owner: YES
 * - Others: NO
 */
export function canManagePermissions(
  user: AuthUserPayload,
  document: IDocument
): AuthorizationResult {
  if (document.ownerId.toString() === user.userId) {
    return { allowed: true };
  }

  return {
    allowed: false,
    reason: 'Access denied: Only the document owner can manage access permissions.',
  };
}

/**
 * Policy: Can user view audit history for a specific document?
 * - Document owner: YES
 * - Admin: YES
 * - Others: NO
 */
export function canViewDocumentAudit(
  user: AuthUserPayload,
  document: IDocument
): AuthorizationResult {
  if (document.ownerId.toString() === user.userId || user.role === 'admin') {
    return { allowed: true };
  }

  return {
    allowed: false,
    reason: 'Access denied: Document audit logs are restricted to the owner and administrators.',
  };
}
