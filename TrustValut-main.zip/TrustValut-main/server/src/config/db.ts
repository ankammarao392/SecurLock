import mongoose from 'mongoose';
import { ENV } from './env';

/**
 * Sanitizes MongoDB connection string by masking user credentials
 */
export function sanitizeMongoUri(uri: string): string {
  try {
    return uri.replace(/\/\/([^:]+):([^@]+)@/, '//$1:******@');
  } catch {
    return '[REDACTED_URI]';
  }
}

export async function connectDatabase(uriOverride?: string): Promise<typeof mongoose | null> {
  const uri = uriOverride || ENV.MONGODB_URI;

  if (!uri || uri.includes('your_mongodb_atlas_connection_string')) {
    console.warn('\n========================================================================');
    console.warn('[TrustVault Security Notice] MONGODB_URI is not set or contains placeholder.');
    console.warn('To connect to MongoDB Atlas, please set MONGODB_URI in server/.env');
    console.warn('Example: MONGODB_URI=mongodb+srv://<user>:<password>@cluster.mongodb.net/trustvault');
    console.warn('========================================================================\n');
    return null;
  }

  try {
    const connection = await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 8000,
      autoIndex: true,
    });
    console.log(`[TrustVault Database] Connected successfully to MongoDB: ${sanitizeMongoUri(uri)}`);
    return connection;
  } catch (error: any) {
    console.error(`[TrustVault Database Error] Failed to connect to MongoDB (${sanitizeMongoUri(uri)}): ${error.message}`);
    throw new Error(`Database connection failed: ${error.message}`);
  }
}

export async function disconnectDatabase(): Promise<void> {
  await mongoose.disconnect();
}
