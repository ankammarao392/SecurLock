import { Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { ENV } from '../config/env';
import { AuthenticatedRequest, AuthUserPayload, UserRole } from '../types';
import { User } from '../models/User';
import { auditService } from '../services/auditService';

/**
 * Middleware: Verifies JWT from HTTP-only cookie or Bearer token,
 * verifies user active status in the database to prevent session continuation for disabled accounts.
 */
export async function authenticate(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  const correlationId = (req.headers['x-correlation-id'] as string) || crypto.randomUUID();
  req.correlationId = correlationId;

  try {
    // 1. Extract token from HTTP-only cookie or Authorization header
    let token = req.cookies?.[ENV.COOKIE_NAME];
    if (!token && req.headers.authorization?.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      res.status(401).json({
        success: false,
        error: {
          code: 'UNAUTHENTICATED',
          message: 'Authentication token missing or invalid.',
          correlationId,
        },
      });
      return;
    }

    // 2. Verify JWT signature & expiration
    let decoded: any;
    try {
      decoded = jwt.verify(token, ENV.JWT_SECRET) as AuthUserPayload;
    } catch (err: any) {
      res.status(401).json({
        success: false,
        error: {
          code: 'INVALID_TOKEN',
          message: 'Session has expired or is invalid. Please log in again.',
          correlationId,
        },
      });
      return;
    }

    // 3. Database verification: check if user still exists and is ACTIVE
    const userDoc = await User.findById(decoded.userId).select('+status');
    if (!userDoc) {
      res.status(401).json({
        success: false,
        error: {
          code: 'USER_NOT_FOUND',
          message: 'The account associated with this session no longer exists.',
          correlationId,
        },
      });
      return;
    }

    if (userDoc.status !== 'active') {
      // Disabled account check - immediate invalidation
      await auditService.recordDenied('access.denied', 'Account disabled', {
        actorId: userDoc._id,
        actorEmail: userDoc.email,
        actorRole: userDoc.role,
        correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        metadata: { path: req.originalUrl, method: req.method },
      });

      res.status(403).json({
        success: false,
        error: {
          code: 'ACCOUNT_DISABLED',
          message: 'Your account has been deactivated. Please contact an administrator.',
          correlationId,
        },
      });
      return;
    }

    // Attach validated payload
    req.user = {
      userId: userDoc._id.toString(),
      email: userDoc.email,
      role: userDoc.role,
      name: userDoc.name,
    };

    next();
  } catch (error: any) {
    res.status(500).json({
      success: false,
      error: {
        code: 'AUTH_ERROR',
        message: 'Internal authentication validation error.',
        correlationId,
      },
    });
  }
}

/**
 * Role-Based Access Control Guard
 */
export function requireRoles(...roles: UserRole[]) {
  return async (req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> => {
    if (!req.user) {
      res.status(401).json({
        success: false,
        error: { code: 'UNAUTHENTICATED', message: 'Authentication required.' },
      });
      return;
    }

    if (!roles.includes(req.user.role)) {
      await auditService.recordDenied('access.denied', `Required role [${roles.join(', ')}] not held by user role ${req.user.role}`, {
        actorId: req.user.userId,
        actorEmail: req.user.email,
        actorRole: req.user.role,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
        metadata: { path: req.originalUrl, method: req.method, requiredRoles: roles },
      });

      res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: `Access denied. Requires one of the following roles: ${roles.join(', ')}.`,
          correlationId: req.correlationId,
        },
      });
      return;
    }

    next();
  };
}
