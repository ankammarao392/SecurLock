import multer from 'multer';
import { ENV } from '../config/env';

// Store uploaded files in memory for signature inspection and validation
const storage = multer.memoryStorage();

export const upload = multer({
  storage,
  limits: {
    fileSize: ENV.MAX_FILE_SIZE_BYTES, // 10 MB limit
    files: 1,
  },
});
