import { Request, Response, NextFunction } from 'express';
import { ZodError } from 'zod';
import multer from 'multer';

export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const correlationId = (req as any).correlationId;

  // Handle Zod Validation Errors
  if (err instanceof ZodError) {
    const errorMessages = err.errors.map((e) => e.message).join('. ');
    res.status(400).json({
      success: false,
      error: {
        code: 'VALIDATION_ERROR',
        message: errorMessages || 'Request payload validation failed.',
        details: err.errors.map((e) => ({
          path: e.path.join('.'),
          message: e.message,
        })),
        correlationId,
      },
    });
    return;
  }

  // Handle Multer upload errors
  if (err instanceof multer.MulterError) {
    if (err.code === 'LIMIT_FILE_SIZE') {
      res.status(400).json({
        success: false,
        error: {
          code: 'FILE_TOO_LARGE',
          message: 'Uploaded file exceeds the maximum allowed size limit of 10 MB.',
          correlationId,
        },
      });
      return;
    }

    res.status(400).json({
      success: false,
      error: {
        code: 'UPLOAD_ERROR',
        message: err.message,
        correlationId,
      },
    });
    return;
  }

  // Handle Mongoose CastError (e.g. invalid ObjectId format)
  if (err.name === 'CastError' && err.kind === 'ObjectId') {
    res.status(404).json({
      success: false,
      error: {
        code: 'NOT_FOUND',
        message: 'The requested resource was not found.',
        correlationId,
      },
    });
    return;
  }

  // Default internal server error (do not leak stack trace)
  console.error('[Unhandled Server Error]', err);

  res.status(err.status || 500).json({
    success: false,
    error: {
      code: err.code || 'INTERNAL_SERVER_ERROR',
      message:
        process.env.NODE_ENV === 'production'
          ? 'An internal error occurred. Please contact security administration.'
          : err.message || 'An unexpected error occurred.',
      correlationId,
    },
  });
}
