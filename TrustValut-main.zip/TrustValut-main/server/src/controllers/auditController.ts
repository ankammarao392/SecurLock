import { Response, NextFunction } from 'express';
import { Types } from 'mongoose';
import { AuditLog } from '../models/AuditLog';
import { DocumentModel } from '../models/Document';
import { AuthenticatedRequest } from '../types';
import { canViewDocumentAudit } from '../policies/documentPolicy';
import { auditService } from '../services/auditService';

export async function getAuditLogs(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;

    // Non-admin users cannot browse global audit logs
    if (user.role !== 'admin') {
      await auditService.recordDenied('access.denied', 'Unauthorized global audit view attempt', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: 'Access denied: Global audit logs are restricted to security administrators.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    const {
      search,
      action,
      outcome,
      actorId,
      documentId,
      startDate,
      endDate,
      format,
    } = req.query;

    const query: any = {};

    if (action) query.action = action;
    if (outcome) query.outcome = outcome;
    if (actorId && Types.ObjectId.isValid(actorId as string)) {
      query.actorId = new Types.ObjectId(actorId as string);
    }
    if (documentId && Types.ObjectId.isValid(documentId as string)) {
      query.documentId = new Types.ObjectId(documentId as string);
    }

    if (startDate || endDate) {
      query.timestamp = {};
      if (startDate) query.timestamp.$gte = new Date(startDate as string);
      if (endDate) query.timestamp.$lte = new Date(endDate as string);
    }

    if (search && typeof search === 'string' && search.trim()) {
      const term = search.trim();
      query.$or = [
        { actorEmail: { $regex: term, $options: 'i' } },
        { action: { $regex: term, $options: 'i' } },
        { reason: { $regex: term, $options: 'i' } },
        { correlationId: { $regex: term, $options: 'i' } },
      ];
    }

    // Check for CSV export request
    if (format === 'csv') {
      const logs = await AuditLog.find(query)
        .populate('actorId', 'name email')
        .populate('documentId', 'title')
        .sort({ timestamp: -1 })
        .limit(2000)
        .lean();

      let csv = 'Timestamp,Action,Outcome,Actor Email,Actor Role,Document Title,IP Address,Reason,Correlation ID\n';
      logs.forEach((log: any) => {
        const time = new Date(log.timestamp).toISOString();
        const actionStr = `"${log.action || ''}"`;
        const outcomeStr = `"${log.outcome || ''}"`;
        const actor = `"${log.actorEmail || (log.actorId ? log.actorId.email : 'System')}"`;
        const role = `"${log.actorRole || ''}"`;
        const docTitle = `"${log.documentId ? (log.documentId.title || '').replace(/"/g, '""') : ''}"`;
        const ip = `"${log.ipAddress || ''}"`;
        const reasonStr = `"${(log.reason || '').replace(/"/g, '""')}"`;
        const corrId = `"${log.correlationId || ''}"`;
        csv += `${time},${actionStr},${outcomeStr},${actor},${role},${docTitle},${ip},${reasonStr},${corrId}\n`;
      });

      await auditService.recordSuccess('admin.audit_export', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        correlationId: req.correlationId,
        metadata: { recordCount: logs.length },
      });

      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', `attachment; filename="trustvault-audit-export-${Date.now()}.csv"`);
      res.send(csv);
      return;
    }

    // Standard JSON pagination
    const page = Math.max(1, parseInt((req.query.page as string) || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt((req.query.limit as string) || '25', 10)));
    const skip = (page - 1) * limit;

    const [logs, total, summary] = await Promise.all([
      AuditLog.find(query)
        .populate('actorId', 'name email')
        .populate('documentId', 'title')
        .sort({ timestamp: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      AuditLog.countDocuments(query),
      // Summary analytics
      Promise.all([
        AuditLog.countDocuments({ action: 'document.download', outcome: 'success' }),
        AuditLog.countDocuments({ action: 'permission.grant', outcome: 'success' }),
        AuditLog.countDocuments({ outcome: 'denied' }),
        AuditLog.countDocuments({ action: 'document.upload', outcome: 'success' }),
      ]),
    ]);

    const formattedLogs = logs.map((log: any) => ({
      id: log._id,
      timestamp: log.timestamp,
      action: log.action,
      outcome: log.outcome,
      correlationId: log.correlationId,
      actor: log.actorId
        ? { id: log.actorId._id, name: log.actorId.name, email: log.actorId.email }
        : { email: log.actorEmail || 'System / Anonymous', name: 'System' },
      actorRole: log.actorRole,
      document: log.documentId
        ? { id: log.documentId._id, title: log.documentId.title }
        : null,
      ipAddress: log.ipAddress,
      userAgent: log.userAgent,
      reason: log.reason,
      metadata: log.metadata,
    }));

    res.status(200).json({
      success: true,
      data: {
        logs: formattedLogs,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
        summary: {
          totalDownloads: summary[0],
          totalPermissionChanges: summary[1],
          totalDeniedAttempts: summary[2],
          totalUploads: summary[3],
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getDocumentAuditLogs(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const check = canViewDocumentAudit(user, document);
    if (!check.allowed) {
      await auditService.recordDenied('access.denied', check.reason || 'Document audit view denied', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: check.reason, correlationId: req.correlationId },
      });
      return;
    }

    const logs = await AuditLog.find({ documentId: document._id })
      .populate('actorId', 'name email role')
      .sort({ timestamp: -1 })
      .limit(100)
      .lean();

    const formattedLogs = logs.map((log: any) => ({
      id: log._id,
      timestamp: log.timestamp,
      action: log.action,
      outcome: log.outcome,
      correlationId: log.correlationId,
      actor: log.actorId
        ? { id: log.actorId._id, name: log.actorId.name, email: log.actorId.email, role: log.actorId.role }
        : { email: log.actorEmail || 'System', name: 'System', role: log.actorRole },
      reason: log.reason,
      metadata: log.metadata,
    }));

    res.status(200).json({
      success: true,
      data: { logs: formattedLogs },
    });
  } catch (error) {
    next(error);
  }
}
