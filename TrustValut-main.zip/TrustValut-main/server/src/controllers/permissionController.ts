import { Response, NextFunction } from 'express';
import { Types } from 'mongoose';
import { DocumentModel } from '../models/Document';
import { DocumentPermission } from '../models/DocumentPermission';
import { User } from '../models/User';
import { AuthenticatedRequest } from '../types';
import { grantPermissionSchema, updatePermissionSchema } from '../validators';
import { auditService } from '../services/auditService';
import { canManagePermissions } from '../policies/documentPolicy';

export async function getDocumentPermissions(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const check = canManagePermissions(user, document);
    if (!check.allowed && user.role !== 'admin') {
      await auditService.recordDenied('access.denied', 'Cannot view permissions list', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: 'Only the document owner can view permissions.', correlationId: req.correlationId },
      });
      return;
    }

    const permissions = await DocumentPermission.find({ documentId: document._id })
      .populate('userId', 'name email role status')
      .populate('grantedBy', 'name email')
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: { permissions },
    });
  } catch (error) {
    next(error);
  }
}

export async function grantPermission(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;
    const validated = grantPermissionSchema.parse(req.body);

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const check = canManagePermissions(user, document);
    if (!check.allowed) {
      await auditService.recordDenied('permission.grant', check.reason || 'Permission management denied', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: check.reason, correlationId: req.correlationId },
      });
      return;
    }

    // Lookup recipient user
    let recipientUser = null;
    if (validated.userId) {
      recipientUser = await User.findById(validated.userId);
    } else if (validated.userEmail) {
      recipientUser = await User.findOne({ email: validated.userEmail.toLowerCase().trim() });
    }

    if (!recipientUser) {
      res.status(400).json({
        success: false,
        error: {
          code: 'USER_NOT_FOUND',
          message: 'The specified recipient user does not exist in TrustVault. Access cannot be granted to unregistered users.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // Cannot grant permission to oneself (already owner)
    if (recipientUser._id.toString() === document.ownerId.toString()) {
      res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_RECIPIENT',
          message: 'Cannot grant permissions to the document owner.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    const expiresAt = validated.expiresAt ? new Date(validated.expiresAt) : null;

    // Check if an active permission already exists for this user-document pair
    const existingActivePerm = await DocumentPermission.findOne({
      documentId: document._id,
      userId: recipientUser._id,
      isActive: true,
    });

    if (existingActivePerm) {
      // Archive the existing permission
      existingActivePerm.isActive = false;
      existingActivePerm.revokedAt = new Date();
      await existingActivePerm.save();
    }

    // Create the new active permission
    const newPermission = new DocumentPermission({
      documentId: document._id,
      userId: recipientUser._id,
      permission: validated.permission,
      grantedBy: new Types.ObjectId(user.userId),
      grantedAt: new Date(),
      expiresAt,
      isActive: true,
      revokedAt: null,
    });

    await newPermission.save();

    await auditService.recordSuccess('permission.grant', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      targetUserId: recipientUser._id,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      metadata: {
        targetEmail: recipientUser.email,
        permission: validated.permission,
        expiresAt,
      },
    });

    res.status(201).json({
      success: true,
      data: {
        permission: {
          id: newPermission._id,
          documentId: newPermission.documentId,
          user: {
            id: recipientUser._id,
            name: recipientUser.name,
            email: recipientUser.email,
          },
          permission: newPermission.permission,
          grantedAt: newPermission.grantedAt,
          expiresAt: newPermission.expiresAt,
          isActive: newPermission.isActive,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function updatePermission(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id, permissionId } = req.params;
    const validated = updatePermissionSchema.parse(req.body);

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const check = canManagePermissions(user, document);
    if (!check.allowed) {
      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: check.reason, correlationId: req.correlationId },
      });
      return;
    }

    const permission = await DocumentPermission.findOne({
      _id: permissionId,
      documentId: document._id,
      isActive: true,
    });

    if (!permission) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Active permission record not found.', correlationId: req.correlationId },
      });
      return;
    }

    if (validated.permission) permission.permission = validated.permission;
    if (validated.expiresAt !== undefined) {
      permission.expiresAt = validated.expiresAt ? new Date(validated.expiresAt) : null;
    }

    await permission.save();

    await auditService.recordSuccess('permission.update', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      targetUserId: permission.userId,
      correlationId: req.correlationId,
      metadata: { permission: permission.permission, expiresAt: permission.expiresAt },
    });

    res.status(200).json({
      success: true,
      data: { permission },
    });
  } catch (error) {
    next(error);
  }
}

export async function revokePermission(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id, permissionId } = req.params;

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const check = canManagePermissions(user, document);
    if (!check.allowed) {
      await auditService.recordDenied('permission.revoke', check.reason || 'Revoke denied', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: check.reason, correlationId: req.correlationId },
      });
      return;
    }

    const permission = await DocumentPermission.findOne({
      _id: permissionId,
      documentId: document._id,
      isActive: true,
    });

    if (!permission) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Active permission not found.', correlationId: req.correlationId },
      });
      return;
    }

    // Instant revocation: deactivate and timestamp
    permission.isActive = false;
    permission.revokedAt = new Date();
    await permission.save();

    await auditService.recordSuccess('permission.revoke', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      targetUserId: permission.userId,
      correlationId: req.correlationId,
      metadata: { revokedPermission: permission.permission },
    });

    res.status(200).json({
      success: true,
      data: { message: 'Permission revoked successfully. Access has been removed immediately.' },
    });
  } catch (error) {
    next(error);
  }
}
