import { Response, NextFunction } from 'express';
import { Types } from 'mongoose';
import { DocumentModel, IDocument } from '../models/Document';
import { DocumentPermission } from '../models/DocumentPermission';
import { DocumentVersion } from '../models/DocumentVersion';
import { AuthenticatedRequest } from '../types';
import {
  documentUploadSchema,
  documentUpdateSchema,
} from '../validators';
import {
  validateUploadedBuffer,
  calculateSha256,
  generateStorageKey,
} from '../utils/fileValidator';
import { fileStorageService } from '../services/fileStorageService';
import { auditService } from '../services/auditService';
import {
  canReadDocument,
  canDownloadDocument,
  canEditDocument,
  canDeleteDocument,
  canPurgeDocument,
  getActivePermission,
} from '../policies/documentPolicy';

export async function uploadDocument(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const file = req.file;

    if (!file) {
      res.status(400).json({
        success: false,
        error: {
          code: 'FILE_REQUIRED',
          message: 'A document file is required for upload.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // 1. Validate metadata
    const validatedMetadata = documentUploadSchema.parse(req.body);

    // 2. Validate file signature / magic bytes
    const validationResult = validateUploadedBuffer(
      file.buffer,
      file.originalname,
      file.mimetype
    );

    if (!validationResult.isValid) {
      await auditService.recordDenied(
        'document.upload',
        validationResult.errorMessage || 'Invalid file signature',
        {
          actorId: user.userId,
          actorEmail: user.email,
          actorRole: user.role,
          correlationId: req.correlationId,
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
          metadata: {
            originalFilename: file.originalname,
            fileSize: file.size,
            declaredMimeType: file.mimetype,
          },
        }
      );

      res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_FILE',
          message: validationResult.errorMessage,
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // 3. Calculate checksum & generate storage key
    const checksum = calculateSha256(file.buffer);
    const storageKey = generateStorageKey();

    // 4. Save file to private storage
    await fileStorageService.saveFile(storageKey, file.buffer);

    // 5. Create database record
    const document = new DocumentModel({
      title: validatedMetadata.title,
      description: validatedMetadata.description,
      category: validatedMetadata.category,
      originalFilename: file.originalname,
      storageKey,
      mimeType: validationResult.detectedMimeType || file.mimetype,
      fileSize: file.size,
      sha256Checksum: checksum,
      ownerId: new Types.ObjectId(user.userId),
      sensitivity: validatedMetadata.sensitivity,
      version: 1,
      deletedAt: null,
    });

    await document.save();

    // 6. Record initial version in DocumentVersion
    const versionRecord = new DocumentVersion({
      documentId: document._id,
      versionNumber: 1,
      storageKey,
      checksum,
      changedBy: new Types.ObjectId(user.userId),
      fileSize: file.size,
      mimeType: document.mimeType,
      originalFilename: file.originalname,
      description: 'Initial upload',
    });
    await versionRecord.save();

    // 7. Audit log
    await auditService.recordSuccess('document.upload', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      metadata: {
        title: document.title,
        category: document.category,
        sensitivity: document.sensitivity,
        checksum,
        fileSize: file.size,
      },
    });

    res.status(201).json({
      success: true,
      data: {
        document: {
          id: document._id,
          title: document.title,
          description: document.description,
          category: document.category,
          originalFilename: document.originalFilename,
          mimeType: document.mimeType,
          fileSize: document.fileSize,
          sha256Checksum: document.sha256Checksum,
          sensitivity: document.sensitivity,
          version: document.version,
          createdAt: document.createdAt,
          updatedAt: document.updatedAt,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getDocuments(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const scope = (req.query.scope as string) || 'all';
    const category = req.query.category as string;
    const sensitivity = req.query.sensitivity as string;
    const search = req.query.search as string;
    const page = Math.max(1, parseInt((req.query.page as string) || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt((req.query.limit as string) || '20', 10)));
    const skip = (page - 1) * limit;

    // Build authorization-aware query
    const query: any = {};

    if (scope === 'trash') {
      // Trash can only be viewed by the owner
      query.ownerId = new Types.ObjectId(user.userId);
      query.deletedAt = { $ne: null };
    } else {
      query.deletedAt = null;

      if (scope === 'mine') {
        query.ownerId = new Types.ObjectId(user.userId);
      } else if (scope === 'shared') {
        // Find documents explicitly shared with current user
        const now = new Date();
        const activePermissions = await DocumentPermission.find({
          userId: user.userId,
          isActive: true,
          $or: [{ expiresAt: null }, { expiresAt: { $gt: now } }],
        }).select('documentId');

        const sharedDocIds = activePermissions.map((p) => p.documentId);
        query._id = { $in: sharedDocIds };
      } else {
        // 'all': For normal users, only own documents + shared documents
        // For admin users: they can see all documents metadata in the system
        if (user.role === 'admin') {
          // Admin can see all system document metadata
        } else {
          const now = new Date();
          const activePermissions = await DocumentPermission.find({
            userId: user.userId,
            isActive: true,
            $or: [{ expiresAt: null }, { expiresAt: { $gt: now } }],
          }).select('documentId');

          const sharedDocIds = activePermissions.map((p) => p.documentId);
          query.$or = [
            { ownerId: new Types.ObjectId(user.userId) },
            { _id: { $in: sharedDocIds } },
          ];
        }
      }
    }

    if (category) query.category = category;
    if (sensitivity) query.sensitivity = sensitivity;
    if (search && search.trim()) {
      query.$text = { $search: search.trim() };
    }

    const [documents, total] = await Promise.all([
      DocumentModel.find(query)
        .populate('ownerId', 'name email')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      DocumentModel.countDocuments(query),
    ]);

    // Attach user's permission level for each document
    const formattedDocs = await Promise.all(
      documents.map(async (doc: any) => {
        let userAccess: 'owner' | 'edit' | 'read' | 'admin_meta' = 'read';
        if (doc.ownerId?._id?.toString() === user.userId || doc.ownerId?.toString() === user.userId) {
          userAccess = 'owner';
        } else if (user.role === 'admin') {
          userAccess = 'admin_meta';
        } else {
          const perm = await getActivePermission(doc._id.toString(), user.userId);
          if (perm) {
            userAccess = perm.permission;
          }
        }

        return {
          id: doc._id,
          title: doc.title,
          description: doc.description,
          category: doc.category,
          originalFilename: doc.originalFilename,
          mimeType: doc.mimeType,
          fileSize: doc.fileSize,
          sha256Checksum: doc.sha256Checksum,
          sensitivity: doc.sensitivity,
          version: doc.version,
          deletedAt: doc.deletedAt,
          createdAt: doc.createdAt,
          updatedAt: doc.updatedAt,
          owner: doc.ownerId
            ? {
                id: doc.ownerId._id || doc.ownerId,
                name: doc.ownerId.name || 'Unknown',
                email: doc.ownerId.email || '',
              }
            : null,
          userAccess,
        };
      })
    );

    res.status(200).json({
      success: true,
      data: {
        documents: formattedDocs,
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getDocumentById(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;

    const document = await DocumentModel.findById(id).populate('ownerId', 'name email');
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const authCheck = await canReadDocument(user, document);
    if (!authCheck.allowed) {
      await auditService.recordDenied('access.denied', authCheck.reason || 'Unauthorized document view', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: authCheck.reason, correlationId: req.correlationId },
      });
      return;
    }

    await auditService.recordSuccess('document.view', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      metadata: { title: document.title },
    });

    let userAccess: 'owner' | 'edit' | 'read' | 'admin_meta' = 'read';
    if (document.ownerId._id.toString() === user.userId) {
      userAccess = 'owner';
    } else if (authCheck.activePermission) {
      userAccess = authCheck.activePermission.permission;
    } else if (user.role === 'admin') {
      userAccess = 'admin_meta';
    }

    res.status(200).json({
      success: true,
      data: {
        document: {
          id: document._id,
          title: document.title,
          description: document.description,
          category: document.category,
          originalFilename: document.originalFilename,
          mimeType: document.mimeType,
          fileSize: document.fileSize,
          sha256Checksum: document.sha256Checksum,
          sensitivity: document.sensitivity,
          version: document.version,
          deletedAt: document.deletedAt,
          createdAt: document.createdAt,
          updatedAt: document.updatedAt,
          owner: {
            id: (document.ownerId as any)._id,
            name: (document.ownerId as any).name,
            email: (document.ownerId as any).email,
          },
          userAccess,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function downloadDocument(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const authCheck = await canDownloadDocument(user, document);
    if (!authCheck.allowed) {
      await auditService.recordDenied(
        'document.download',
        authCheck.reason || 'Unauthorized download attempt',
        {
          actorId: user.userId,
          actorEmail: user.email,
          actorRole: user.role,
          documentId: document._id,
          correlationId: req.correlationId,
          ipAddress: req.ip,
          userAgent: req.headers['user-agent'],
          metadata: { title: document.title },
        }
      );

      res.status(403).json({
        success: false,
        error: {
          code: 'FORBIDDEN',
          message: authCheck.reason,
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // Verify storage file exists
    const exists = await fileStorageService.fileExists(document.storageKey);
    if (!exists) {
      res.status(404).json({
        success: false,
        error: {
          code: 'FILE_NOT_FOUND_ON_DISK',
          message: 'The requested document file could not be located in secure storage.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // Record audit event for authorized download
    await auditService.recordSuccess('document.download', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      metadata: {
        title: document.title,
        fileSize: document.fileSize,
        checksum: document.sha256Checksum,
      },
    });

    // Stream download with security headers
    const safeFilename = encodeURIComponent(document.originalFilename);
    res.setHeader('Content-Type', document.mimeType);
    res.setHeader('Content-Length', document.fileSize);
    res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"; filename*=UTF-8''${safeFilename}`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cache-Control', 'private, no-cache, no-store, must-revalidate');

    const stream = fileStorageService.getFileStream(document.storageKey);
    stream.pipe(res);
  } catch (error) {
    next(error);
  }
}

export async function updateDocumentMetadata(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;
    const validated = documentUpdateSchema.parse(req.body);

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const authCheck = await canEditDocument(user, document);
    if (!authCheck.allowed) {
      await auditService.recordDenied('document.update_metadata', authCheck.reason || 'Edit permission denied', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: authCheck.reason, correlationId: req.correlationId },
      });
      return;
    }

    const previousData = {
      title: document.title,
      description: document.description,
      category: document.category,
      sensitivity: document.sensitivity,
    };

    if (validated.title !== undefined) document.title = validated.title;
    if (validated.description !== undefined) document.description = validated.description;
    if (validated.category !== undefined) document.category = validated.category;
    if (validated.sensitivity !== undefined) document.sensitivity = validated.sensitivity;

    await document.save();

    await auditService.recordSuccess('document.update_metadata', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      metadata: { previous: previousData, updated: validated },
    });

    res.status(200).json({
      success: true,
      data: { document },
    });
  } catch (error) {
    next(error);
  }
}

export async function getDocumentVersions(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const authCheck = await canReadDocument(user, document);
    if (!authCheck.allowed) {
      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: authCheck.reason, correlationId: req.correlationId },
      });
      return;
    }

    const versions = await DocumentVersion.find({ documentId: document._id })
      .populate('changedBy', 'name email')
      .sort({ versionNumber: -1 });

    res.status(200).json({
      success: true,
      data: { versions },
    });
  } catch (error) {
    next(error);
  }
}

export async function uploadNewVersion(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;
    const file = req.file;

    if (!file) {
      res.status(400).json({
        success: false,
        error: { code: 'FILE_REQUIRED', message: 'Version file upload is required.' },
      });
      return;
    }

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const authCheck = await canEditDocument(user, document);
    if (!authCheck.allowed) {
      await auditService.recordDenied('document.version_create', authCheck.reason || 'Cannot upload version', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: authCheck.reason, correlationId: req.correlationId },
      });
      return;
    }

    // Validate magic bytes
    const validationResult = validateUploadedBuffer(file.buffer, file.originalname, file.mimetype);
    if (!validationResult.isValid) {
      res.status(400).json({
        success: false,
        error: { code: 'INVALID_FILE', message: validationResult.errorMessage },
      });
      return;
    }

    const checksum = calculateSha256(file.buffer);
    const storageKey = generateStorageKey();
    await fileStorageService.saveFile(storageKey, file.buffer);

    const nextVersionNumber = document.version + 1;

    document.version = nextVersionNumber;
    document.storageKey = storageKey;
    document.sha256Checksum = checksum;
    document.fileSize = file.size;
    document.originalFilename = file.originalname;
    document.mimeType = validationResult.detectedMimeType || file.mimetype;
    await document.save();

    const versionDoc = new DocumentVersion({
      documentId: document._id,
      versionNumber: nextVersionNumber,
      storageKey,
      checksum,
      changedBy: new Types.ObjectId(user.userId),
      fileSize: file.size,
      mimeType: document.mimeType,
      originalFilename: file.originalname,
      description: req.body.description || `Updated to version ${nextVersionNumber}`,
    });
    await versionDoc.save();

    await auditService.recordSuccess('document.version_create', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      metadata: {
        versionNumber: nextVersionNumber,
        checksum,
        fileSize: file.size,
      },
    });

    res.status(201).json({
      success: true,
      data: { document, version: versionDoc },
    });
  } catch (error) {
    next(error);
  }
}

export async function deleteDocument(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;
    const isPermanent = req.query.permanent === 'true';

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    if (isPermanent) {
      const purgeCheck = canPurgeDocument(user, document);
      if (!purgeCheck.allowed) {
        await auditService.recordDenied('document.retention_purge', purgeCheck.reason || 'Purge not allowed', {
          actorId: user.userId,
          actorEmail: user.email,
          actorRole: user.role,
          documentId: document._id,
          correlationId: req.correlationId,
        });

        res.status(403).json({
          success: false,
          error: { code: 'FORBIDDEN', message: purgeCheck.reason, correlationId: req.correlationId },
        });
        return;
      }

      // Permanent purge: remove file and records
      await fileStorageService.deleteFile(document.storageKey);
      await DocumentVersion.deleteMany({ documentId: document._id });
      await DocumentPermission.deleteMany({ documentId: document._id });
      await DocumentModel.findByIdAndDelete(document._id);

      await auditService.recordSuccess('document.retention_purge', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
        metadata: { title: document.title },
      });

      res.status(200).json({
        success: true,
        data: { message: 'Document permanently purged from retention.' },
      });
      return;
    }

    // Soft delete
    const deleteCheck = canDeleteDocument(user, document);
    if (!deleteCheck.allowed) {
      await auditService.recordDenied('document.delete', deleteCheck.reason || 'Delete not allowed', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: deleteCheck.reason, correlationId: req.correlationId },
      });
      return;
    }

    document.deletedAt = new Date();
    await document.save();

    await auditService.recordSuccess('document.delete', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      correlationId: req.correlationId,
      metadata: { title: document.title },
    });

    res.status(200).json({
      success: true,
      data: { message: 'Document moved to trash.', document },
    });
  } catch (error) {
    next(error);
  }
}

export async function restoreDocument(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = req.user!;
    const { id } = req.params;

    const document = await DocumentModel.findById(id);
    if (!document) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'Document not found.', correlationId: req.correlationId },
      });
      return;
    }

    const deleteCheck = canDeleteDocument(user, document);
    if (!deleteCheck.allowed) {
      await auditService.recordDenied('document.restore', deleteCheck.reason || 'Restore not allowed', {
        actorId: user.userId,
        actorEmail: user.email,
        actorRole: user.role,
        documentId: document._id,
        correlationId: req.correlationId,
      });

      res.status(403).json({
        success: false,
        error: { code: 'FORBIDDEN', message: deleteCheck.reason, correlationId: req.correlationId },
      });
      return;
    }

    document.deletedAt = null;
    await document.save();

    await auditService.recordSuccess('document.restore', {
      actorId: user.userId,
      actorEmail: user.email,
      actorRole: user.role,
      documentId: document._id,
      correlationId: req.correlationId,
      metadata: { title: document.title },
    });

    res.status(200).json({
      success: true,
      data: { message: 'Document restored successfully.', document },
    });
  } catch (error) {
    next(error);
  }
}
