import { Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import { User } from '../models/User';
import { ENV } from '../config/env';
import { auditService } from '../services/auditService';
import {
  registerSchema,
  loginSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from '../validators';
import { AuthenticatedRequest, AuthUserPayload } from '../types';

function createToken(payload: AuthUserPayload): string {
  return jwt.sign(payload, ENV.JWT_SECRET, {
    expiresIn: ENV.JWT_EXPIRES_IN as any,
  });
}

function setAuthCookie(res: Response, token: string): void {
  res.cookie(ENV.COOKIE_NAME, token, {
    httpOnly: true,
    secure: ENV.COOKIE_SECURE,
    sameSite: 'lax',
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
  });
}

export async function register(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const validated = registerSchema.parse(req.body);

    // Check if user already exists
    const existing = await User.findOne({ email: validated.email });
    if (existing) {
      res.status(400).json({
        success: false,
        error: {
          code: 'EMAIL_ALREADY_EXISTS',
          message: 'An account with this email address already exists.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    const salt = await bcrypt.genSalt(12);
    const passwordHash = await bcrypt.hash(validated.password, salt);

    const user = new User({
      name: validated.name,
      email: validated.email,
      passwordHash,
      role: validated.role || 'owner',
      status: 'active',
      lastLoginAt: new Date(),
    });

    await user.save();

    const authPayload: AuthUserPayload = {
      userId: user._id.toString(),
      email: user.email,
      role: user.role,
      name: user.name,
    };

    const token = createToken(authPayload);
    setAuthCookie(res, token);

    await auditService.recordSuccess('auth.register', {
      actorId: user._id,
      actorEmail: user.email,
      actorRole: user.role,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
      metadata: { role: user.role },
    });

    res.status(201).json({
      success: true,
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          status: user.status,
          createdAt: user.createdAt,
        },
        token, // Provided for API clients/tests that use Bearer header
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function login(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const validated = loginSchema.parse(req.body);

    const user = await User.findOne({ email: validated.email }).select('+passwordHash +status');
    if (!user) {
      await auditService.recordDenied('auth.login.failed', 'User not found', {
        actorEmail: validated.email,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      res.status(401).json({
        success: false,
        error: {
          code: 'INVALID_CREDENTIALS',
          message: 'Invalid email or password.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // Verify status
    if (user.status !== 'active') {
      await auditService.recordDenied('auth.login.failed', 'Account disabled', {
        actorId: user._id,
        actorEmail: user.email,
        actorRole: user.role,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      res.status(403).json({
        success: false,
        error: {
          code: 'ACCOUNT_DISABLED',
          message: 'This account has been deactivated. Contact an administrator.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // Compare password
    const isMatch = await bcrypt.compare(validated.password, user.passwordHash);
    if (!isMatch) {
      await auditService.recordDenied('auth.login.failed', 'Password mismatch', {
        actorId: user._id,
        actorEmail: user.email,
        actorRole: user.role,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });

      res.status(401).json({
        success: false,
        error: {
          code: 'INVALID_CREDENTIALS',
          message: 'Invalid email or password.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    // Update last login
    user.lastLoginAt = new Date();
    await user.save();

    const authPayload: AuthUserPayload = {
      userId: user._id.toString(),
      email: user.email,
      role: user.role,
      name: user.name,
    };

    const token = createToken(authPayload);
    setAuthCookie(res, token);

    await auditService.recordSuccess('auth.login.success', {
      actorId: user._id,
      actorEmail: user.email,
      actorRole: user.role,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
    });

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          status: user.status,
          lastLoginAt: user.lastLoginAt,
        },
        token,
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function logout(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (req.user) {
      await auditService.recordSuccess('auth.logout', {
        actorId: req.user.userId,
        actorEmail: req.user.email,
        actorRole: req.user.role,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
    }

    res.clearCookie(ENV.COOKIE_NAME, {
      httpOnly: true,
      secure: ENV.COOKIE_SECURE,
      sameSite: 'lax',
    });

    res.status(200).json({
      success: true,
      data: { message: 'Successfully logged out.' },
    });
  } catch (error) {
    next(error);
  }
}

export async function getMe(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const user = await User.findById(req.user!.userId);
    if (!user) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'User record not found.' },
      });
      return;
    }

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          status: user.status,
          createdAt: user.createdAt,
          lastLoginAt: user.lastLoginAt,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function forgotPassword(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const validated = forgotPasswordSchema.parse(req.body);

    const user = await User.findOne({ email: validated.email });
    let resetTokenPlain: string | null = null;

    if (user && user.status === 'active') {
      resetTokenPlain = crypto.randomBytes(32).toString('hex');
      const tokenHash = crypto.createHash('sha256').update(resetTokenPlain).digest('hex');

      user.passwordResetTokenHash = tokenHash;
      user.passwordResetExpires = new Date(Date.now() + 60 * 60 * 1000); // 1 hour
      await user.save();

      await auditService.recordSuccess('auth.password_reset_request', {
        actorId: user._id,
        actorEmail: user.email,
        actorRole: user.role,
        correlationId: req.correlationId,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      });
    }

    // Always return constant message to avoid email enumeration
    res.status(200).json({
      success: true,
      data: {
        message: 'If the email exists and is active, a password reset token has been issued.',
        // For local development convenience, return resetToken if in development
        ...(process.env.NODE_ENV !== 'production' && resetTokenPlain ? { debugToken: resetTokenPlain } : {}),
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function resetPassword(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const validated = resetPasswordSchema.parse(req.body);
    const tokenHash = crypto.createHash('sha256').update(validated.token).digest('hex');

    const user = await User.findOne({
      passwordResetTokenHash: tokenHash,
      passwordResetExpires: { $gt: new Date() },
    }).select('+passwordResetTokenHash +passwordResetExpires');

    if (!user) {
      res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_TOKEN',
          message: 'Password reset token is invalid or has expired.',
          correlationId: req.correlationId,
        },
      });
      return;
    }

    const salt = await bcrypt.genSalt(12);
    user.passwordHash = await bcrypt.hash(validated.newPassword, salt);
    user.passwordResetTokenHash = undefined;
    user.passwordResetExpires = undefined;
    await user.save();

    await auditService.recordSuccess('auth.password_reset_success', {
      actorId: user._id,
      actorEmail: user.email,
      actorRole: user.role,
      correlationId: req.correlationId,
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'],
    });

    res.status(200).json({
      success: true,
      data: { message: 'Password has been reset successfully. You may now log in.' },
    });
  } catch (error) {
    next(error);
  }
}
