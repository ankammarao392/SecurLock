import { Response, NextFunction } from 'express';
import bcrypt from 'bcryptjs';
import { User } from '../models/User';
import { DocumentModel } from '../models/Document';
import { AuditLog } from '../models/AuditLog';
import { AuthenticatedRequest } from '../types';
import { adminCreateUserSchema, adminUpdateUserSchema } from '../validators';
import { auditService } from '../services/auditService';

export async function getAdminDashboard(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);

    const [
      totalUsers,
      activeUsers,
      totalDocuments,
      storageStats,
      sensitivityStats,
      audit24hCount,
      denied24hCount,
      recentAlerts,
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ status: 'active' }),
      DocumentModel.countDocuments({ deletedAt: null }),
      DocumentModel.aggregate([
        { $match: { deletedAt: null } },
        { $group: { _id: null, totalBytes: { $sum: '$fileSize' } } },
      ]),
      DocumentModel.aggregate([
        { $match: { deletedAt: null } },
        { $group: { _id: '$sensitivity', count: { $sum: 1 } } },
      ]),
      AuditLog.countDocuments({ timestamp: { $gte: oneDayAgo } }),
      AuditLog.countDocuments({ timestamp: { $gte: oneDayAgo }, outcome: 'denied' }),
      AuditLog.find({ outcome: 'denied' })
        .sort({ timestamp: -1 })
        .limit(6)
        .populate('actorId', 'name email')
        .populate('documentId', 'title')
        .lean(),
    ]);

    const totalStorageBytes = storageStats[0]?.totalBytes || 0;

    res.status(200).json({
      success: true,
      data: {
        metrics: {
          totalUsers,
          activeUsers,
          totalDocuments,
          totalStorageBytes,
          audit24hCount,
          denied24hCount,
        },
        sensitivityDistribution: sensitivityStats.map((item) => ({
          sensitivity: item._id,
          count: item.count,
        })),
        recentAlerts: recentAlerts.map((a: any) => ({
          id: a._id,
          timestamp: a.timestamp,
          action: a.action,
          reason: a.reason,
          actorEmail: a.actorEmail || (a.actorId ? a.actorId.email : 'Anonymous'),
          ipAddress: a.ipAddress,
          documentTitle: a.documentId ? a.documentId.title : null,
        })),
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function getAdminUsers(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { role, status, search } = req.query;
    const page = Math.max(1, parseInt((req.query.page as string) || '1', 10));
    const limit = Math.min(100, Math.max(1, parseInt((req.query.limit as string) || '20', 10)));
    const skip = (page - 1) * limit;

    const query: any = {};
    if (role) query.role = role;
    if (status) query.status = status;
    if (search && typeof search === 'string' && search.trim()) {
      const term = search.trim();
      query.$or = [
        { name: { $regex: term, $options: 'i' } },
        { email: { $regex: term, $options: 'i' } },
      ];
    }

    const [users, total] = await Promise.all([
      User.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
      User.countDocuments(query),
    ]);

    res.status(200).json({
      success: true,
      data: {
        users: users.map((u) => ({
          id: u._id,
          name: u.name,
          email: u.email,
          role: u.role,
          status: u.status,
          createdAt: u.createdAt,
          lastLoginAt: u.lastLoginAt,
        })),
        pagination: {
          page,
          limit,
          total,
          totalPages: Math.ceil(total / limit),
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function createAdminUser(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const admin = req.user!;
    const validated = adminCreateUserSchema.parse(req.body);

    const existing = await User.findOne({ email: validated.email });
    if (existing) {
      res.status(400).json({
        success: false,
        error: { code: 'EMAIL_EXISTS', message: 'User with this email already exists.' },
      });
      return;
    }

    const salt = await bcrypt.genSalt(12);
    const passwordHash = await bcrypt.hash(validated.password, salt);

    const newUser = new User({
      name: validated.name,
      email: validated.email,
      passwordHash,
      role: validated.role,
      status: validated.status || 'active',
    });

    await newUser.save();

    await auditService.recordSuccess('user.create', {
      actorId: admin.userId,
      actorEmail: admin.email,
      actorRole: admin.role,
      targetUserId: newUser._id,
      correlationId: req.correlationId,
      metadata: { createdEmail: newUser.email, assignedRole: newUser.role },
    });

    res.status(201).json({
      success: true,
      data: {
        user: {
          id: newUser._id,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
          status: newUser.status,
          createdAt: newUser.createdAt,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

export async function updateAdminUser(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const admin = req.user!;
    const { id } = req.params;
    const validated = adminUpdateUserSchema.parse(req.body);

    const user = await User.findById(id);
    if (!user) {
      res.status(404).json({
        success: false,
        error: { code: 'NOT_FOUND', message: 'User not found.', correlationId: req.correlationId },
      });
      return;
    }

    // Prevent admin from locking themselves out
    if (user._id.toString() === admin.userId && validated.status === 'disabled') {
      res.status(400).json({
        success: false,
        error: { code: 'CANNOT_DISABLE_SELF', message: 'You cannot disable your own administrator account.' },
      });
      return;
    }

    if (validated.name !== undefined) user.name = validated.name;

    if (validated.role !== undefined && validated.role !== user.role) {
      const oldRole = user.role;
      user.role = validated.role;
      await auditService.recordSuccess('user.role_change', {
        actorId: admin.userId,
        actorEmail: admin.email,
        actorRole: admin.role,
        targetUserId: user._id,
        correlationId: req.correlationId,
        metadata: { fromRole: oldRole, toRole: validated.role, targetEmail: user.email },
      });
    }

    if (validated.status !== undefined && validated.status !== user.status) {
      const oldStatus = user.status;
      user.status = validated.status;
      await auditService.recordSuccess('user.status_change', {
        actorId: admin.userId,
        actorEmail: admin.email,
        actorRole: admin.role,
        targetUserId: user._id,
        correlationId: req.correlationId,
        metadata: { fromStatus: oldStatus, toStatus: validated.status, targetEmail: user.email },
      });
    }

    if (validated.password) {
      const salt = await bcrypt.genSalt(12);
      user.passwordHash = await bcrypt.hash(validated.password, salt);
    }

    await user.save();

    res.status(200).json({
      success: true,
      data: {
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          status: user.status,
          updatedAt: user.updatedAt,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}
