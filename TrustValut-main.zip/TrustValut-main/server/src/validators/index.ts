import { z } from 'zod';

export const registerSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100),
  email: z.string().email('Invalid email address').toLowerCase().trim(),
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(128)
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
  role: z.enum(['admin', 'owner', 'viewer']).optional().default('owner'),
});

export const loginSchema = z.object({
  email: z.string().email('Invalid email address').toLowerCase().trim(),
  password: z.string().min(1, 'Password is required'),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email('Invalid email address').toLowerCase().trim(),
});

export const resetPasswordSchema = z.object({
  token: z.string().min(1, 'Reset token is required'),
  newPassword: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(128)
    .regex(/[A-Z]/, 'Password must contain at least one uppercase letter')
    .regex(/[a-z]/, 'Password must contain at least one lowercase letter')
    .regex(/[0-9]/, 'Password must contain at least one number'),
});

export const documentUploadSchema = z.object({
  title: z.string().min(1, 'Title is required').max(255).trim(),
  description: z.string().max(2000).optional().default(''),
  category: z.enum([
    'Legal',
    'Financial',
    'Human Resources',
    'Security & Compliance',
    'Engineering',
    'Executive',
    'Operations',
    'Other',
  ]).optional().default('Other'),
  sensitivity: z.enum(['Public', 'Internal', 'Confidential', 'Restricted']).optional().default('Internal'),
});

export const documentUpdateSchema = z.object({
  title: z.string().min(1, 'Title is required').max(255).trim().optional(),
  description: z.string().max(2000).optional(),
  category: z.enum([
    'Legal',
    'Financial',
    'Human Resources',
    'Security & Compliance',
    'Engineering',
    'Executive',
    'Operations',
    'Other',
  ]).optional(),
  sensitivity: z.enum(['Public', 'Internal', 'Confidential', 'Restricted']).optional(),
});

export const grantPermissionSchema = z.object({
  userEmail: z.string().email('Invalid user email address').toLowerCase().trim().optional(),
  userId: z.string().optional(),
  permission: z.enum(['read', 'edit']),
  expiresAt: z.string().datetime({ offset: true }).nullable().optional(),
}).refine((data) => data.userEmail || data.userId, {
  message: 'Either userEmail or userId must be provided',
  path: ['userEmail'],
});

export const updatePermissionSchema = z.object({
  permission: z.enum(['read', 'edit']).optional(),
  expiresAt: z.string().datetime({ offset: true }).nullable().optional(),
});

export const adminCreateUserSchema = z.object({
  name: z.string().min(2).max(100).trim(),
  email: z.string().email().toLowerCase().trim(),
  password: z.string().min(8).max(128),
  role: z.enum(['admin', 'owner', 'viewer']),
  status: z.enum(['active', 'disabled']).optional().default('active'),
});

export const adminUpdateUserSchema = z.object({
  name: z.string().min(2).max(100).trim().optional(),
  role: z.enum(['admin', 'owner', 'viewer']).optional(),
  status: z.enum(['active', 'disabled']).optional(),
  password: z.string().min(8).max(128).optional(),
});
