import crypto from 'crypto';
import path from 'path';

export interface FileValidationResult {
  isValid: boolean;
  detectedMimeType?: string;
  errorMessage?: string;
}

export interface AllowedFileType {
  extension: string;
  mimeTypes: string[];
  validateSignature: (buffer: Buffer) => boolean;
}

/**
 * Magic byte signature verifiers for supported enterprise document types
 */
export const ALLOWED_FILE_TYPES: Record<string, AllowedFileType> = {
  pdf: {
    extension: '.pdf',
    mimeTypes: ['application/pdf'],
    validateSignature: (buffer: Buffer) => {
      // PDF starts with %PDF- (0x25 0x50 0x44 0x46 0x2D)
      if (buffer.length < 5) return false;
      return (
        buffer[0] === 0x25 &&
        buffer[1] === 0x50 &&
        buffer[2] === 0x44 &&
        buffer[3] === 0x46 &&
        buffer[4] === 0x2d
      );
    },
  },
  png: {
    extension: '.png',
    mimeTypes: ['image/png'],
    validateSignature: (buffer: Buffer) => {
      // PNG signature: 89 50 4E 47 0D 0A 1A 0A
      if (buffer.length < 8) return false;
      return (
        buffer[0] === 0x89 &&
        buffer[1] === 0x50 &&
        buffer[2] === 0x4e &&
        buffer[3] === 0x47 &&
        buffer[4] === 0x0d &&
        buffer[5] === 0x0a &&
        buffer[6] === 0x1a &&
        buffer[7] === 0x0a
      );
    },
  },
  jpeg: {
    extension: '.jpg',
    mimeTypes: ['image/jpeg', 'image/jpg'],
    validateSignature: (buffer: Buffer) => {
      // JPEG starts with FF D8 FF
      if (buffer.length < 3) return false;
      return buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff;
    },
  },
  docx: {
    extension: '.docx',
    mimeTypes: [
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/zip',
      'application/x-zip-compressed',
    ],
    validateSignature: (buffer: Buffer) => {
      // ZIP format magic bytes: PK\x03\x04 (50 4B 03 04)
      if (buffer.length < 4) return false;
      return (
        buffer[0] === 0x50 &&
        buffer[1] === 0x4b &&
        buffer[2] === 0x03 &&
        buffer[3] === 0x04
      );
    },
  },
  xlsx: {
    extension: '.xlsx',
    mimeTypes: [
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/zip',
      'application/x-zip-compressed',
    ],
    validateSignature: (buffer: Buffer) => {
      // ZIP format magic bytes: PK\x03\x04
      if (buffer.length < 4) return false;
      return (
        buffer[0] === 0x50 &&
        buffer[1] === 0x4b &&
        buffer[2] === 0x03 &&
        buffer[3] === 0x04
      );
    },
  },
  pptx: {
    extension: '.pptx',
    mimeTypes: [
      'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      'application/zip',
      'application/x-zip-compressed',
    ],
    validateSignature: (buffer: Buffer) => {
      // ZIP format magic bytes: PK\x03\x04
      if (buffer.length < 4) return false;
      return (
        buffer[0] === 0x50 &&
        buffer[1] === 0x4b &&
        buffer[2] === 0x03 &&
        buffer[3] === 0x04
      );
    },
  },
};

/**
 * Validates file buffer, declared extension, and declared MIME type against magic byte signatures.
 * Rejects mismatched or spoofed file uploads.
 */
export function validateUploadedBuffer(
  buffer: Buffer,
  originalFilename: string,
  declaredMimeType: string,
  maxSizeBytes: number = 10 * 1024 * 1024
): FileValidationResult {
  if (!buffer || buffer.length === 0) {
    return { isValid: false, errorMessage: 'File payload is empty or missing.' };
  }

  if (buffer.length > maxSizeBytes) {
    return {
      isValid: false,
      errorMessage: `File size exceeds the maximum limit of ${maxSizeBytes / (1024 * 1024)} MB.`,
    };
  }

  // Sanitize filename & extract extension
  const safeBaseName = path.basename(originalFilename);
  const ext = path.extname(safeBaseName).toLowerCase().replace('.', '');

  // Check if extension is supported
  const extKey = ext === 'jpeg' ? 'jpeg' : ext === 'jpg' ? 'jpeg' : ext;
  const config = ALLOWED_FILE_TYPES[extKey];

  if (!config) {
    return {
      isValid: false,
      errorMessage: `Unsupported file extension '.${ext}'. Supported formats are: PDF, DOCX, XLSX, PPTX, PNG, JPEG.`,
    };
  }

  // Validate magic bytes
  const hasValidSignature = config.validateSignature(buffer);
  if (!hasValidSignature) {
    return {
      isValid: false,
      errorMessage: `File content signature (magic bytes) does not match declared extension '.${ext}'. Upload rejected.`,
    };
  }

  return {
    isValid: true,
    detectedMimeType: config.mimeTypes[0],
  };
}

/**
 * Calculates SHA-256 cryptographic checksum of buffer
 */
export function calculateSha256(buffer: Buffer): string {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

/**
 * Generates an unpredictable, cryptographically random storage key
 */
export function generateStorageKey(): string {
  return crypto.randomUUID();
}
