import { Request } from 'express';

export type UserRole = 'admin' | 'owner' | 'viewer';
export type UserStatus = 'active' | 'disabled';

export type DocumentSensitivity = 'Public' | 'Internal' | 'Confidential' | 'Restricted';
export type DocumentCategory = 'Legal' | 'Financial' | 'Human Resources' | 'Security & Compliance' | 'Engineering' | 'Executive' | 'Operations' | 'Other';

export type PermissionType = 'read' | 'edit';

export type AuditAction =
  | 'auth.login.success'
  | 'auth.login.failed'
  | 'auth.logout'
  | 'auth.register'
  | 'auth.password_reset_request'
  | 'auth.password_reset_success'
  | 'document.upload'
  | 'document.view'
  | 'document.download'
  | 'document.update_metadata'
  | 'document.version_create'
  | 'document.delete'
  | 'document.restore'
  | 'document.retention_purge'
  | 'permission.grant'
  | 'permission.update'
  | 'permission.revoke'
  | 'user.create'
  | 'user.role_change'
  | 'user.status_change'
  | 'access.denied'
  | 'admin.audit_export';

export type AuditOutcome = 'success' | 'denied';

export interface AuthUserPayload {
  userId: string;
  email: string;
  role: UserRole;
  name: string;
}

export interface AuthenticatedRequest extends Request {
  user?: AuthUserPayload;
  correlationId?: string;
}
