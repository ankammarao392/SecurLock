import { describe, it, expect, beforeAll, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import { MongoMemoryServer } from 'mongodb-memory-server';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { createApp } from '../src/app';
import { User } from '../src/models/User';
import { DocumentModel } from '../src/models/Document';
import { DocumentPermission } from '../src/models/DocumentPermission';
import { AuditLog } from '../src/models/AuditLog';
import { fileStorageService } from '../src/services/fileStorageService';
import { calculateSha256, generateStorageKey } from '../src/utils/fileValidator';
import jwt from 'jsonwebtoken';
import { ENV } from '../src/config/env';

let mongod: MongoMemoryServer;
let app: any;

// Test user credentials & IDs
let adminToken: string;
let userAToken: string;
let userBToken: string;
let viewerToken: string;

let userAId: string;
let userBId: string;
let viewerId: string;
let adminId: string;

let userADocId: string;
let userADocStorageKey: string;

// Helper to generate minimal valid PDF buffer
function makeTestPdfBuffer(text: string): Buffer {
  return Buffer.from(
    `%PDF-1.4\n1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] >> endobj\nxref\n0 4\ntrailer << /Size 4 /Root 1 0 R >>\nstartxref\n180\n%%EOF\n% ${text}`,
    'utf-8'
  );
}

beforeAll(async () => {
  mongod = await MongoMemoryServer.create();
  const uri = mongod.getUri();
  await mongoose.connect(uri);
  app = createApp();
});

afterAll(async () => {
  await mongoose.disconnect();
  await mongod.stop();
});

beforeEach(async () => {
  // Clear all collections safely in test environment
  await Promise.all([
    User.deleteMany({}),
    DocumentModel.deleteMany({}),
    DocumentPermission.deleteMany({}),
    (AuditLog as any).deleteMany({}, { skipAuditLock: true }),
  ]);

  const salt = await bcrypt.genSalt(10);
  const passwordHash = await bcrypt.hash('SecurePassword123!', salt);

  // Create Users
  const [adminUser, userA, userB, viewerUser] = await Promise.all([
    User.create({
      name: 'System Admin',
      email: 'admin@test.local',
      passwordHash,
      role: 'admin',
      status: 'active',
    }),
    User.create({
      name: 'Alice Owner',
      email: 'alice@test.local',
      passwordHash,
      role: 'owner',
      status: 'active',
    }),
    User.create({
      name: 'Bob Owner',
      email: 'bob@test.local',
      passwordHash,
      role: 'owner',
      status: 'active',
    }),
    User.create({
      name: 'Charlie Viewer',
      email: 'charlie@test.local',
      passwordHash,
      role: 'viewer',
      status: 'active',
    }),
  ]);

  adminId = adminUser._id.toString();
  userAId = userA._id.toString();
  userBId = userB._id.toString();
  viewerId = viewerUser._id.toString();

  // Generate authentication tokens directly with valid JWT secret
  adminToken = jwt.sign({ userId: adminId, email: adminUser.email, role: adminUser.role, name: adminUser.name }, ENV.JWT_SECRET);
  userAToken = jwt.sign({ userId: userAId, email: userA.email, role: userA.role, name: userA.name }, ENV.JWT_SECRET);
  userBToken = jwt.sign({ userId: userBId, email: userB.email, role: userB.role, name: userB.name }, ENV.JWT_SECRET);
  viewerToken = jwt.sign({ userId: viewerId, email: viewerUser.email, role: viewerUser.role, name: viewerUser.name }, ENV.JWT_SECRET);

  // Create User A's private document
  const pdfBuffer = makeTestPdfBuffer('User A Confidential Data');
  userADocStorageKey = generateStorageKey();
  await fileStorageService.saveFile(userADocStorageKey, pdfBuffer);

  const doc = await DocumentModel.create({
    title: "Alice's Secret Patent Application",
    description: 'Proprietary cryptographic algorithms',
    category: 'Engineering',
    originalFilename: 'patent_spec.pdf',
    storageKey: userADocStorageKey,
    mimeType: 'application/pdf',
    fileSize: pdfBuffer.length,
    sha256Checksum: calculateSha256(pdfBuffer),
    ownerId: userA._id,
    sensitivity: 'Restricted',
    version: 1,
    deletedAt: null,
  });

  userADocId = doc._id.toString();
});

describe('TrustVault Security Verification Test Suite', () => {
  // Scenario 1: Unauthenticated request cannot access protected endpoints
  it('1. Rejects unauthenticated requests with 401 Unauthorized', async () => {
    const res = await request(app).get('/api/documents');
    expect(res.status).toBe(401);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('UNAUTHENTICATED');
  });

  // Scenario 2: User A cannot read User B's private document
  it("2. User B cannot read User A's private document without explicit permission", async () => {
    const res = await request(app)
      .get(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${userBToken}`);

    expect(res.status).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  // Scenario 3: User A cannot download User B's private document
  it("3. User B cannot download User A's private document file stream", async () => {
    const res = await request(app)
      .get(`/api/documents/${userADocId}/download`)
      .set('Authorization', `Bearer ${userBToken}`);

    expect(res.status).toBe(403);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('FORBIDDEN');
  });

  // Scenario 4: User A cannot update or delete User B's document
  it("4. User B cannot update or delete User A's document", async () => {
    // Attempt metadata update
    const updateRes = await request(app)
      .patch(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${userBToken}`)
      .send({ title: 'Hacked Title' });

    expect(updateRes.status).toBe(403);

    // Attempt delete
    const deleteRes = await request(app)
      .delete(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${userBToken}`);

    expect(deleteRes.status).toBe(403);

    // Assert document remains unchanged
    const doc = await DocumentModel.findById(userADocId);
    expect(doc?.title).toBe("Alice's Secret Patent Application");
    expect(doc?.deletedAt).toBeNull();
  });

  // Scenario 5: Viewer with read permission can read and download
  it('5. Viewer with read permission can read metadata and download the authorized document', async () => {
    // Grant read permission
    await DocumentPermission.create({
      documentId: new mongoose.Types.ObjectId(userADocId),
      userId: new mongoose.Types.ObjectId(viewerId),
      permission: 'read',
      grantedBy: new mongoose.Types.ObjectId(userAId),
      isActive: true,
    });

    // Read metadata
    const readRes = await request(app)
      .get(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`);

    expect(readRes.status).toBe(200);
    expect(readRes.body.data.document.title).toBe("Alice's Secret Patent Application");

    // Download file
    const downloadRes = await request(app)
      .get(`/api/documents/${userADocId}/download`)
      .set('Authorization', `Bearer ${viewerToken}`);

    expect(downloadRes.status).toBe(200);
    expect(downloadRes.headers['content-type']).toContain('application/pdf');
    expect(downloadRes.headers['x-content-type-options']).toBe('nosniff');
  });

  // Scenario 6: Viewer with read permission cannot modify or delete
  it('6. Viewer with read permission cannot modify or delete the document', async () => {
    await DocumentPermission.create({
      documentId: new mongoose.Types.ObjectId(userADocId),
      userId: new mongoose.Types.ObjectId(viewerId),
      permission: 'read',
      grantedBy: new mongoose.Types.ObjectId(userAId),
      isActive: true,
    });

    const editRes = await request(app)
      .patch(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`)
      .send({ title: 'Tampered Title' });

    expect(editRes.status).toBe(403);

    const deleteRes = await request(app)
      .delete(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`);

    expect(deleteRes.status).toBe(403);
  });

  // Scenario 7: Editor with edit permission can perform edits but cannot delete another owner's document
  it('7. Editor with edit permission can edit metadata but cannot delete another owner\'s document', async () => {
    await DocumentPermission.create({
      documentId: new mongoose.Types.ObjectId(userADocId),
      userId: new mongoose.Types.ObjectId(viewerId),
      permission: 'edit',
      grantedBy: new mongoose.Types.ObjectId(userAId),
      isActive: true,
    });

    // Permitted edit
    const editRes = await request(app)
      .patch(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`)
      .send({ description: 'Updated by authorized editor Charlie' });

    expect(editRes.status).toBe(200);

    // Forbidden delete
    const deleteRes = await request(app)
      .delete(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`);

    expect(deleteRes.status).toBe(403);
  });

  // Scenario 8: Revoked users immediately lose read and download access
  it('8. Revoked users immediately lose read and download access on subsequent requests', async () => {
    const perm = await DocumentPermission.create({
      documentId: new mongoose.Types.ObjectId(userADocId),
      userId: new mongoose.Types.ObjectId(viewerId),
      permission: 'read',
      grantedBy: new mongoose.Types.ObjectId(userAId),
      isActive: true,
    });

    // Verify initial access
    const check1 = await request(app)
      .get(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`);
    expect(check1.status).toBe(200);

    // Revoke access as owner
    const revokeRes = await request(app)
      .delete(`/api/documents/${userADocId}/permissions/${perm._id}`)
      .set('Authorization', `Bearer ${userAToken}`);
    expect(revokeRes.status).toBe(200);

    // Immediate rejection on next request
    const check2 = await request(app)
      .get(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`);
    expect(check2.status).toBe(403);

    const downloadCheck = await request(app)
      .get(`/api/documents/${userADocId}/download`)
      .set('Authorization', `Bearer ${viewerToken}`);
    expect(downloadCheck.status).toBe(403);
  });

  // Scenario 9: Expired permission is rejected
  it('9. Expired permissions are automatically rejected', async () => {
    await DocumentPermission.create({
      documentId: new mongoose.Types.ObjectId(userADocId),
      userId: new mongoose.Types.ObjectId(viewerId),
      permission: 'read',
      grantedBy: new mongoose.Types.ObjectId(userAId),
      expiresAt: new Date(Date.now() - 60000), // 1 minute in the past
      isActive: true,
    });

    const res = await request(app)
      .get(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${viewerToken}`);

    expect(res.status).toBe(403);
  });

  // Scenario 10: Administrator can inspect audit records but cannot download confidential file contents without permission
  it('10. Administrator can query audit records but cannot download confidential files (Least Privilege)', async () => {
    // Admin queries audit log
    const auditRes = await request(app)
      .get('/api/audit')
      .set('Authorization', `Bearer ${adminToken}`);

    expect(auditRes.status).toBe(200);
    expect(auditRes.body.success).toBe(true);

    // Admin attempts to download Alice's private confidential document without permission
    const downloadRes = await request(app)
      .get(`/api/documents/${userADocId}/download`)
      .set('Authorization', `Bearer ${adminToken}`);

    // Administrator cannot bypass document confidentiality!
    expect(downloadRes.status).toBe(403);
  });

  // Scenario 11: A user cannot grant themselves permissions by modifying API payloads
  it('11. A user cannot grant themselves permissions to another user\'s document', async () => {
    const res = await request(app)
      .post(`/api/documents/${userADocId}/permissions`)
      .set('Authorization', `Bearer ${userBToken}`)
      .send({
        userId: userBId,
        permission: 'edit',
      });

    expect(res.status).toBe(403);
  });

  // Scenario 12: A user cannot alter another user\'s permissions
  it('12. Non-owner cannot grant or modify permissions for other users', async () => {
    const res = await request(app)
      .post(`/api/documents/${userADocId}/permissions`)
      .set('Authorization', `Bearer ${viewerToken}`)
      .send({
        userEmail: 'bob@test.local',
        permission: 'read',
      });

    expect(res.status).toBe(403);
  });

  // Scenario 13: Invalid file types, oversized uploads, and MIME/signature mismatches are rejected
  it('13. Rejects invalid magic bytes, spoofed extensions, and oversized uploads', async () => {
    // A fake PDF that is actually plain text (magic byte mismatch)
    const spoofedPdf = Buffer.from('This is a text file pretending to be a PDF', 'utf-8');

    const res = await request(app)
      .post('/api/documents')
      .set('Authorization', `Bearer ${userAToken}`)
      .field('title', 'Spoofed Document')
      .field('category', 'Legal')
      .attach('file', spoofedPdf, 'fake.pdf');

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error.code).toBe('INVALID_FILE');
    expect(res.body.error.message).toContain('signature (magic bytes) does not match');
  });

  // Scenario 14: Denied access attempts produce appropriate audit events
  it('14. Denied access attempts create audit events with outcome "denied"', async () => {
    await request(app)
      .get(`/api/documents/${userADocId}`)
      .set('Authorization', `Bearer ${userBToken}`);

    const deniedLogs = await AuditLog.find({
      actorId: new mongoose.Types.ObjectId(userBId),
      outcome: 'denied',
    });

    expect(deniedLogs.length).toBeGreaterThan(0);
    expect(deniedLogs[0].reason).toContain('Access denied');
  });

  // Scenario 15: Normal application APIs cannot edit or delete audit history
  it('15. Schema-level hooks protect audit logs from updates or deletions (Append-Only)', async () => {
    const log = await AuditLog.create({
      action: 'auth.login.success',
      actorId: new mongoose.Types.ObjectId(userAId),
      outcome: 'success',
      timestamp: new Date(),
    });

    // Attempting to update or delete via Mongoose query throws
    await expect(
      AuditLog.updateOne({ _id: log._id }, { action: 'tampered.action' })
    ).rejects.toThrow('Audit logs are append-only and cannot be modified');

    await expect(
      AuditLog.deleteOne({ _id: log._id })
    ).rejects.toThrow('Audit logs are append-only and cannot be deleted');
  });

  // Scenario 16: Disabled users cannot continue using an otherwise valid session
  it('16. Disabled users are immediately rejected even with an unexpired session token', async () => {
    // Deactivate user B
    await User.findByIdAndUpdate(userBId, { status: 'disabled' });

    // User B attempts to access API with previously valid token
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${userBToken}`);

    expect(res.status).toBe(403);
    expect(res.body.error.code).toBe('ACCOUNT_DISABLED');
  });

  // Scenario 17: Search and pagination never expose unauthorized documents
  it('17. Search and pagination never disclose unauthorized document titles or counts', async () => {
    // User B searches for Alice's secret patent
    const res = await request(app)
      .get('/api/documents?search=Patent')
      .set('Authorization', `Bearer ${userBToken}`);

    expect(res.status).toBe(200);
    // User B must see zero documents and zero pagination count
    expect(res.body.data.documents.length).toBe(0);
    expect(res.body.data.pagination.total).toBe(0);
  });
});
