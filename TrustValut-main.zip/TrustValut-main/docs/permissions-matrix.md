# TrustVault Role & Permission Matrix

TrustVault enforces a multi-tier authorization model combining Role-Based Access Control (RBAC) with granular Document-Level Discretionary Access Control (DAC).

---

## 1. Persona Definitions

1. **Administrator (`admin`)**:
   - Oversees organizational security posture, identity lifecycle, and system audit events.
   - Operates under strict **Least Privilege**: cannot download or inspect confidential file contents unless the document owner explicitly grants them access.
2. **Document Owner (`owner`)**:
   - Holds complete authority over documents they deposit into the vault.
   - Grants read or edit permissions to named users, configures access expiry, and triggers instant revocations.
3. **Viewer (`viewer`)**:
   - Can only access documents explicitly delegated to them.
   - When granted `read`, can view metadata and stream file downloads.
   - When granted `edit`, can modify supported metadata and deposit new document versions.

---

## 2. Comprehensive Capability Matrix

| Operation | Endpoint | Administrator | Document Owner | Viewer (Read) | Viewer (Edit) | Unauthenticated |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| **Authenticate / Sign In** | `POST /api/auth/login` | Yes | Yes | Yes | Yes | Yes |
| **Provision User (Admin)** | `POST /api/admin/users` | **Yes** | No | No | No | No |
| **Deactivate Account** | `PATCH /api/admin/users/:id` | **Yes** | No | No | No | No |
| **View System Audit Explorer** | `GET /api/audit` | **Yes** | No | No | No | No |
| **Export Audit Logs (CSV)** | `GET /api/audit?format=csv` | **Yes** | No | No | No | No |
| **Deposit / Upload Document** | `POST /api/documents` | Yes* | **Yes** | No | No | No |
| **List Owned Documents** | `GET /api/documents?scope=mine` | Yes (Own) | **Yes** | No | No | No |
| **List Shared Documents** | `GET /api/documents?scope=shared` | Yes (Shared) | Yes (Shared) | **Yes** | **Yes** | No |
| **View Document Details** | `GET /api/documents/:id` | Metadata only | **Yes** | **Yes** | **Yes** | No |
| **Stream File Download** | `GET /api/documents/:id/download` | **No** (Least Priv.) | **Yes** | **Yes** | **Yes** | No |
| **Edit Document Metadata** | `PATCH /api/documents/:id` | No | **Yes** | No | **Yes** | No |
| **Upload New Version** | `POST /api/documents/:id/versions` | No | **Yes** | No | **Yes** | No |
| **View Version History** | `GET /api/documents/:id/versions` | Yes | **Yes** | **Yes** | **Yes** | No |
| **Soft-Delete Document** | `DELETE /api/documents/:id` | No | **Yes** | No | No | No |
| **Restore Document from Trash** | `POST /api/documents/:id/restore`| No | **Yes** | No | No | No |
| **Permanent Retention Purge** | `DELETE /api/documents/:id?permanent=true` | **Yes** | **Yes** | No | No | No |
| **Grant Collaborator Access** | `POST /api/documents/:id/permissions` | No | **Yes** | No | No | No |
| **Revoke Collaborator Access** | `DELETE /api/documents/:id/permissions/:pid` | No | **Yes** | No | No | No |
| **View Document Audit Trail** | `GET /api/documents/:id/audit` | **Yes** | **Yes** | No | No | No |

*\* Administrators can upload documents if they also act as document depositors.*

---

## 3. Enforcement Rules & Invariants

1. **Deny By Default**: If no explicit ownership or unexpired permission record exists, access is rejected with `403 Forbidden`.
2. **Instant Revocation Guarantee**: Deactivating a permission immediately blocks subsequent download requests.
3. **Single Active Permission**: Only one active permission record is maintained per `(documentId, userId)` pair. Prior permissions are archived with revocation timestamps.
4. **Session Termination on Deactivation**: If an administrator deactivates a user account, the user's active session is blocked on their next API request.
