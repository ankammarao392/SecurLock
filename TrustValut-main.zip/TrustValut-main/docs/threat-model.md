# TrustVault Threat Model & Security Posture Analysis

This document provides a STRIDE threat model and architectural risk assessment for TrustVault.

---

## 1. STRIDE Threat Analysis

| Threat Category | Potential Attack Vector | TrustVault Mitigation Strategy |
| :--- | :--- | :--- |
| **Spoofing Identity** | Credential stuffing, session token forgery, session replay. | - Bcrypt password hashing (work factor 12).<br>- HTTP-only, secure, SameSite=Lax cookies.<br>- Session tokens checked against active database user status.<br>- Account deactivation immediately revokes active tokens. |
| **Tampering with Data** | Parameter tampering on document updates; altering audit trails; modifying permissions. | - Centralized authorization policy validates ownership and rights.<br>- Append-only schema hooks block mutation/deletion of audit logs.<br>- SHA-256 integrity digests computed on initial file upload and verified on versions. |
| **Repudiation** | An actor denies downloading a confidential document or revoking access. | - Structured audit events record actor, IP, timestamp, action, and correlation ID.<br>- Denied access attempts logged with rejection reason. |
| **Information Disclosure** | IDOR/BOLA by guessing document IDs; leaking metadata via search; directory traversal. | - Zero IDOR: Every endpoint asserts permissions against database.<br>- Search queries and pagination totals scoped strictly to authorized documents.<br>- Private uploads stored outside web root with random UUIDs; zero static serving. |
| **Denial of Service** | Large file uploads exhausting disk; brute-force credential stuffing. | - 10 MB strict file size ceiling enforced in memory before disk write.<br>- Rate limiting on `/api/auth/login` (30 attempts / 15 minutes).<br>- Global request body size limited to 2 MB for JSON endpoints. |
| **Elevation of Privilege** | Normal user requesting admin endpoints or granting themselves edit rights on foreign docs. | - Role guards (`requireRoles('admin')`).<br>- Permission mutations strictly restricted to document owner.<br>- Administrator cannot bypass document confidentiality to download unshared files. |

---

## 2. File Upload Defense Architecture

1. **Extension Spoofing**: Attackers frequently rename `.exe` or `.sh` files to `.pdf`. TrustVault reads the first byte sequence in memory and matches it against known magic bytes.
2. **Path Traversal (`../`)**: File names are sanitized with `path.basename()`. Stored files use random UUID identifiers rather than client-supplied filenames.
3. **MIME Confusion / Sniffing**: All file download responses set `X-Content-Type-Options: nosniff` and `Content-Disposition: attachment`.
4. **Execution Prevention**: The `private-uploads/` folder is never mounted via `express.static()`. Stored files have no execution permissions (`0o600`).

---

## 3. Limits of Application-Level Audit Logging

Application-level append-only hooks protect logs from application users and standard APIs. However, they do not inherently defend against a compromised database administrator (DBA) or root host compromise. 

**Recommended Production Hardening:**
- Stream audit events asynchronously to an external, write-once immutable SIEM (e.g., AWS CloudWatch with S3 Object Lock, Datadog, or Splunk).
- Configure MongoDB Atlas Database Auditing and Role-Based Access Control to restrict direct database modifications.
