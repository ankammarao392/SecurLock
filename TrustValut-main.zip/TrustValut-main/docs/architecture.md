# TrustVault: System Architecture & Technical Specifications

TrustVault is an enterprise-grade document management and access governance platform engineered for organizations handling confidential and restricted business assets (e.g., M&A term sheets, financial audits, IP patents, and vulnerability reports).

---

## 1. High-Level Architecture Topology

```
+---------------------------------------------------------------------------------+
|                                 CLIENT TIER                                     |
|  React 19 / TypeScript / Vite / Tailwind CSS / Recharts / Lucide Icons          |
|  - Cyber-defense control center UI (Midnight Navy & Electric Teal)              |
|  - Client-side CSRF handling and credentialed Axios transport                   |
+----------------------------------------+----------------------------------------+
                                         | HTTPS (TLS 1.3) / SameSite Lax Cookies
                                         v
+---------------------------------------------------------------------------------+
|                                 SERVER TIER                                     |
|  Node.js / Express / TypeScript                                                 |
|  - Helmet security headers (Content-Security-Policy, X-Content-Type-Options)   |
|  - CORS strict allowlists                                                      |
|  - express-rate-limit (Brute-force protection on /auth)                         |
|  - Multer memory buffer streaming & magic byte signature inspector             |
|  - JWT authentication in secure HTTP-only cookies                               |
|  - Correlation ID middleware (X-Correlation-ID)                                 |
+--------------------+------------------------------------+-----------------------+
                     |                                    |
                     v                                    v
+--------------------+--------------+   +-----------------+-----------------------+
|          DATABASE TIER            |   |              STORAGE TIER               |
|  MongoDB Atlas / Mongoose         |   |  Local Isolated Storage / Object Store  |
|  - User Identity (bcrypt hashes)  |   |  - Non-static directory: private-uploads|
|  - Document Metadata & Checksums  |   |  - Unpredictable UUID storage keys      |
|  - Granular Permissions & History |   |  - Authorized streaming pipes only      |
|  - Append-Only Audit Trail        |   |  - Zero permanent public URLs           |
+-----------------------------------+   +-----------------------------------------+
```

---

## 2. Security Boundaries & Zero-Trust Principles

### Zero IDOR / BOLA (Broken Object Level Authorization)
In TrustVault, no client can manipulate document access by altering a document ID, user ID, or role. Every endpoint receiving an identifier resolves the calling principal via the database and validates permissions against centralized authorization policies (`canReadDocument`, `canDownloadDocument`, `canEditDocument`, `canDeleteDocument`, `canManagePermissions`).

### Least Privilege Administration
Consistent with zero-trust architecture, system administrators cannot automatically read or download confidential document payloads merely because of their administrative role. Document access requires explicit ownership or active, unexpired permission granted by the document owner.

### Instant Revocation
Permissions are not baked into long-lived tokens or cached frontend states. Revocations update the active status in the database immediately, causing subsequent download or view requests to be rejected on the next request.

---

## 3. Cryptographic Storage & Upload Pipeline

1. **Client Upload**: Multipart upload arrives at `/api/documents`.
2. **Buffer Inspection**: The file buffer is retained in memory (max 10 MB).
3. **Magic Byte Signature Inspection**:
   - PDF: `%PDF-` (`0x25, 0x50, 0x44, 0x46, 0x2D`)
   - PNG: `0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A`
   - JPEG: `0xFF, 0xD8, 0xFF`
   - DOCX / XLSX / PPTX: Zip header `PK\x03\x04` (`0x50, 0x4B, 0x03, 0x04`)
   - *Spoofed extensions or disguised executables are immediately rejected with HTTP 400 and logged.*
4. **Integrity Hashing**: SHA-256 cryptographic digest calculated across the raw payload.
5. **Randomized Key Storage**: Cryptographically random UUID generated. The file is written to `private-uploads/<uuid>` with restricted filesystem permissions (`0o600`).
6. **Streaming Authorized Download**: Downloads stream with `X-Content-Type-Options: nosniff` and `Content-Disposition: attachment`.

---

## 4. Append-Only Audit Logging

Every security-relevant operation creates an audit log entry:
- Authentication (success, failed, logout, password reset)
- Document operations (upload, view, download, update, version create, delete, restore, purge)
- Permission operations (grant, update, revoke)
- Access boundaries (denied access attempts with correlation ID)

Audit records are append-only. The Mongoose schema enforces pre-hooks rejecting `updateOne`, `updateMany`, `deleteOne`, and `deleteMany`.
