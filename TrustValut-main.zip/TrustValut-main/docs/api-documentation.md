# TrustVault REST API Reference

TrustVault exposes a secured RESTful API adhering to strict input validation, correlation tracing, and error code standardization.

---

## 1. Global Conventions

### Security Headers
Every response includes:
- `X-Correlation-ID`: Unique UUID tracking the request through audit logs.
- `X-Content-Type-Options: nosniff`
- `Strict-Transport-Security: max-age=15552000; includeSubDomains` (production)

### Standard Response Format
```json
{
  "success": true,
  "data": { ... }
}
```

### Standard Error Format
```json
{
  "success": false,
  "error": {
    "code": "FORBIDDEN",
    "message": "Access denied: You do not have permission to download this document.",
    "correlationId": "8f3912a7-f958-45e8-bb65-5c1cf78280f5"
  }
}
```

---

## 2. Authentication Endpoints

### Register
`POST /api/auth/register`
- **Body**: `{ "name": "string", "email": "string", "password": "string", "role": "owner" | "viewer" }`
- **Response**: `201 Created`

### Login
`POST /api/auth/login`
- **Rate Limit**: 30 attempts per 15 minutes
- **Body**: `{ "email": "string", "password": "string" }`
- **Response**: `200 OK`, sets HTTP-only cookie `trustvault_token`

### Logout
`POST /api/auth/logout`
- **Response**: `200 OK`, clears cookie

### Get Current User Profile
`GET /api/auth/me`
- **Headers**: Cookie or `Authorization: Bearer <token>`
- **Response**: `200 OK`

### Forgot Password
`POST /api/auth/forgot-password`
- **Body**: `{ "email": "string" }`
- **Response**: `200 OK` (constant message preventing user enumeration)

### Reset Password
`POST /api/auth/reset-password`
- **Body**: `{ "token": "string", "newPassword": "string" }`
- **Response**: `200 OK`

---

## 3. Document Endpoints

### Upload Document
`POST /api/documents`
- **Content-Type**: `multipart/form-data`
- **Fields**:
  - `file`: Binary payload (PDF, DOCX, XLSX, PPTX, PNG, JPEG; max 10MB)
  - `title`: string
  - `description`: optional string
  - `category`: Legal | Financial | Human Resources | Security & Compliance | Engineering | Executive | Operations | Other
  - `sensitivity`: Public | Internal | Confidential | Restricted
- **Response**: `201 Created`

### List Documents
`GET /api/documents`
- **Query Parameters**:
  - `scope`: `all` | `mine` | `shared` | `trash`
  - `category`: string
  - `sensitivity`: string
  - `search`: string
  - `page`: integer
  - `limit`: integer
- **Response**: `200 OK`

### Get Document Metadata
`GET /api/documents/:id`
- **Response**: `200 OK`

### Stream Download Document File
`GET /api/documents/:id/download`
- **Authorization**: Caller must be owner OR hold active read/edit permission.
- **Headers**: `Content-Disposition: attachment; filename="..."`
- **Response**: `200 OK` binary file stream

### Update Metadata
`PATCH /api/documents/:id`
- **Body**: `{ "title": "string", "description": "string", "category": "...", "sensitivity": "..." }`
- **Response**: `200 OK`

### List Document Versions
`GET /api/documents/:id/versions`
- **Response**: `200 OK`

### Upload New Version
`POST /api/documents/:id/versions`
- **Content-Type**: `multipart/form-data`
- **Fields**: `file`, `description`
- **Response**: `201 Created`

### Soft-Delete Document
`DELETE /api/documents/:id`
- **Response**: `200 OK`

### Restore Document
`POST /api/documents/:id/restore`
- **Response**: `200 OK`

### Permanent Retention Purge
`DELETE /api/documents/:id?permanent=true`
- **Authorization**: Document owner or compliance administrator.
- **Response**: `200 OK`

---

## 4. Permission Endpoints

### List Document Permissions
`GET /api/documents/:id/permissions`
- **Response**: `200 OK`

### Grant Permission
`POST /api/documents/:id/permissions`
- **Body**: `{ "userId": "string" | "userEmail": "string", "permission": "read" | "edit", "expiresAt": "ISO date" | null }`
- **Response**: `201 Created`

### Revoke Permission
`DELETE /api/documents/:id/permissions/:permissionId`
- **Response**: `200 OK` (takes effect immediately on subsequent requests)

---

## 5. Audit Endpoints

### Query Global Audit Logs
`GET /api/audit`
- **Authorization**: `admin` role required.
- **Query Parameters**: `search`, `action`, `outcome`, `startDate`, `endDate`, `page`, `limit`
- **CSV Export**: Append `format=csv` to trigger raw streaming CSV export.
- **Response**: `200 OK`

### Query Document Audit Trail
`GET /api/documents/:id/audit`
- **Authorization**: Owner or administrator.
- **Response**: `200 OK`

---

## 6. Administration Endpoints

### Get Admin Dashboard Metrics
`GET /api/admin/dashboard`
- **Response**: `200 OK`

### List Users Directory
`GET /api/admin/users`
- **Response**: `200 OK`

### Provision User
`POST /api/admin/users`
- **Body**: `{ "name": "...", "email": "...", "password": "...", "role": "admin"|"owner"|"viewer" }`
- **Response**: `201 Created`

### Update User Role or Status
`PATCH /api/admin/users/:id`
- **Body**: `{ "role": "...", "status": "active"|"disabled" }`
- **Response**: `200 OK`
