import axios from 'axios';
import {
  User,
  DocumentItem,
  DocumentPermissionItem,
  DocumentVersionItem,
  AuditLogItem,
  Pagination,
} from '../types';

export const api = axios.create({
  baseURL: '/api',
  withCredentials: true,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Interceptor to format server error messages
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const errorData = error.response?.data?.error;
    let message = errorData?.message || error.message || 'An unexpected error occurred.';
    if (errorData?.details && Array.isArray(errorData.details) && errorData.details.length > 0) {
      const detailsText = errorData.details.map((d: any) => d.message).join('. ');
      if (detailsText) message = detailsText;
    }
    return Promise.reject(new Error(message));
  }
);

// Auth API
export const authApi = {
  login: (data: { email: string; password: string }) =>
    api.post<{ success: boolean; data: { user: User; token: string } }>('/auth/login', data),
  register: (data: { name: string; email: string; password: string; role?: string }) =>
    api.post<{ success: boolean; data: { user: User; token: string } }>('/auth/register', data),
  logout: () => api.post<{ success: boolean }>('/auth/logout'),
  getMe: () => api.get<{ success: boolean; data: { user: User } }>('/auth/me'),
  forgotPassword: (data: { email: string }) =>
    api.post<{ success: boolean; data: { message: string; debugToken?: string } }>('/auth/forgot-password', data),
  resetPassword: (data: { token: string; newPassword: string }) =>
    api.post<{ success: boolean; data: { message: string } }>('/auth/reset-password', data),
};

// Document API
export const documentApi = {
  getDocuments: (params?: {
    scope?: string;
    category?: string;
    sensitivity?: string;
    search?: string;
    page?: number;
    limit?: number;
  }) =>
    api.get<{
      success: boolean;
      data: { documents: DocumentItem[]; pagination: Pagination };
    }>('/documents', { params }),

  getDocumentById: (id: string) =>
    api.get<{ success: boolean; data: { document: DocumentItem } }>(`/documents/${id}`),

  uploadDocument: (formData: FormData) =>
    api.post<{ success: boolean; data: { document: DocumentItem } }>('/documents', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),

  updateMetadata: (
    id: string,
    data: { title?: string; description?: string; category?: string; sensitivity?: string }
  ) => api.patch<{ success: boolean; data: { document: DocumentItem } }>(`/documents/${id}`, data),

  downloadDocument: (id: string, filename: string) => {
    return api
      .get(`/documents/${id}/download`, {
        responseType: 'blob',
      })
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', filename);
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
      });
  },

  getVersions: (id: string) =>
    api.get<{ success: boolean; data: { versions: DocumentVersionItem[] } }>(`/documents/${id}/versions`),

  uploadVersion: (id: string, formData: FormData) =>
    api.post<{ success: boolean; data: { document: DocumentItem; version: DocumentVersionItem } }>(
      `/documents/${id}/versions`,
      formData,
      { headers: { 'Content-Type': 'multipart/form-data' } }
    ),

  deleteDocument: (id: string, permanent: boolean = false) =>
    api.delete<{ success: boolean; data: { message: string } }>(`/documents/${id}`, {
      params: { permanent },
    }),

  restoreDocument: (id: string) =>
    api.post<{ success: boolean; data: { message: string } }>(`/documents/${id}/restore`),
};

// Permissions API
export const permissionApi = {
  getPermissions: (documentId: string) =>
    api.get<{ success: boolean; data: { permissions: DocumentPermissionItem[] } }>(
      `/documents/${documentId}/permissions`
    ),

  grantPermission: (
    documentId: string,
    data: { userEmail?: string; userId?: string; permission: 'read' | 'edit'; expiresAt?: string | null }
  ) =>
    api.post<{ success: boolean; data: { permission: any } }>(
      `/documents/${documentId}/permissions`,
      data
    ),

  updatePermission: (
    documentId: string,
    permissionId: string,
    data: { permission?: 'read' | 'edit'; expiresAt?: string | null }
  ) =>
    api.patch<{ success: boolean; data: { permission: any } }>(
      `/documents/${documentId}/permissions/${permissionId}`,
      data
    ),

  revokePermission: (documentId: string, permissionId: string) =>
    api.delete<{ success: boolean; data: { message: string } }>(
      `/documents/${documentId}/permissions/${permissionId}`
    ),
};

// Audit API
export const auditApi = {
  getLogs: (params?: {
    search?: string;
    action?: string;
    outcome?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    limit?: number;
  }) =>
    api.get<{
      success: boolean;
      data: {
        logs: AuditLogItem[];
        pagination: Pagination;
        summary: {
          totalDownloads: number;
          totalPermissionChanges: number;
          totalDeniedAttempts: number;
          totalUploads: number;
        };
      };
    }>('/audit', { params }),

  getDocumentAudit: (documentId: string) =>
    api.get<{ success: boolean; data: { logs: AuditLogItem[] } }>(`/documents/${documentId}/audit`),

  exportCsvUrl: () => '/api/audit?format=csv',
};

// Admin API
export const adminApi = {
  getDashboard: () =>
    api.get<{
      success: boolean;
      data: {
        metrics: {
          totalUsers: number;
          activeUsers: number;
          totalDocuments: number;
          totalStorageBytes: number;
          audit24hCount: number;
          denied24hCount: number;
        };
        sensitivityDistribution: { sensitivity: string; count: number }[];
        recentAlerts: any[];
      };
    }>('/admin/dashboard'),

  getUsers: (params?: { role?: string; status?: string; search?: string; page?: number; limit?: number }) =>
    api.get<{ success: boolean; data: { users: User[]; pagination: Pagination } }>('/admin/users', {
      params,
    }),

  createUser: (data: { name: string; email: string; password: string; role: string; status?: string }) =>
    api.post<{ success: boolean; data: { user: User } }>('/admin/users', data),

  updateUser: (id: string, data: { name?: string; role?: string; status?: string; password?: string }) =>
    api.patch<{ success: boolean; data: { user: User } }>(`/admin/users/${id}`, data),
};

// User lookup API
export const userLookupApi = {
  search: (query: string) =>
    api.get<{ success: boolean; data: { users: { id: string; name: string; email: string; role: string }[] } }>(
      `/users/search?q=${encodeURIComponent(query)}`
    ),
};
