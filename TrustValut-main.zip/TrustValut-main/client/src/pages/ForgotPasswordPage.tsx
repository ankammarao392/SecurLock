import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, ArrowLeft, Send, CheckCircle2 } from 'lucide-react';
import { authApi } from '../services/api';
import { useToast } from '../context/ToastContext';

export const ForgotPasswordPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [debugToken, setDebugToken] = useState<string | null>(null);
  const toast = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await authApi.forgotPassword({ email });
      setSubmitted(true);
      if (res.data.data.debugToken) {
        setDebugToken(res.data.data.debugToken);
      }
      toast.success('Request Received', 'Password reset instructions dispatched.');
    } catch (err: any) {
      toast.error('Request Error', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-bold tracking-tight text-white">Reset Credentials</h2>
        <p className="mt-1 text-xs text-slate-400">
          Enter your registered work email to receive a secure recovery token
        </p>
      </div>

      {submitted ? (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <p className="font-semibold text-slate-100">Instructions Dispatched</p>
            <p className="text-slate-400 text-[11px]">
              If an active account is associated with this email, a single-use cryptographic token has
              been generated.
            </p>
          </div>

          {debugToken && (
            <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/30 text-xs space-y-2">
              <span className="text-[10px] uppercase font-bold text-cyan-400 block">
                Local Dev Recovery Token:
              </span>
              <div className="font-mono text-[10px] text-slate-300 break-all p-2 bg-slate-950 rounded">
                {debugToken}
              </div>
              <button
                onClick={() => navigate(`/reset-password?token=${debugToken}`)}
                className="w-full py-1.5 rounded-lg bg-cyanAccent/10 text-cyan-300 hover:bg-cyanAccent/20 font-semibold text-xs border border-cyan-500/30 transition-colors"
              >
                Continue with Token &rarr;
              </button>
            </div>
          )}

          <div className="text-center">
            <Link
              to="/login"
              className="inline-flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 font-semibold"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Return to Sign In
            </Link>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="font-semibold text-slate-300 block mb-1">Work Email</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com"
                className="w-full bg-slate-900 border border-vault-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-vault-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50"
          >
            {loading ? (
              'Dispatching...'
            ) : (
              <>
                <Send className="w-3.5 h-3.5" />
                <span>Issue Reset Token</span>
              </>
            )}
          </button>

          <div className="text-center pt-2">
            <Link
              to="/login"
              className="inline-flex items-center gap-1.5 text-slate-400 hover:text-slate-200"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> Back to Sign In
            </Link>
          </div>
        </form>
      )}
    </div>
  );
};
