import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { Share2, Search, ChevronLeft, ChevronRight, Lock } from 'lucide-react';
import { DocumentTable } from '../components/DocumentTable';
import { documentApi } from '../services/api';
import { DocumentItem } from '../types';
import { useToast } from '../context/ToastContext';

interface OutletContextType {
  searchQuery: string;
  onSelectDocument: (doc: DocumentItem) => void;
  onDownload: (doc: DocumentItem) => void;
  refreshTrigger: number;
}

export const SharedWithMePage: React.FC = () => {
  const {
    searchQuery: globalSearch,
    onSelectDocument,
    onDownload,
    refreshTrigger,
  } = useOutletContext<OutletContextType>();

  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [localSearch, setLocalSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalDocs, setTotalDocs] = useState(0);
  const toast = useToast();

  const effectiveSearch = localSearch || globalSearch;

  useEffect(() => {
    loadSharedDocuments();
  }, [categoryFilter, effectiveSearch, page, refreshTrigger]);

  const loadSharedDocuments = async () => {
    setLoading(true);
    try {
      const res = await documentApi.getDocuments({
        scope: 'shared',
        category: categoryFilter || undefined,
        search: effectiveSearch || undefined,
        page,
        limit: 15,
      });

      if (res.data.success) {
        setDocuments(res.data.data.documents);
        setTotalPages(res.data.data.pagination.totalPages);
        setTotalDocs(res.data.data.pagination.total);
      }
    } catch (err: any) {
      toast.error('Failed to load shared documents', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs uppercase tracking-wider">
          <Share2 className="w-4 h-4" />
          <span>Delegated Access Repository</span>
        </div>
        <h1 className="text-2xl font-bold text-white mt-1">Shared With Me</h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Confidential enterprise documents explicitly authorized to your account ({totalDocs} items)
        </p>
      </div>

      {/* Filter Bar */}
      <div className="p-4 rounded-2xl bg-vault-card border border-vault-border flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => {
                setLocalSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search shared titles..."
              className="w-full bg-vault-surface border border-vault-border rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setPage(1);
            }}
            className="bg-vault-surface border border-vault-border rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="">All Categories</option>
            <option value="Legal">Legal</option>
            <option value="Financial">Financial</option>
            <option value="Human Resources">Human Resources</option>
            <option value="Security & Compliance">Security & Compliance</option>
            <option value="Engineering">Engineering</option>
            <option value="Executive">Executive</option>
            <option value="Operations">Operations</option>
          </select>
        </div>

        <div className="text-slate-400 text-xs">
          Showing <span className="text-slate-200 font-semibold">{documents.length}</span> documents
        </div>
      </div>

      {/* Shared Documents Table */}
      <DocumentTable
        documents={documents}
        loading={loading}
        onSelectDocument={onSelectDocument}
        onDownload={onDownload}
      />

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <span className="text-xs text-slate-400">
            Page {page} of {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-xl bg-vault-card border border-vault-border text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-xl bg-vault-card border border-vault-border text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
