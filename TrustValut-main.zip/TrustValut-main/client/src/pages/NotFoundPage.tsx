import React from 'react';
import { Link } from 'react-router-dom';
import { FileQuestion, ArrowLeft } from 'lucide-react';
import { BrandLogo } from '../components/BrandLogo';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-vault-bg flex flex-col items-center justify-center p-6 text-center">
      <div className="mb-6">
        <BrandLogo size="lg" />
      </div>

      <div className="max-w-md w-full bg-vault-card border border-vault-border rounded-2xl p-8 shadow-vault-md space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mx-auto text-cyan-400">
          <FileQuestion className="w-8 h-8" />
        </div>

        <h1 className="text-xl font-bold text-white">404 — Document Not Found</h1>

        <p className="text-xs text-slate-300 leading-relaxed">
          The requested endpoint or document resource does not exist in the TrustVault registry.
        </p>

        <div className="pt-2">
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-vault-sm transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Dashboard</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
