import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ShieldAlert, ArrowLeft, Lock } from 'lucide-react';
import { BrandLogo } from '../components/BrandLogo';

export const AccessDeniedPage: React.FC = () => {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-vault-bg flex flex-col items-center justify-center p-6 text-center">
      <div className="mb-6">
        <BrandLogo size="lg" />
      </div>

      <div className="max-w-md w-full bg-vault-card border border-rose-500/30 rounded-2xl p-8 shadow-vault-md space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center mx-auto text-rose-400">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <h1 className="text-xl font-bold text-white">403 — Access Boundary Denied</h1>

        <p className="text-xs text-slate-300 leading-relaxed">
          Zero-Trust security policy prevented access to this resource. You do not hold an active,
          unexpired authorization token for the requested operation.
        </p>

        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-[11px] font-mono text-slate-400 text-left space-y-1">
          <div><span className="text-slate-500">Security Decision:</span> <span className="text-rose-400">REJECTED</span></div>
          <div><span className="text-slate-500">Audit Status:</span> <span className="text-cyan-400">LOGGED</span></div>
          <div><span className="text-slate-500">Timestamp:</span> {new Date().toISOString()}</div>
        </div>

        <div className="pt-2">
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-vault-sm transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Return to Secure Overview</span>
          </Link>
        </div>
      </div>
    </div>
  );
};
