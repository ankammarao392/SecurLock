import React, { useState, useEffect } from 'react';
import {
  FileSearch,
  Download,
  Filter,
  Search,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  ChevronLeft,
  ChevronRight,
  Shield,
  Eye,
  X,
} from 'lucide-react';
import { auditApi } from '../services/api';
import { AuditLogItem } from '../types';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export const AuditExplorerPage: React.FC = () => {
  const { user } = useAuth();
  const [logs, setLogs] = useState<AuditLogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [outcomeFilter, setOutcomeFilter] = useState('');
  const [actionFilter, setActionFilter] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalLogs, setTotalLogs] = useState(0);
  const [summary, setSummary] = useState({
    totalDownloads: 0,
    totalPermissionChanges: 0,
    totalDeniedAttempts: 0,
    totalUploads: 0,
  });
  const [inspectLog, setInspectLog] = useState<AuditLogItem | null>(null);
  const toast = useToast();

  useEffect(() => {
    if (user?.role === 'admin') {
      loadLogs();
    }
  }, [search, outcomeFilter, actionFilter, page, user]);

  const loadLogs = async () => {
    setLoading(true);
    try {
      const res = await auditApi.getLogs({
        search: search || undefined,
        outcome: outcomeFilter || undefined,
        action: actionFilter || undefined,
        page,
        limit: 20,
      });

      if (res.data.success) {
        setLogs(res.data.data.logs);
        setTotalPages(res.data.data.pagination.totalPages);
        setTotalLogs(res.data.data.pagination.total);
        if (res.data.data.summary) {
          setSummary(res.data.data.summary);
        }
      }
    } catch (err: any) {
      toast.error('Audit Access Failed', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleExportCsv = () => {
    window.open(auditApi.exportCsvUrl(), '_blank');
    toast.success('Audit Export Started', 'Downloading compliance CSV audit report.');
  };

  if (user?.role !== 'admin') {
    return (
      <div className="p-12 text-center max-w-md mx-auto space-y-4">
        <Shield className="w-12 h-12 text-rose-500 mx-auto" />
        <h2 className="text-xl font-bold text-white">Global Audit Restricted</h2>
        <p className="text-xs text-slate-400">
          Global security audit exploration is restricted to Chief Information Security Officers
          and Security Administrators. To inspect audit history for individual documents you own,
          open the document details drawer.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs uppercase tracking-wider">
            <FileSearch className="w-4 h-4" />
            <span>Forensic Investigation</span>
          </div>
          <h1 className="text-2xl font-bold text-white mt-1">Append-Only Audit Explorer</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Cryptographically sealed, immutable activity logs ({totalLogs} events recorded)
          </p>
        </div>

        <button
          onClick={handleExportCsv}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-vault-surface hover:bg-vault-hover text-cyan-400 border border-vault-border font-semibold text-xs transition-colors shadow-vault-sm"
        >
          <Download className="w-4 h-4" />
          <span>Export Compliance CSV</span>
        </button>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-vault-card border border-vault-border">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total Authorized Downloads
          </span>
          <div className="text-xl font-bold text-emerald-400 mt-1">{summary.totalDownloads}</div>
        </div>
        <div className="p-4 rounded-xl bg-vault-card border border-vault-border">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Permission Mutations
          </span>
          <div className="text-xl font-bold text-cyan-400 mt-1">{summary.totalPermissionChanges}</div>
        </div>
        <div className="p-4 rounded-xl bg-vault-card border border-vault-border">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Vault Deposits
          </span>
          <div className="text-xl font-bold text-teal-400 mt-1">{summary.totalUploads}</div>
        </div>
        <div className="p-4 rounded-xl bg-vault-card border border-vault-border">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Denied Access Attempts
          </span>
          <div className="text-xl font-bold text-rose-400 mt-1">{summary.totalDeniedAttempts}</div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="p-4 rounded-2xl bg-vault-card border border-vault-border flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative w-72">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search by email, action, reason, correlation ID..."
              className="w-full bg-vault-surface border border-vault-border rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <select
            value={outcomeFilter}
            onChange={(e) => {
              setOutcomeFilter(e.target.value);
              setPage(1);
            }}
            className="bg-vault-surface border border-vault-border rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="">All Outcomes</option>
            <option value="success">Success Only</option>
            <option value="denied">Denied Only</option>
          </select>

          <select
            value={actionFilter}
            onChange={(e) => {
              setActionFilter(e.target.value);
              setPage(1);
            }}
            className="bg-vault-surface border border-vault-border rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="">All Action Types</option>
            <option value="document.download">Document Download</option>
            <option value="document.upload">Document Upload</option>
            <option value="permission.grant">Permission Grant</option>
            <option value="permission.revoke">Permission Revoke</option>
            <option value="auth.login.success">Login Success</option>
            <option value="auth.login.failed">Login Failed</option>
            <option value="access.denied">Access Denied</option>
          </select>

          {(search || outcomeFilter || actionFilter) && (
            <button
              onClick={() => {
                setSearch('');
                setOutcomeFilter('');
                setActionFilter('');
                setPage(1);
              }}
              className="text-cyan-400 hover:text-cyan-300 font-medium text-xs underline"
            >
              Clear Filters
            </button>
          )}
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-vault-card rounded-2xl border border-vault-border overflow-hidden shadow-vault-md">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-vault-border bg-vault-surface/40 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                <th className="py-3.5 px-4">Timestamp</th>
                <th className="py-3.5 px-4">Action</th>
                <th className="py-3.5 px-4">Outcome</th>
                <th className="py-3.5 px-4">Actor</th>
                <th className="py-3.5 px-4">Target Document</th>
                <th className="py-3.5 px-4">Correlation ID</th>
                <th className="py-3.5 px-4 text-right">Inspect</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-vault-border/60">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Querying audit database...
                  </td>
                </tr>
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No matching audit records found.
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-vault-surface/50 transition-colors">
                    {/* Timestamp */}
                    <td className="py-3.5 px-4 text-slate-300 font-mono text-[11px]">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>

                    {/* Action */}
                    <td className="py-3.5 px-4 font-semibold text-slate-200">
                      {log.action}
                    </td>

                    {/* Outcome Badge */}
                    <td className="py-3.5 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider inline-flex items-center gap-1 ${
                          log.outcome === 'success'
                            ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                            : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                        }`}
                      >
                        {log.outcome === 'success' ? (
                          <CheckCircle2 className="w-3 h-3" />
                        ) : (
                          <AlertTriangle className="w-3 h-3" />
                        )}
                        <span>{log.outcome}</span>
                      </span>
                    </td>

                    {/* Actor */}
                    <td className="py-3.5 px-4 text-slate-300">
                      <div>{log.actor?.name || log.actor?.email}</div>
                      <div className="text-[10px] text-slate-400 capitalize">{log.actorRole || 'user'}</div>
                    </td>

                    {/* Target Document */}
                    <td className="py-3.5 px-4 text-slate-300 max-w-xs truncate">
                      {log.document ? log.document.title : log.reason ? (
                        <span className="text-rose-400 text-[11px] font-medium">{log.reason}</span>
                      ) : (
                        <span className="text-slate-500">—</span>
                      )}
                    </td>

                    {/* Correlation ID */}
                    <td className="py-3.5 px-4 font-mono text-[10px] text-cyan-400/80">
                      {log.correlationId ? log.correlationId.slice(0, 12) + '...' : '—'}
                    </td>

                    {/* Inspect */}
                    <td className="py-3.5 px-4 text-right">
                      <button
                        onClick={() => setInspectLog(log)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <span className="text-xs text-slate-400">
            Page {page} of {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-xl bg-vault-card border border-vault-border text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-xl bg-vault-card border border-vault-border text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Log Details Modal */}
      {inspectLog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-vault-card border border-vault-border rounded-2xl p-6 shadow-2xl space-y-4 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-vault-border">
              <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <FileSearch className="w-4 h-4 text-cyan-400" />
                Audit Event Forensics
              </h3>
              <button
                onClick={() => setInspectLog(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-2.5 font-mono text-[11px]">
              <div>
                <span className="text-slate-400">Action:</span>{' '}
                <span className="text-slate-200 font-semibold">{inspectLog.action}</span>
              </div>
              <div>
                <span className="text-slate-400">Outcome:</span>{' '}
                <span
                  className={
                    inspectLog.outcome === 'success' ? 'text-emerald-400' : 'text-rose-400'
                  }
                >
                  {inspectLog.outcome.toUpperCase()}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Timestamp:</span>{' '}
                <span className="text-slate-200">
                  {new Date(inspectLog.timestamp).toISOString()}
                </span>
              </div>
              <div>
                <span className="text-slate-400">Actor Email:</span>{' '}
                <span className="text-slate-200">{inspectLog.actor?.email}</span>
              </div>
              <div>
                <span className="text-slate-400">Correlation ID:</span>{' '}
                <span className="text-cyan-400">{inspectLog.correlationId || 'N/A'}</span>
              </div>
              {inspectLog.reason && (
                <div>
                  <span className="text-slate-400">Rejection Reason:</span>{' '}
                  <span className="text-rose-400">{inspectLog.reason}</span>
                </div>
              )}
              {inspectLog.metadata && Object.keys(inspectLog.metadata).length > 0 && (
                <div>
                  <span className="text-slate-400 block mb-1">Metadata:</span>
                  <pre className="p-3 bg-slate-950 rounded-xl border border-vault-border overflow-x-auto text-slate-300 text-[10px]">
                    {JSON.stringify(inspectLog.metadata, null, 2)}
                  </pre>
                </div>
              )}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setInspectLog(null)}
                className="px-4 py-2 rounded-xl bg-vault-surface hover:bg-vault-hover text-slate-200 border border-vault-border font-medium"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
