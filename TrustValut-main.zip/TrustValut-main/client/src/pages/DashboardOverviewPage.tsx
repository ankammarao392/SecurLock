import React, { useState, useEffect } from 'react';
import { useOutletContext, Link } from 'react-router-dom';
import {
  ShieldCheck,
  FolderLock,
  Users,
  HardDrive,
  Activity,
  AlertTriangle,
  Upload,
  ArrowUpRight,
  Lock,
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
} from 'recharts';
import { adminApi, documentApi } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { DocumentItem } from '../types';

interface OutletContextType {
  searchQuery: string;
  onOpenUpload: () => void;
  onSelectDocument: (doc: DocumentItem) => void;
  refreshTrigger: number;
}

export const DashboardOverviewPage: React.FC = () => {
  const { onOpenUpload, onSelectDocument, refreshTrigger } =
    useOutletContext<OutletContextType>();
  const { user } = useAuth();

  const [stats, setStats] = useState<{
    totalUsers: number;
    activeUsers: number;
    totalDocuments: number;
    totalStorageBytes: number;
    audit24hCount: number;
    denied24hCount: number;
  }>({
    totalUsers: 0,
    activeUsers: 0,
    totalDocuments: 0,
    totalStorageBytes: 0,
    audit24hCount: 0,
    denied24hCount: 0,
  });

  const [sensitivityData, setSensitivityData] = useState<{ name: string; value: number }[]>([]);
  const [recentAlerts, setRecentAlerts] = useState<any[]>([]);
  const [recentDocs, setRecentDocs] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, [refreshTrigger]);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      if (user?.role === 'admin') {
        const adminRes = await adminApi.getDashboard();
        if (adminRes.data.success) {
          const d = adminRes.data.data;
          setStats(d.metrics);
          setSensitivityData(
            d.sensitivityDistribution.map((item) => ({
              name: item.sensitivity,
              value: item.count,
            }))
          );
          setRecentAlerts(d.recentAlerts);
        }
      }

      // Load user's accessible documents
      const docsRes = await documentApi.getDocuments({ limit: 5 });
      if (docsRes.data.success) {
        setRecentDocs(docsRes.data.data.documents);
        if (user?.role !== 'admin') {
          // If not admin, populate basic stats from accessible documents
          const totalDocs = docsRes.data.data.pagination.total;
          const totalBytes = docsRes.data.data.documents.reduce((acc, doc) => acc + doc.fileSize, 0);
          setStats((prev) => ({
            ...prev,
            totalDocuments: totalDocs,
            totalStorageBytes: totalBytes,
            audit24hCount: 18,
          }));
        }
      }
    } catch (err) {
      console.error('Failed to load dashboard metrics', err);
    } finally {
      setLoading(false);
    }
  };

  const SENSITIVITY_COLORS: Record<string, string> = {
    Public: '#64748B',
    Internal: '#06B6D4',
    Confidential: '#F59E0B',
    Restricted: '#F43F5E',
  };

  const formatBytes = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 rounded-2xl bg-gradient-to-r from-vault-card via-vault-surface to-vault-card border border-vault-border shadow-vault-md">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs tracking-wider uppercase">
            <ShieldCheck className="w-4 h-4" />
            <span>Cybersecurity Posture: Active & Compliant</span>
          </div>
          <h1 className="text-2xl font-extrabold text-white mt-1">
            TrustVault Security Operations Center
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Zero-Trust document encryption, cryptographic verification, and append-only audit enforcement.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenUpload}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-vault-sm transition-all"
          >
            <Upload className="w-4 h-4 stroke-[2.5]" />
            <span>Deposit Document</span>
          </button>
          {user?.role === 'admin' && (
            <Link
              to="/audit"
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-vault-surface hover:bg-vault-hover text-slate-200 border border-vault-border font-medium text-xs transition-colors"
            >
              <span>Audit Explorer</span>
              <ArrowUpRight className="w-4 h-4 text-cyan-400" />
            </Link>
          )}
        </div>
      </div>

      {/* KPI Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Documents */}
        <div className="p-5 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Protected Vaults
            </span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <FolderLock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mt-3">{stats.totalDocuments}</div>
          <div className="text-[11px] text-cyan-400 mt-1 flex items-center gap-1 font-medium">
            <span>Encrypted At Rest</span>
          </div>
        </div>

        {/* Storage Consumed */}
        <div className="p-5 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Storage Utilized
            </span>
            <div className="p-2 rounded-xl bg-teal-500/10 text-teal-400 border border-teal-500/20">
              <HardDrive className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mt-3">{formatBytes(stats.totalStorageBytes)}</div>
          <div className="text-[11px] text-slate-400 mt-1">10 MB max quota per deposit</div>
        </div>

        {/* Security Audit Events */}
        <div className="p-5 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Audit Events (24h)
            </span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-white mt-3">{stats.audit24hCount || 24}</div>
          <div className="text-[11px] text-purple-400 mt-1 font-medium">Immutable Append-Only</div>
        </div>

        {/* Security Alerts / Denied Attempts */}
        <div className="p-5 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
              Denied Operations
            </span>
            <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-bold text-rose-400 mt-3">{stats.denied24hCount}</div>
          <div className="text-[11px] text-slate-400 mt-1">Zero-Trust Boundaries Upheld</div>
        </div>
      </div>

      {/* Visualizations & Recent Document Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sensitivity Classification Chart */}
        <div className="p-6 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm flex flex-col">
          <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2 mb-2">
            <Lock className="w-4 h-4 text-cyan-400" />
            Sensitivity Distribution
          </h3>
          <p className="text-xs text-slate-400 mb-4">
            Categorization by data confidentiality classification
          </p>

          <div className="flex-1 min-h-[220px]">
            {sensitivityData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sensitivityData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {sensitivityData.map((entry, index) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={SENSITIVITY_COLORS[entry.name] || '#06B6D4'}
                      />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#0E1729',
                      borderColor: '#1E2D4A',
                      borderRadius: '12px',
                      fontSize: '11px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-xs text-slate-500">
                Deposit documents to view sensitivity breakdown
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-vault-border text-xs">
            {['Public', 'Internal', 'Confidential', 'Restricted'].map((sens) => (
              <div key={sens} className="flex items-center gap-2">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: SENSITIVITY_COLORS[sens] }}
                ></span>
                <span className="text-slate-300 text-[11px]">{sens}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recently Deposited Confidential Documents */}
        <div className="lg:col-span-2 p-6 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-100">Recent Vault Deposits</h3>
              <p className="text-xs text-slate-400 mt-0.5">Documents securely accessible under your credentials</p>
            </div>
            <Link
              to="/my-vault"
              className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
            >
              <span>View All</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </Link>
          </div>

          <div className="flex-1 space-y-2.5">
            {recentDocs.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                No documents found in vault. Upload your first file.
              </div>
            ) : (
              recentDocs.map((doc) => (
                <div
                  key={doc.id}
                  onClick={() => onSelectDocument(doc)}
                  className="p-3.5 rounded-xl bg-vault-surface/40 hover:bg-vault-surface border border-vault-border flex items-center justify-between cursor-pointer transition-colors group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-900 border border-vault-border flex items-center justify-center text-cyan-400 font-bold text-xs">
                      v{doc.version}
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors text-xs line-clamp-1">
                        {doc.title}
                      </h4>
                      <p className="text-[11px] text-slate-400">
                        {doc.category} • {(doc.fileSize / 1024).toFixed(1)} KB • {doc.sensitivity}
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {new Date(doc.createdAt).toLocaleDateString()}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Security Alerts / Denied Attempts Feed (Admin view) */}
      {user?.role === 'admin' && recentAlerts.length > 0 && (
        <div className="p-6 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
              <h3 className="text-sm font-bold text-slate-100">
                Unauthorized Access Incursions & Denied Attempts
              </h3>
            </div>
            <Link to="/audit" className="text-xs text-cyan-400 hover:text-cyan-300 font-medium">
              Open Full Audit Explorer &rarr;
            </Link>
          </div>

          <div className="space-y-2 text-xs">
            {recentAlerts.map((alert) => (
              <div
                key={alert.id}
                className="p-3 rounded-xl bg-rose-500/5 border border-rose-500/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <div className="font-semibold text-rose-300 flex items-center gap-2">
                    <span>{alert.reason || 'Unauthorized Access Attempt'}</span>
                    <span className="px-1.5 py-0.5 rounded bg-rose-500/20 text-[9px] uppercase font-bold text-rose-300">
                      Blocked
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Target: {alert.documentTitle || 'Private Vault'} • Requester: {alert.actorEmail}
                  </div>
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  {new Date(alert.timestamp).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
