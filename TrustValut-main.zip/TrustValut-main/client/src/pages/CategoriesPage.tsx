import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  Layers,
  Scale,
  DollarSign,
  UserCheck,
  ShieldAlert,
  Cpu,
  Briefcase,
  Cog,
  Folder,
  ArrowRight,
} from 'lucide-react';
import { documentApi } from '../services/api';
import { DocumentCategory, DocumentItem } from '../types';
import { DocumentTable } from '../components/DocumentTable';
import { useToast } from '../context/ToastContext';

interface OutletContextType {
  onSelectDocument: (doc: DocumentItem) => void;
  onManageAccess: (doc: DocumentItem) => void;
  onDownload: (doc: DocumentItem) => void;
  refreshTrigger: number;
}

const CATEGORIES: { name: DocumentCategory; icon: any; color: string; desc: string }[] = [
  {
    name: 'Legal',
    icon: Scale,
    color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',
    desc: 'Term sheets, non-disclosure agreements, contracts, and IP filings.',
  },
  {
    name: 'Financial',
    icon: DollarSign,
    color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    desc: 'Audit reports, quarterly forecasts, equity schedules, and margins.',
  },
  {
    name: 'Security & Compliance',
    icon: ShieldAlert,
    color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
    desc: 'Penetration tests, SOC 2 reports, zero-trust policies, and GDPR.',
  },
  {
    name: 'Engineering',
    icon: Cpu,
    color: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
    desc: 'Architectural blueprints, cryptographic specs, and topology.',
  },
  {
    name: 'Human Resources',
    icon: UserCheck,
    color: 'text-teal-400 bg-teal-500/10 border-teal-500/20',
    desc: 'Executive compensation, organizational reviews, and benefits.',
  },
  {
    name: 'Executive',
    icon: Briefcase,
    color: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
    desc: 'Board meeting minutes, strategic roadmaps, and M&A briefs.',
  },
  {
    name: 'Operations',
    icon: Cog,
    color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
    desc: 'Supply chain contracts, infrastructure SLAs, and logistics.',
  },
  {
    name: 'Other',
    icon: Folder,
    color: 'text-slate-400 bg-slate-500/10 border-slate-500/20',
    desc: 'General organizational assets and miscellaneous documents.',
  },
];

export const CategoriesPage: React.FC = () => {
  const { onSelectDocument, onManageAccess, onDownload, refreshTrigger } =
    useOutletContext<OutletContextType>();

  const [selectedCategory, setSelectedCategory] = useState<DocumentCategory | null>(null);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(false);
  const toast = useToast();

  useEffect(() => {
    if (selectedCategory) {
      loadCategoryDocuments(selectedCategory);
    }
  }, [selectedCategory, refreshTrigger]);

  const loadCategoryDocuments = async (category: DocumentCategory) => {
    setLoading(true);
    try {
      const res = await documentApi.getDocuments({ category, limit: 30 });
      if (res.data.success) {
        setDocuments(res.data.data.documents);
      }
    } catch (err: any) {
      toast.error('Failed to load category documents', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs uppercase tracking-wider">
          <Layers className="w-4 h-4" />
          <span>Taxonomy & Classification</span>
        </div>
        <h1 className="text-2xl font-bold text-white mt-1">Enterprise Categories</h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Browse encrypted repositories organized by business domain and compliance scope
        </p>
      </div>

      {/* Category Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {CATEGORIES.map((cat) => {
          const Icon = cat.icon;
          const isSelected = selectedCategory === cat.name;
          return (
            <div
              key={cat.name}
              onClick={() => setSelectedCategory(isSelected ? null : cat.name)}
              className={`p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                isSelected
                  ? 'bg-vault-surface border-cyan-400 shadow-vault-glow'
                  : 'bg-vault-card hover:bg-vault-surface/60 border-vault-border'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className={`p-2.5 rounded-xl border ${cat.color}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  {isSelected && (
                    <span className="text-[10px] uppercase font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                      Active Filter
                    </span>
                  )}
                </div>
                <h3 className="font-bold text-slate-100 text-sm">{cat.name}</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{cat.desc}</p>
              </div>

              <div className="pt-2 flex items-center justify-between text-xs font-semibold text-cyan-400">
                <span>{isSelected ? 'Viewing Documents' : 'Inspect Category'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Category Documents */}
      {selectedCategory && (
        <div className="space-y-4 pt-4 border-t border-vault-border">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span>Category:</span>
              <span className="text-cyan-400">{selectedCategory}</span>
              <span className="text-xs text-slate-400 font-normal">({documents.length} items)</span>
            </h2>

            <button
              onClick={() => setSelectedCategory(null)}
              className="text-xs text-slate-400 hover:text-slate-200 underline"
            >
              Close Category View
            </button>
          </div>

          <DocumentTable
            documents={documents}
            loading={loading}
            onSelectDocument={onSelectDocument}
            onDownload={onDownload}
            onManageAccess={onManageAccess}
          />
        </div>
      )}
    </div>
  );
};
