import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import {
  FolderLock,
  Upload,
  Filter,
  Trash2,
  RotateCcw,
  Search,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { DocumentTable } from '../components/DocumentTable';
import { documentApi } from '../services/api';
import { DocumentItem, DocumentCategory, DocumentSensitivity } from '../types';
import { useToast } from '../context/ToastContext';

interface OutletContextType {
  searchQuery: string;
  onOpenUpload: () => void;
  onSelectDocument: (doc: DocumentItem) => void;
  onManageAccess: (doc: DocumentItem) => void;
  onDownload: (doc: DocumentItem) => void;
  refreshTrigger: number;
  triggerRefresh: () => void;
}

export const MyVaultPage: React.FC = () => {
  const {
    searchQuery: globalSearch,
    onOpenUpload,
    onSelectDocument,
    onManageAccess,
    onDownload,
    refreshTrigger,
    triggerRefresh,
  } = useOutletContext<OutletContextType>();

  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isTrashView, setIsTrashView] = useState(false);
  const [categoryFilter, setCategoryFilter] = useState<string>('');
  const [sensitivityFilter, setSensitivityFilter] = useState<string>('');
  const [localSearch, setLocalSearch] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalDocs, setTotalDocs] = useState(0);
  const toast = useToast();

  const effectiveSearch = localSearch || globalSearch;

  useEffect(() => {
    loadDocuments();
  }, [
    isTrashView,
    categoryFilter,
    sensitivityFilter,
    effectiveSearch,
    page,
    refreshTrigger,
  ]);

  const loadDocuments = async () => {
    setLoading(true);
    try {
      const res = await documentApi.getDocuments({
        scope: isTrashView ? 'trash' : 'mine',
        category: categoryFilter || undefined,
        sensitivity: sensitivityFilter || undefined,
        search: effectiveSearch || undefined,
        page,
        limit: 15,
      });

      if (res.data.success) {
        setDocuments(res.data.data.documents);
        setTotalPages(res.data.data.pagination.totalPages);
        setTotalDocs(res.data.data.pagination.total);
      }
    } catch (err: any) {
      toast.error('Failed to load vault documents', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (doc: DocumentItem) => {
    try {
      await documentApi.deleteDocument(doc.id, false);
      toast.success('Document Moved to Trash', `"${doc.title}" has been quarantined.`);
      triggerRefresh();
    } catch (err: any) {
      toast.error('Delete Denied', err.message);
    }
  };

  const handleRestore = async (doc: DocumentItem) => {
    try {
      await documentApi.restoreDocument(doc.id);
      toast.success('Document Restored', `"${doc.title}" is back in active vault.`);
      triggerRefresh();
    } catch (err: any) {
      toast.error('Restore Denied', err.message);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs uppercase tracking-wider">
            <FolderLock className="w-4 h-4" />
            <span>Private Repository</span>
          </div>
          <h1 className="text-2xl font-bold text-white mt-1">My Secure Vault</h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Encrypted documents owned and administered by you ({totalDocs} items)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setIsTrashView(!isTrashView);
              setPage(1);
            }}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-medium border transition-colors ${
              isTrashView
                ? 'bg-rose-500/15 border-rose-500/30 text-rose-300'
                : 'bg-vault-surface hover:bg-vault-hover border-vault-border text-slate-300'
            }`}
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{isTrashView ? 'Exit Trash' : 'Quarantined Trash'}</span>
          </button>

          {!isTrashView && (
            <button
              onClick={onOpenUpload}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-vault-sm transition-all"
            >
              <Upload className="w-4 h-4 stroke-[2.5]" />
              <span>Upload Document</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-vault-card border border-vault-border flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-3">
          {/* Local Search Input */}
          <div className="relative w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => {
                setLocalSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Filter by title..."
              className="w-full bg-vault-surface border border-vault-border rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Category Filter */}
          <select
            value={categoryFilter}
            onChange={(e) => {
              setCategoryFilter(e.target.value);
              setPage(1);
            }}
            className="bg-vault-surface border border-vault-border rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="">All Categories</option>
            <option value="Legal">Legal</option>
            <option value="Financial">Financial</option>
            <option value="Human Resources">Human Resources</option>
            <option value="Security & Compliance">Security & Compliance</option>
            <option value="Engineering">Engineering</option>
            <option value="Executive">Executive</option>
            <option value="Operations">Operations</option>
            <option value="Other">Other</option>
          </select>

          {/* Sensitivity Filter */}
          <select
            value={sensitivityFilter}
            onChange={(e) => {
              setSensitivityFilter(e.target.value);
              setPage(1);
            }}
            className="bg-vault-surface border border-vault-border rounded-xl px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="">All Sensitivities</option>
            <option value="Public">Public</option>
            <option value="Internal">Internal</option>
            <option value="Confidential">Confidential</option>
            <option value="Restricted">Restricted</option>
          </select>

          {(categoryFilter || sensitivityFilter || localSearch) && (
            <button
              onClick={() => {
                setCategoryFilter('');
                setSensitivityFilter('');
                setLocalSearch('');
              }}
              className="text-cyan-400 hover:text-cyan-300 font-medium text-xs underline"
            >
              Reset Filters
            </button>
          )}
        </div>

        {/* Count Label */}
        <div className="text-slate-400 text-xs">
          Showing <span className="text-slate-200 font-semibold">{documents.length}</span> of{' '}
          <span className="text-slate-200 font-semibold">{totalDocs}</span> documents
        </div>
      </div>

      {/* Documents Table */}
      <DocumentTable
        documents={documents}
        loading={loading}
        onSelectDocument={onSelectDocument}
        onDownload={onDownload}
        onManageAccess={onManageAccess}
        onDelete={handleDelete}
        onRestore={handleRestore}
        isTrashView={isTrashView}
      />

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between pt-2">
          <span className="text-xs text-slate-400">
            Page {page} of {totalPages}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-xl bg-vault-card border border-vault-border text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-xl bg-vault-card border border-vault-border text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
