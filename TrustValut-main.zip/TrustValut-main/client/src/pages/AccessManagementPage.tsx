import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { KeyRound, Shield, Users, Clock, ArrowRight, Lock } from 'lucide-react';
import { documentApi } from '../services/api';
import { DocumentItem } from '../types';
import { useToast } from '../context/ToastContext';

interface OutletContextType {
  onManageAccess: (doc: DocumentItem) => void;
  refreshTrigger: number;
}

export const AccessManagementPage: React.FC = () => {
  const { onManageAccess, refreshTrigger } = useOutletContext<OutletContextType>();
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  useEffect(() => {
    loadOwnedDocuments();
  }, [refreshTrigger]);

  const loadOwnedDocuments = async () => {
    setLoading(true);
    try {
      const res = await documentApi.getDocuments({ scope: 'mine', limit: 50 });
      if (res.data.success) {
        setDocuments(res.data.data.documents);
      }
    } catch (err: any) {
      toast.error('Failed to load owned documents', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs uppercase tracking-wider">
          <KeyRound className="w-4 h-4" />
          <span>Access Governance</span>
        </div>
        <h1 className="text-2xl font-bold text-white mt-1">Document Access Management</h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Audit permissions, grant granular viewer or editor rights, and trigger instant revocations.
        </p>
      </div>

      {/* Information Alert */}
      <div className="p-4 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 text-xs text-slate-300 flex items-start gap-3">
        <Shield className="w-5 h-5 text-cyan-400 flex-shrink-0 mt-0.5" />
        <div>
          <span className="font-bold text-cyan-300 block mb-0.5">Zero-Trust Instant Revocation Policy</span>
          When you revoke collaborator access, the change takes effect immediately on the server.
          The user is instantly rejected on the very next download or view request, with an audit log generated.
        </div>
      </div>

      {/* Document Access Cards Grid */}
      {loading ? (
        <div className="p-12 text-center text-slate-400 bg-vault-card rounded-2xl border border-vault-border text-xs">
          Loading access records...
        </div>
      ) : documents.length === 0 ? (
        <div className="p-16 text-center text-slate-500 bg-vault-card rounded-2xl border border-vault-border">
          <Lock className="w-10 h-10 mx-auto mb-2 text-slate-600" />
          <p className="font-semibold text-slate-300 text-sm">No Owned Documents</p>
          <p className="text-xs text-slate-500 mt-1">Upload documents to manage permissions.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {documents.map((doc) => (
            <div
              key={doc.id}
              className="p-5 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm flex flex-col justify-between space-y-4 hover:border-slate-700 transition-colors"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/20">
                    {doc.category}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-400">
                    Sensitivity: <span className="text-slate-200">{doc.sensitivity}</span>
                  </span>
                </div>
                <h3 className="font-bold text-slate-100 text-sm line-clamp-1">{doc.title}</h3>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                  {doc.description || 'Confidential organizational asset.'}
                </p>
              </div>

              <div className="pt-3 border-t border-vault-border flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-mono">
                  {(doc.fileSize / 1024).toFixed(1)} KB • v{doc.version}
                </span>

                <button
                  onClick={() => onManageAccess(doc)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-vault-surface hover:bg-vault-hover text-cyan-400 border border-vault-border font-semibold text-xs transition-colors"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Manage Permissions</span>
                  <ArrowRight className="w-3 h-3 ml-0.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
