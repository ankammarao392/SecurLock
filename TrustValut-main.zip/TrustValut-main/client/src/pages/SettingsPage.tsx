import React from 'react';
import {
  Settings,
  Shield,
  KeyRound,
  FileText,
  Lock,
  CheckCircle2,
  XCircle,
  HelpCircle,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const SettingsPage: React.FC = () => {
  const { user } = useAuth();

  const permissionsMatrix = [
    {
      action: 'Upload confidential documents',
      admin: false,
      owner: true,
      viewer: false,
      note: 'Only owners deposit and control documents.',
    },
    {
      action: 'Read & stream download private documents',
      admin: false,
      owner: true,
      viewer: 'If granted',
      note: 'Strict least privilege: admins cannot read or download private files without explicit permission.',
    },
    {
      action: 'Modify document metadata & upload versions',
      admin: false,
      owner: true,
      viewer: 'If edit granted',
      note: 'Viewers with edit permission can upload new versions.',
    },
    {
      action: 'Grant, modify, or revoke permissions',
      admin: false,
      owner: true,
      viewer: false,
      note: 'Document owners control their document access list.',
    },
    {
      action: 'Soft-delete or restore documents',
      admin: false,
      owner: true,
      viewer: false,
      note: 'Document owners manage their document lifecycle.',
    },
    {
      action: 'Purge document from retention',
      admin: true,
      owner: true,
      viewer: false,
      note: 'Permanent retention purge by owner or compliance admin.',
    },
    {
      action: 'Inspect system-wide audit explorer',
      admin: true,
      owner: false,
      viewer: false,
      note: 'Global audit logs restricted to security administrators.',
    },
    {
      action: 'Inspect document-specific audit history',
      admin: true,
      owner: true,
      viewer: false,
      note: 'Document owners inspect their own document trail.',
    },
    {
      action: 'Provision accounts & assign roles',
      admin: true,
      owner: false,
      viewer: false,
      note: 'Protected administrative endpoint.',
    },
    {
      action: 'Instantly deactivate accounts',
      admin: true,
      owner: false,
      viewer: false,
      note: 'Immediately halts session on the next request.',
    },
  ];

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-cyan-400 font-semibold text-xs uppercase tracking-wider">
          <Settings className="w-4 h-4" />
          <span>Security & Governance</span>
        </div>
        <h1 className="text-2xl font-bold text-white mt-1">Platform Settings & Access Matrix</h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Role-based authorization specifications, active profile details, and cryptographic standards
        </p>
      </div>

      {/* User Profile Card */}
      <div className="p-6 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm space-y-4">
        <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <KeyRound className="w-4 h-4 text-cyan-400" />
          Authenticated Security Principal
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-3.5 rounded-xl bg-vault-surface/40 border border-vault-border">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Name</span>
            <span className="text-slate-100 font-semibold mt-0.5 block">{user?.name}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-vault-surface/40 border border-vault-border">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Email Address</span>
            <span className="text-slate-100 font-mono mt-0.5 block">{user?.email}</span>
          </div>

          <div className="p-3.5 rounded-xl bg-vault-surface/40 border border-vault-border">
            <span className="text-[10px] uppercase font-bold text-slate-400 block">Active Role</span>
            <span className="text-cyan-400 font-bold uppercase mt-0.5 block">{user?.role}</span>
          </div>
        </div>
      </div>

      {/* Role-Permission Matrix */}
      <div className="p-6 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Shield className="w-4 h-4 text-cyan-400" />
              Role-Based Access Control (RBAC) Matrix
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Strictly enforced server-side policy definition across all 3 roles
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-vault-border bg-vault-surface/40 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Operation / Capability</th>
                <th className="py-3 px-4 text-center">Administrator</th>
                <th className="py-3 px-4 text-center">Document Owner</th>
                <th className="py-3 px-4 text-center">Viewer</th>
                <th className="py-3 px-4">Policy Enforcement Rule</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-vault-border/60">
              {permissionsMatrix.map((item, idx) => (
                <tr key={idx} className="hover:bg-vault-surface/30 transition-colors">
                  <td className="py-3 px-4 font-medium text-slate-200">{item.action}</td>
                  {/* Admin */}
                  <td className="py-3 px-4 text-center">
                    {item.admin ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-600 mx-auto" />
                    )}
                  </td>
                  {/* Owner */}
                  <td className="py-3 px-4 text-center">
                    {item.owner ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                    ) : (
                      <XCircle className="w-4 h-4 text-slate-600 mx-auto" />
                    )}
                  </td>
                  {/* Viewer */}
                  <td className="py-3 px-4 text-center">
                    {typeof item.viewer === 'boolean' ? (
                      item.viewer ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 mx-auto" />
                      ) : (
                        <XCircle className="w-4 h-4 text-slate-600 mx-auto" />
                      )
                    ) : (
                      <span className="text-[10px] text-cyan-400 font-semibold px-2 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/20">
                        {item.viewer}
                      </span>
                    )}
                  </td>
                  {/* Note */}
                  <td className="py-3 px-4 text-slate-400 text-[11px]">{item.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Security Specifications */}
      <div className="p-6 rounded-2xl bg-vault-card border border-vault-border shadow-vault-sm space-y-3 text-xs">
        <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
          <Lock className="w-4 h-4 text-cyan-400" />
          Cryptographic & Defense Architecture
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-slate-300">
          <div className="p-3 rounded-xl bg-vault-surface/30 border border-vault-border">
            <div className="font-semibold text-cyan-400 mb-1">Magic Byte Verification</div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Uploads are checked directly in memory for magic byte signatures (PDF, DOCX, XLSX, PPTX, PNG, JPEG).
              Spoofed extensions and disguised executables are rejected with 400 Bad Request.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-vault-surface/30 border border-vault-border">
            <div className="font-semibold text-cyan-400 mb-1">Zero IDOR / Direct Object References</div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Every endpoint receiving a document ID queries permissions dynamically against the database.
              Guessing IDs yields 403 Forbidden with security audit logging.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-vault-surface/30 border border-vault-border">
            <div className="font-semibold text-cyan-400 mb-1">No Public URLs / Authorised Streaming</div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Storage files are kept outside the web root. Files are streamed directly through authenticated
              Express routes with <span className="font-mono text-cyan-300">X-Content-Type-Options: nosniff</span>.
            </p>
          </div>

          <div className="p-3 rounded-xl bg-vault-surface/30 border border-vault-border">
            <div className="font-semibold text-cyan-400 mb-1">Append-Only Audit Immutability</div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              The Mongoose schema enforces pre-hooks blocking update and delete calls at the application level.
              Every operation produces a traceable correlation ID.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
