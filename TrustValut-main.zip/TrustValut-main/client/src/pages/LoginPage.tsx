import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lock, Mail, ArrowRight, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';

export const LoginPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { login, quickLogin } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(email, password);
      navigate('/');
    } catch (err: any) {
      toast.error('Authentication Denied', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDemoSelect = async (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    setLoading(true);
    try {
      await quickLogin(demoEmail, demoPass);
      navigate('/');
    } catch (err: any) {
      toast.error('Authentication Denied', err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-bold tracking-tight text-white">Sign In to Vault</h2>
        <p className="mt-1 text-xs text-slate-400">
          Enter your organization credentials to authenticate
        </p>
      </div>

      {/* Demo Credentials Switcher Box */}
      <div className="p-3.5 rounded-xl bg-vault-surface/80 border border-vault-border space-y-2 text-xs">
        <div className="flex items-center justify-between text-slate-300 font-medium">
          <span className="flex items-center gap-1.5 text-cyan-400">
            <ShieldAlert className="w-3.5 h-3.5" /> Demo Accounts
          </span>
          <span className="text-[10px] text-slate-400">Click to autofill & sign in</span>
        </div>
        <div className="grid grid-cols-1 gap-1.5">
          <button
            type="button"
            onClick={() => handleDemoSelect('admin@trustvault.io', 'TrustVault@Admin2026!')}
            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-left flex items-center justify-between border border-slate-800 transition-colors"
          >
            <span className="font-medium text-slate-200">🛡️ Administrator (CISO)</span>
            <span className="text-[10px] text-slate-400 font-mono">admin@trustvault.io</span>
          </button>
          <button
            type="button"
            onClick={() => handleDemoSelect('sarah.owner@trustvault.io', 'SarahOwner@2026!')}
            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-left flex items-center justify-between border border-slate-800 transition-colors"
          >
            <span className="font-medium text-slate-200">📂 Sarah Chen (Document Owner)</span>
            <span className="text-[10px] text-slate-400 font-mono">sarah.owner@trustvault.io</span>
          </button>
          <button
            type="button"
            onClick={() => handleDemoSelect('alex.viewer@trustvault.io', 'AlexViewer@2026!')}
            className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-left flex items-center justify-between border border-slate-800 transition-colors"
          >
            <span className="font-medium text-slate-200">👁️ Alex Rivera (Auditor / Viewer)</span>
            <span className="text-[10px] text-slate-400 font-mono">alex.viewer@trustvault.io</span>
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4 text-xs">
        <div>
          <label className="font-semibold text-slate-300 block mb-1">Work Email</label>
          <div className="relative">
            <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@company.com"
              className="w-full bg-slate-900 border border-vault-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="font-semibold text-slate-300">Password</label>
            <Link to="/forgot-password" className="text-cyan-400 hover:text-cyan-300 text-[11px]">
              Forgot password?
            </Link>
          </div>
          <div className="relative">
            <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••••••"
              className="w-full bg-slate-900 border border-vault-border rounded-xl pl-10 pr-4 py-2.5 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-vault-sm flex items-center justify-center gap-2 transition-all disabled:opacity-50"
        >
          {loading ? (
            'Authenticating...'
          ) : (
            <>
              <span>Access Secure Vault</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </form>

      <div className="text-center pt-2 border-t border-vault-border text-xs text-slate-400">
        Need a new enterprise account?{' '}
        <Link to="/register" className="text-cyan-400 hover:text-cyan-300 font-semibold">
          Register Onboarding
        </Link>
      </div>
    </div>
  );
};
