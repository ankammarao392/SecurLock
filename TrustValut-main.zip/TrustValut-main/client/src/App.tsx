import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastProvider } from './context/ToastContext';
import { AuthProvider } from './context/AuthContext';
import { AuthLayout } from './layouts/AuthLayout';
import { DashboardLayout } from './layouts/DashboardLayout';
import { LoginPage } from './pages/LoginPage';
import { RegisterPage } from './pages/RegisterPage';
import { ForgotPasswordPage } from './pages/ForgotPasswordPage';
import { ResetPasswordPage } from './pages/ResetPasswordPage';
import { DashboardOverviewPage } from './pages/DashboardOverviewPage';
import { MyVaultPage } from './pages/MyVaultPage';
import { SharedWithMePage } from './pages/SharedWithMePage';
import { AccessManagementPage } from './pages/AccessManagementPage';
import { AuditExplorerPage } from './pages/AuditExplorerPage';
import { CategoriesPage } from './pages/CategoriesPage';
import { UserManagementPage } from './pages/UserManagementPage';
import { SettingsPage } from './pages/SettingsPage';
import { AccessDeniedPage } from './pages/AccessDeniedPage';
import { NotFoundPage } from './pages/NotFoundPage';

export const App: React.FC = () => {
  return (
    <ToastProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            {/* Authenticated Dashboard Routes */}
            <Route path="/" element={<DashboardLayout />}>
              <Route index element={<DashboardOverviewPage />} />
              <Route path="my-vault" element={<MyVaultPage />} />
              <Route path="shared" element={<SharedWithMePage />} />
              <Route path="access" element={<AccessManagementPage />} />
              <Route path="audit" element={<AuditExplorerPage />} />
              <Route path="categories" element={<CategoriesPage />} />
              <Route path="admin/users" element={<UserManagementPage />} />
              <Route path="settings" element={<SettingsPage />} />
            </Route>

            {/* Public Authentication Routes */}
            <Route element={<AuthLayout />}>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />
              <Route path="/forgot-password" element={<ForgotPasswordPage />} />
              <Route path="/reset-password" element={<ResetPasswordPage />} />
            </Route>

            {/* Error and Fallback Routes */}
            <Route path="/access-denied" element={<AccessDeniedPage />} />
            <Route path="/404" element={<NotFoundPage />} />
            <Route path="*" element={<Navigate to="/404" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ToastProvider>
  );
};

export default App;
