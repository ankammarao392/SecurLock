export type UserRole = 'admin' | 'owner' | 'viewer';
export type UserStatus = 'active' | 'disabled';

export type DocumentSensitivity = 'Public' | 'Internal' | 'Confidential' | 'Restricted';
export type DocumentCategory =
  | 'Legal'
  | 'Financial'
  | 'Human Resources'
  | 'Security & Compliance'
  | 'Engineering'
  | 'Executive'
  | 'Operations'
  | 'Other';

export type PermissionType = 'read' | 'edit';
export type UserAccessLevel = 'owner' | 'edit' | 'read' | 'admin_meta';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  createdAt: string;
  lastLoginAt?: string;
}

export interface DocumentItem {
  id: string;
  title: string;
  description?: string;
  category: DocumentCategory;
  originalFilename: string;
  mimeType: string;
  fileSize: number;
  sha256Checksum: string;
  sensitivity: DocumentSensitivity;
  version: number;
  deletedAt?: string | null;
  createdAt: string;
  updatedAt: string;
  owner?: {
    id: string;
    name: string;
    email: string;
  } | null;
  userAccess: UserAccessLevel;
}

export interface DocumentPermissionItem {
  _id: string;
  documentId: string;
  userId: {
    _id: string;
    name: string;
    email: string;
    role: UserRole;
    status: UserStatus;
  };
  permission: PermissionType;
  grantedBy: {
    _id: string;
    name: string;
    email: string;
  };
  grantedAt: string;
  expiresAt?: string | null;
  revokedAt?: string | null;
  isActive: boolean;
}

export interface DocumentVersionItem {
  _id: string;
  documentId: string;
  versionNumber: number;
  storageKey: string;
  checksum: string;
  changedBy: {
    _id: string;
    name: string;
    email: string;
  };
  fileSize: number;
  mimeType: string;
  originalFilename: string;
  description?: string;
  createdAt: string;
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  action: string;
  outcome: 'success' | 'denied';
  correlationId?: string;
  actor: {
    id?: string;
    name: string;
    email: string;
  };
  actorRole?: string;
  document?: {
    id: string;
    title: string;
  } | null;
  ipAddress?: string;
  userAgent?: string;
  reason?: string;
  metadata?: Record<string, any>;
}

export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}
