import React, { useState } from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { Sidebar } from '../components/Sidebar';
import { TopBar } from '../components/TopBar';
import { UploadModal } from '../components/UploadModal';
import { DocumentDrawer } from '../components/DocumentDrawer';
import { AccessModal } from '../components/AccessModal';
import { useAuth } from '../context/AuthContext';
import { DocumentItem } from '../types';
import { documentApi } from '../services/api';
import { useToast } from '../context/ToastContext';

export const DashboardLayout: React.FC = () => {
  const { user, loading } = useAuth();
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<DocumentItem | null>(null);
  const [accessDoc, setAccessDoc] = useState<DocumentItem | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const toast = useToast();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-vault-bg flex items-center justify-center text-cyan-400">
        <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  const handleDownload = async (doc: DocumentItem) => {
    try {
      toast.info('Downloading File', `Streaming "${doc.originalFilename}" from secure storage...`);
      await documentApi.downloadDocument(doc.id, doc.originalFilename);
      toast.success('Download Complete', doc.originalFilename);
    } catch (err: any) {
      toast.error('Download Denied', err.message);
    }
  };

  const handleGlobalSearch = (query: string) => {
    setSearchQuery(query);
  };

  return (
    <div className="min-h-screen bg-vault-bg text-vault-text flex">
      {/* Left Navigation Sidebar */}
      <Sidebar />

      {/* Main Content Area */}
      <div className="flex-1 ml-64 flex flex-col min-w-0 min-h-screen">
        <TopBar
          onSearch={handleGlobalSearch}
          onOpenUpload={() => setIsUploadOpen(true)}
        />

        <main className="flex-1 p-8 overflow-y-auto">
          <Outlet
            context={{
              searchQuery,
              onOpenUpload: () => setIsUploadOpen(true),
              onSelectDocument: (doc: DocumentItem) => setSelectedDoc(doc),
              onManageAccess: (doc: DocumentItem) => setAccessDoc(doc),
              onDownload: handleDownload,
              refreshTrigger,
              triggerRefresh: () => setRefreshTrigger((prev) => prev + 1),
            }}
          />
        </main>
      </div>

      {/* Upload Document Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onUploadSuccess={() => setRefreshTrigger((prev) => prev + 1)}
      />

      {/* Document Properties Detail Drawer */}
      {selectedDoc && (
        <DocumentDrawer
          document={selectedDoc}
          onClose={() => setSelectedDoc(null)}
          onDownload={handleDownload}
          onManageAccess={(doc) => setAccessDoc(doc)}
          onDocumentUpdated={() => setRefreshTrigger((prev) => prev + 1)}
        />
      )}

      {/* Document Access Control Modal */}
      {accessDoc && (
        <AccessModal
          document={accessDoc}
          isOpen={!!accessDoc}
          onClose={() => setAccessDoc(null)}
          onPermissionChanged={() => setRefreshTrigger((prev) => prev + 1)}
        />
      )}
    </div>
  );
};
