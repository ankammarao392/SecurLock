import React from 'react';
import { Shield, Lock } from 'lucide-react';

interface BrandLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showTagline?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ size = 'md', showTagline = false }) => {
  const iconSizes = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-10 h-10',
  };

  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
  };

  return (
    <div className="flex items-center gap-3">
      <div className="relative flex items-center justify-center p-2 rounded-xl bg-gradient-to-br from-cyan-500/20 via-slate-800 to-slate-900 border border-cyan-500/30 shadow-vault-sm">
        <Shield className={`${iconSizes[size]} text-cyan-400`} />
        <Lock className="w-3.5 h-3.5 text-teal-300 absolute inset-0 m-auto" />
      </div>
      <div>
        <div className={`font-bold tracking-tight text-white ${textSizes[size]} flex items-center gap-1.5`}>
          <span>Trust</span>
          <span className="text-cyan-400">Vault</span>
        </div>
        {showTagline && (
          <p className="text-[10px] text-slate-400 tracking-wider uppercase font-medium">
            Your Documents. Your Control.
          </p>
        )}
      </div>
    </div>
  );
};
