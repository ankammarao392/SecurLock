import React, { useState } from 'react';
import { X, UploadCloud, File, AlertCircle, CheckCircle2 } from 'lucide-react';
import { DocumentCategory, DocumentSensitivity } from '../types';
import { documentApi } from '../services/api';
import { useToast } from '../context/ToastContext';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadSuccess: () => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onUploadSuccess,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<DocumentCategory>('Other');
  const [sensitivity, setSensitivity] = useState<DocumentSensitivity>('Internal');
  const [isDragging, setIsDragging] = useState(false);
  const [uploading, setUploading] = useState(false);
  const toast = useToast();

  if (!isOpen) return null;

  const handleFileChange = (selectedFile: File) => {
    // Check size limit: 10 MB
    if (selectedFile.size > 10 * 1024 * 1024) {
      toast.error('File Oversized', 'File exceeds the maximum limit of 10 MB.');
      return;
    }

    setFile(selectedFile);
    if (!title) {
      // Auto-populate title without extension
      const cleanName = selectedFile.name.replace(/\.[^/.]+$/, '');
      setTitle(cleanName.replace(/[-_]/g, ' '));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      toast.error('Validation Error', 'Please select a document file.');
      return;
    }
    if (!title.trim()) {
      toast.error('Validation Error', 'Document title is required.');
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);
    formData.append('title', title.trim());
    formData.append('description', description.trim());
    formData.append('category', category);
    formData.append('sensitivity', sensitivity);

    try {
      const res = await documentApi.uploadDocument(formData);
      if (res.data.success) {
        toast.success(
          'Document Uploaded',
          `"${res.data.data.document.title}" encrypted and secured.`
        );
        onUploadSuccess();
        onClose();
      }
    } catch (err: any) {
      toast.error('Upload Failed', err.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-lg bg-vault-card border border-vault-border rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="p-6 border-b border-vault-border flex items-center justify-between bg-vault-surface/30">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <UploadCloud className="w-5 h-5 text-cyan-400" />
              Secure Document Deposit
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Files are verified by cryptographic magic bytes and stored encrypted.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          {/* Dropzone */}
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setIsDragging(true);
            }}
            onDragLeave={() => setIsDragging(false)}
            onDrop={(e) => {
              e.preventDefault();
              setIsDragging(false);
              if (e.dataTransfer.files?.[0]) {
                handleFileChange(e.dataTransfer.files[0]);
              }
            }}
            className={`border-2 border-dashed rounded-xl p-6 text-center transition-all cursor-pointer ${
              isDragging
                ? 'border-cyan-400 bg-cyan-500/10'
                : file
                ? 'border-emerald-500/50 bg-emerald-500/5'
                : 'border-vault-border hover:border-slate-600 bg-vault-surface/20'
            }`}
            onClick={() => document.getElementById('vault-file-input')?.click()}
          >
            <input
              id="vault-file-input"
              type="file"
              onChange={(e) => {
                if (e.target.files?.[0]) handleFileChange(e.target.files[0]);
              }}
              className="hidden"
            />
            {file ? (
              <div className="flex items-center justify-center gap-3 text-emerald-400">
                <CheckCircle2 className="w-6 h-6" />
                <div className="text-left">
                  <div className="font-semibold text-slate-100 text-xs">{file.name}</div>
                  <div className="text-[11px] text-slate-400">{(file.size / 1024).toFixed(1)} KB</div>
                </div>
              </div>
            ) : (
              <div>
                <UploadCloud className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
                <p className="text-slate-200 font-medium">
                  Click to browse or drop confidential document here
                </p>
                <p className="text-[10px] text-slate-400 mt-1">
                  Supported: PDF, DOCX, XLSX, PPTX, PNG, JPEG (Max 10 MB)
                </p>
              </div>
            )}
          </div>

          {/* Document Title */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1">Document Title *</label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. FY2026 Q3 Board Audit & Revenue Forecast"
              className="w-full bg-slate-900 border border-vault-border rounded-xl px-3.5 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Category & Sensitivity */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-semibold text-slate-300 block mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as DocumentCategory)}
                className="w-full bg-slate-900 border border-vault-border rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="Legal">Legal</option>
                <option value="Financial">Financial</option>
                <option value="Human Resources">Human Resources</option>
                <option value="Security & Compliance">Security & Compliance</option>
                <option value="Engineering">Engineering</option>
                <option value="Executive">Executive</option>
                <option value="Operations">Operations</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-300 block mb-1">Sensitivity Level</label>
              <select
                value={sensitivity}
                onChange={(e) => setSensitivity(e.target.value as DocumentSensitivity)}
                className="w-full bg-slate-900 border border-vault-border rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="Public">Public</option>
                <option value="Internal">Internal</option>
                <option value="Confidential">Confidential</option>
                <option value="Restricted">Restricted (High Risk)</option>
              </select>
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="font-semibold text-slate-300 block mb-1">Description (Optional)</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Notes on confidential content, intended recipients, or retention obligations..."
              className="w-full bg-slate-900 border border-vault-border rounded-xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={uploading}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold shadow-vault-sm transition-all disabled:opacity-50"
            >
              {uploading ? 'Validating Magic Bytes & Encrypting...' : 'Deposit Document'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
