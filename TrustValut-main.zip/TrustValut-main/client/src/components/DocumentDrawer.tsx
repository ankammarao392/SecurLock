import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  Share2,
  Upload,
  History,
  ShieldAlert,
  Clock,
  User,
  Hash,
  FileCheck,
  Check,
  Copy,
} from 'lucide-react';
import { DocumentItem, DocumentVersionItem, AuditLogItem } from '../types';
import { documentApi, auditApi } from '../services/api';
import { useToast } from '../context/ToastContext';

interface DocumentDrawerProps {
  document: DocumentItem | null;
  onClose: () => void;
  onDownload: (doc: DocumentItem) => void;
  onManageAccess?: (doc: DocumentItem) => void;
  onDocumentUpdated?: () => void;
}

export const DocumentDrawer: React.FC<DocumentDrawerProps> = ({
  document,
  onClose,
  onDownload,
  onManageAccess,
  onDocumentUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'details' | 'versions' | 'audit'>('details');
  const [versions, setVersions] = useState<DocumentVersionItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [loadingVersions, setLoadingVersions] = useState(false);
  const [loadingAudit, setLoadingAudit] = useState(false);
  const [copiedHash, setCopiedHash] = useState(false);
  const [uploadingVersion, setUploadingVersion] = useState(false);
  const [versionDescription, setVersionDescription] = useState('');
  const toast = useToast();

  useEffect(() => {
    if (!document) return;

    if (activeTab === 'versions') {
      loadVersions();
    } else if (activeTab === 'audit') {
      loadAudit();
    }
  }, [document, activeTab]);

  const loadVersions = async () => {
    if (!document) return;
    setLoadingVersions(true);
    try {
      const res = await documentApi.getVersions(document.id);
      if (res.data.success) {
        setVersions(res.data.data.versions);
      }
    } catch (err: any) {
      toast.error('Failed to load version history', err.message);
    } finally {
      setLoadingVersions(false);
    }
  };

  const loadAudit = async () => {
    if (!document) return;
    setLoadingAudit(true);
    try {
      const res = await auditApi.getDocumentAudit(document.id);
      if (res.data.success) {
        setAuditLogs(res.data.data.logs);
      }
    } catch (err: any) {
      toast.error('Audit access restricted', err.message);
    } finally {
      setLoadingAudit(false);
    }
  };

  const handleCopyHash = () => {
    if (document) {
      navigator.clipboard.writeText(document.sha256Checksum);
      setCopiedHash(true);
      setTimeout(() => setCopiedHash(false), 2000);
    }
  };

  const handleUploadVersionFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !document) return;

    setUploadingVersion(true);
    const formData = new FormData();
    formData.append('file', file);
    if (versionDescription) {
      formData.append('description', versionDescription);
    }

    try {
      const res = await documentApi.uploadVersion(document.id, formData);
      if (res.data.success) {
        toast.success('Version Created', `Updated to version ${res.data.data.document.version}`);
        setVersionDescription('');
        loadVersions();
        if (onDocumentUpdated) onDocumentUpdated();
      }
    } catch (err: any) {
      toast.error('Version Upload Failed', err.message);
    } finally {
      setUploadingVersion(false);
      e.target.value = '';
    }
  };

  if (!document) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-lg bg-vault-card border-l border-vault-border shadow-2xl z-40 flex flex-col animate-slide-left">
      {/* Drawer Header */}
      <div className="p-6 border-b border-vault-border flex items-start justify-between bg-vault-surface/30">
        <div>
          <span className="text-[10px] uppercase font-bold tracking-wider text-cyan-400 bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">
            {document.category}
          </span>
          <h2 className="text-lg font-bold text-slate-100 mt-2 line-clamp-1">{document.title}</h2>
          <p className="text-xs text-slate-400 mt-0.5">{document.originalFilename}</p>
        </div>
        <button
          onClick={onClose}
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-vault-border bg-vault-surface/10 px-6">
        <button
          onClick={() => setActiveTab('details')}
          className={`py-3 px-3 text-xs font-semibold border-b-2 transition-all ${
            activeTab === 'details'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Security Properties
        </button>
        <button
          onClick={() => setActiveTab('versions')}
          className={`py-3 px-3 text-xs font-semibold border-b-2 transition-all ${
            activeTab === 'versions'
              ? 'border-cyan-400 text-cyan-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Versions ({document.version})
        </button>
        {(document.userAccess === 'owner' || document.userAccess === 'admin_meta') && (
          <button
            onClick={() => setActiveTab('audit')}
            className={`py-3 px-3 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'audit'
                ? 'border-cyan-400 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Audit Trail
          </button>
        )}
      </div>

      {/* Drawer Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {activeTab === 'details' && (
          <div className="space-y-6 text-xs">
            {/* Description */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                Description
              </label>
              <p className="text-slate-300 bg-vault-surface/40 p-3 rounded-xl border border-vault-border leading-relaxed">
                {document.description || 'No description provided for this confidential document.'}
              </p>
            </div>

            {/* SHA-256 Fingerprint */}
            <div>
              <label className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-1.5 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Hash className="w-3.5 h-3.5 text-cyan-400" />
                  SHA-256 Checksum Fingerprint
                </span>
                <button
                  onClick={handleCopyHash}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 normal-case font-normal"
                >
                  {copiedHash ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  {copiedHash ? 'Copied' : 'Copy'}
                </button>
              </label>
              <div className="p-2.5 rounded-xl bg-slate-950 font-mono text-[11px] text-cyan-400/90 break-all border border-slate-800">
                {document.sha256Checksum}
              </div>
            </div>

            {/* Metadata Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-xl bg-vault-surface/40 border border-vault-border">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Sensitivity</span>
                <span className="text-slate-100 font-bold text-sm mt-0.5 block">{document.sensitivity}</span>
              </div>
              <div className="p-3 rounded-xl bg-vault-surface/40 border border-vault-border">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">File Size</span>
                <span className="text-slate-100 font-bold text-sm mt-0.5 block">
                  {(document.fileSize / 1024).toFixed(1)} KB
                </span>
              </div>
              <div className="p-3 rounded-xl bg-vault-surface/40 border border-vault-border">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">MIME Type</span>
                <span className="text-slate-200 font-mono text-[11px] mt-0.5 block truncate">
                  {document.mimeType}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-vault-surface/40 border border-vault-border">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block">Owner</span>
                <span className="text-slate-200 font-medium text-xs mt-0.5 block truncate">
                  {document.owner?.name || 'Owner'}
                </span>
              </div>
            </div>

            {/* Timestamps */}
            <div className="space-y-2 pt-2 border-t border-vault-border text-slate-400 text-[11px]">
              <div className="flex justify-between">
                <span>Created At:</span>
                <span className="text-slate-300 font-medium">
                  {new Date(document.createdAt).toLocaleString()}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Last Updated:</span>
                <span className="text-slate-300 font-medium">
                  {new Date(document.updatedAt).toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'versions' && (
          <div className="space-y-4">
            {/* Upload New Version Section (if editor or owner) */}
            {(document.userAccess === 'owner' || document.userAccess === 'edit') && (
              <div className="p-4 rounded-xl bg-vault-surface/60 border border-vault-border space-y-3">
                <h4 className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                  <Upload className="w-4 h-4 text-cyan-400" /> Upload New Version
                </h4>
                <input
                  type="text"
                  value={versionDescription}
                  onChange={(e) => setVersionDescription(e.target.value)}
                  placeholder="Change summary / revision note..."
                  className="w-full bg-slate-900 border border-vault-border rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <label className="flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-cyanAccent/10 text-cyan-400 border border-cyan-500/20 font-semibold text-xs cursor-pointer hover:bg-cyanAccent/20 transition-all">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{uploadingVersion ? 'Verifying & Encrypting...' : 'Select File for New Version'}</span>
                  <input
                    type="file"
                    onChange={handleUploadVersionFile}
                    disabled={uploadingVersion}
                    className="hidden"
                  />
                </label>
              </div>
            )}

            {/* Version List */}
            {loadingVersions ? (
              <div className="p-8 text-center text-slate-400 text-xs">Loading versions...</div>
            ) : (
              <div className="space-y-2.5">
                {versions.map((ver) => (
                  <div
                    key={ver._id}
                    className="p-3.5 rounded-xl bg-vault-surface/40 border border-vault-border text-xs space-y-1.5"
                  >
                    <div className="flex items-center justify-between font-semibold">
                      <span className="text-cyan-400 font-mono">Version {ver.versionNumber}</span>
                      <span className="text-[10px] text-slate-400">
                        {new Date(ver.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-slate-300 text-[11px]">{ver.description || 'No description'}</p>
                    <div className="pt-1 flex items-center justify-between text-[10px] text-slate-400">
                      <span>Changed by: {ver.changedBy?.name || 'Owner'}</span>
                      <span className="font-mono">{(ver.fileSize / 1024).toFixed(1)} KB</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'audit' && (
          <div>
            {loadingAudit ? (
              <div className="p-8 text-center text-slate-400 text-xs">Loading document audit trail...</div>
            ) : auditLogs.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">No audit events recorded yet.</div>
            ) : (
              <div className="space-y-3">
                {auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className={`p-3 rounded-xl border text-xs space-y-1 ${
                      log.outcome === 'success'
                        ? 'bg-vault-surface/40 border-vault-border'
                        : 'bg-rose-500/10 border-rose-500/20 text-rose-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-200">{log.action}</span>
                      <span
                        className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${
                          log.outcome === 'success'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {log.outcome}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Actor: {log.actor.email} ({log.actorRole || 'user'})
                    </div>
                    {log.reason && <div className="text-[11px] text-rose-400 font-medium">{log.reason}</div>}
                    <div className="text-[10px] text-slate-500">{new Date(log.timestamp).toLocaleString()}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Drawer Footer Actions */}
      <div className="p-6 border-t border-vault-border bg-vault-surface/40 flex items-center gap-3">
        {document.userAccess !== 'admin_meta' && (
          <button
            onClick={() => onDownload(document)}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs transition-all shadow-vault-sm"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Download File</span>
          </button>
        )}
        {document.userAccess === 'owner' && onManageAccess && (
          <button
            onClick={() => {
              onClose();
              onManageAccess(document);
            }}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-vault-surface hover:bg-vault-hover text-slate-200 border border-vault-border font-medium text-xs transition-colors"
          >
            <Share2 className="w-4 h-4 text-cyan-400" />
            <span>Manage Access</span>
          </button>
        )}
      </div>
    </div>
  );
};
