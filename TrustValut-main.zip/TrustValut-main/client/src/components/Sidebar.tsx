import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderLock,
  Share2,
  KeyRound,
  FileSearch,
  Layers,
  Users,
  Settings,
  LogOut,
  ShieldAlert,
  ChevronDown,
} from 'lucide-react';
import { BrandLogo } from './BrandLogo';
import { useAuth } from '../context/AuthContext';

export const Sidebar: React.FC = () => {
  const { user, logout, quickLogin } = useAuth();
  const navigate = useNavigate();

  const navItems = [
    { label: 'Overview', path: '/', icon: LayoutDashboard },
    { label: 'My Vault', path: '/my-vault', icon: FolderLock },
    { label: 'Shared With Me', path: '/shared', icon: Share2 },
    { label: 'Access Management', path: '/access', icon: KeyRound },
    { label: 'Audit Explorer', path: '/audit', icon: FileSearch, adminOnly: true },
    { label: 'Categories', path: '/categories', icon: Layers },
    ...(user?.role === 'admin'
      ? [{ label: 'User Directory', path: '/admin/users', icon: Users }]
      : []),
    { label: 'Settings', path: '/settings', icon: Settings },
  ];

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <aside className="w-64 bg-vault-card border-r border-vault-border flex flex-col h-screen fixed left-0 top-0 z-30 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-vault-border">
        <BrandLogo size="md" showTagline />
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        <div className="px-3 pb-2 text-[11px] font-semibold tracking-wider text-slate-500 uppercase">
          Security Platform
        </div>
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? 'bg-cyanAccent/10 text-cyan-400 border border-cyan-500/20 shadow-vault-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-vault-surface/60'
                }`
              }
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Demo Switcher Quick Bar */}
      <div className="p-3 mx-3 mb-3 bg-vault-surface/70 rounded-xl border border-vault-border text-xs">
        <div className="flex items-center justify-between text-slate-400 font-medium mb-2">
          <span className="flex items-center gap-1.5 text-cyan-400">
            <ShieldAlert className="w-3.5 h-3.5" /> Demo Switcher
          </span>
          <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded">Quick Test</span>
        </div>
        <div className="grid grid-cols-2 gap-1.5">
          <button
            onClick={() => quickLogin('admin@trustvault.io', 'TrustVault@Admin2026!')}
            className={`px-2 py-1.5 rounded text-[11px] text-left transition-colors truncate ${
              user?.role === 'admin'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
            }`}
          >
            🛡️ Admin
          </button>
          <button
            onClick={() => quickLogin('sarah.owner@trustvault.io', 'SarahOwner@2026!')}
            className={`px-2 py-1.5 rounded text-[11px] text-left transition-colors truncate ${
              user?.email.includes('sarah')
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
            }`}
          >
            📂 Sarah (Owner)
          </button>
          <button
            onClick={() => quickLogin('marcus.sec@trustvault.io', 'MarcusSec@2026!')}
            className={`px-2 py-1.5 rounded text-[11px] text-left transition-colors truncate ${
              user?.email.includes('marcus')
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
            }`}
          >
            🔐 Marcus (Owner)
          </button>
          <button
            onClick={() => quickLogin('alex.viewer@trustvault.io', 'AlexViewer@2026!')}
            className={`px-2 py-1.5 rounded text-[11px] text-left transition-colors truncate ${
              user?.email.includes('alex')
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-300'
            }`}
          >
            👁️ Alex (Viewer)
          </button>
        </div>
      </div>

      {/* User Status & Logout Footer */}
      <div className="p-3 border-t border-vault-border flex items-center justify-between bg-vault-card/60">
        <div className="flex items-center gap-2.5 overflow-hidden">
          <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs text-cyan-400 uppercase flex-shrink-0">
            {user?.name?.slice(0, 2) || 'TV'}
          </div>
          <div className="overflow-hidden">
            <div className="text-xs font-medium text-slate-200 truncate">{user?.name}</div>
            <div className="text-[10px] text-slate-400 capitalize">{user?.role} Role</div>
          </div>
        </div>
        <button
          onClick={handleLogout}
          title="Sign Out"
          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
