import React, { useState, useEffect } from 'react';
import {
  X,
  UserCheck,
  UserX,
  Search,
  Calendar,
  Shield,
  Clock,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';
import { DocumentItem, DocumentPermissionItem, PermissionType } from '../types';
import { permissionApi, userLookupApi } from '../services/api';
import { useToast } from '../context/ToastContext';

interface AccessModalProps {
  document: DocumentItem | null;
  isOpen: boolean;
  onClose: () => void;
  onPermissionChanged?: () => void;
}

export const AccessModal: React.FC<AccessModalProps> = ({
  document,
  isOpen,
  onClose,
  onPermissionChanged,
}) => {
  const [permissions, setPermissions] = useState<DocumentPermissionItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchUserQuery, setSearchUserQuery] = useState('');
  const [userSuggestions, setUserSuggestions] = useState<
    { id: string; name: string; email: string; role: string }[]
  >([]);
  const [selectedUser, setSelectedUser] = useState<{
    id: string;
    name: string;
    email: string;
  } | null>(null);
  const [grantType, setGrantType] = useState<PermissionType>('read');
  const [expiryDays, setExpiryDays] = useState<string>('30');
  const [granting, setGranting] = useState(false);
  const toast = useToast();

  useEffect(() => {
    if (document && isOpen) {
      loadPermissions();
    }
  }, [document, isOpen]);

  useEffect(() => {
    if (searchUserQuery.trim().length >= 2) {
      userLookupApi.search(searchUserQuery).then((res) => {
        if (res.data.success) {
          // Filter out document owner
          setUserSuggestions(
            res.data.data.users.filter((u) => u.id !== document?.owner?.id)
          );
        }
      });
    } else {
      setUserSuggestions([]);
    }
  }, [searchUserQuery, document]);

  const loadPermissions = async () => {
    if (!document) return;
    setLoading(true);
    try {
      const res = await permissionApi.getPermissions(document.id);
      if (res.data.success) {
        setPermissions(res.data.data.permissions);
      }
    } catch (err: any) {
      toast.error('Failed to load permissions', err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGrant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!document || !selectedUser) {
      toast.error('Error', 'Please select a registered user to grant access.');
      return;
    }

    setGranting(true);
    let expiresAt: string | null = null;
    if (expiryDays !== 'never') {
      const days = parseInt(expiryDays, 10);
      const d = new Date();
      d.setDate(d.getDate() + days);
      expiresAt = d.toISOString();
    }

    try {
      const res = await permissionApi.grantPermission(document.id, {
        userId: selectedUser.id,
        permission: grantType,
        expiresAt,
      });

      if (res.data.success) {
        toast.success(
          'Permission Granted',
          `${grantType === 'read' ? 'Read' : 'Edit'} access granted to ${selectedUser.email}`
        );
        setSelectedUser(null);
        setSearchUserQuery('');
        loadPermissions();
        if (onPermissionChanged) onPermissionChanged();
      }
    } catch (err: any) {
      toast.error('Grant Failed', err.message);
    } finally {
      setGranting(false);
    }
  };

  const handleRevoke = async (permissionId: string, userEmail: string) => {
    if (!document) return;
    try {
      const res = await permissionApi.revokePermission(document.id, permissionId);
      if (res.data.success) {
        toast.success('Access Revoked', `Access for ${userEmail} was instantly terminated.`);
        loadPermissions();
        if (onPermissionChanged) onPermissionChanged();
      }
    } catch (err: any) {
      toast.error('Revocation Failed', err.message);
    }
  };

  if (!isOpen || !document) return null;

  const activePermissions = permissions.filter((p) => p.isActive);
  const revokedPermissions = permissions.filter((p) => !p.isActive);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-2xl bg-vault-card border border-vault-border rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-6 border-b border-vault-border flex items-center justify-between bg-vault-surface/30">
          <div>
            <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
              <Shield className="w-5 h-5 text-cyan-400" />
              Document Access Control & Authorizations
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
              Document: <span className="text-cyan-300 font-medium">{document.title}</span>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-xs">
          {/* Grant Permission Form */}
          <form onSubmit={handleGrant} className="p-4 rounded-xl bg-vault-surface/50 border border-vault-border space-y-4">
            <h4 className="font-bold text-slate-200 text-xs flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-cyan-400" />
              Grant Document Permission to Registered User
            </h4>

            {/* User Search Input */}
            <div className="relative">
              <label className="font-semibold text-slate-400 block mb-1">Search User *</label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={selectedUser ? `${selectedUser.name} (${selectedUser.email})` : searchUserQuery}
                  onChange={(e) => {
                    setSelectedUser(null);
                    setSearchUserQuery(e.target.value);
                  }}
                  placeholder="Type name or email to search registered users..."
                  className="w-full bg-slate-900 border border-vault-border rounded-xl pl-9 pr-4 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                />
                {selectedUser && (
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedUser(null);
                      setSearchUserQuery('');
                    }}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Suggestions Dropdown */}
              {!selectedUser && userSuggestions.length > 0 && (
                <div className="absolute left-0 right-0 mt-1 bg-vault-card border border-vault-border rounded-xl shadow-xl z-20 overflow-hidden divide-y divide-vault-border">
                  {userSuggestions.map((u) => (
                    <div
                      key={u.id}
                      onClick={() => {
                        setSelectedUser(u);
                        setUserSuggestions([]);
                      }}
                      className="p-2.5 hover:bg-vault-surface cursor-pointer flex items-center justify-between"
                    >
                      <div>
                        <div className="font-semibold text-slate-200 text-xs">{u.name}</div>
                        <div className="text-[11px] text-slate-400">{u.email}</div>
                      </div>
                      <span className="text-[10px] uppercase font-bold text-cyan-400 px-1.5 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/20">
                        {u.role}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Permission Type & Expiry */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-400 block mb-1">Permission Level</label>
                <select
                  value={grantType}
                  onChange={(e) => setGrantType(e.target.value as PermissionType)}
                  className="w-full bg-slate-900 border border-vault-border rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="read">Read Only (View & Download)</option>
                  <option value="edit">Edit (Modify Metadata & Upload Versions)</option>
                </select>
              </div>

              <div>
                <label className="font-semibold text-slate-400 block mb-1">Access Expiration</label>
                <select
                  value={expiryDays}
                  onChange={(e) => setExpiryDays(e.target.value)}
                  className="w-full bg-slate-900 border border-vault-border rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                >
                  <option value="7">7 Days</option>
                  <option value="30">30 Days</option>
                  <option value="90">90 Days</option>
                  <option value="365">1 Year</option>
                  <option value="never">Permanent (Until Revoked)</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end pt-1">
              <button
                type="submit"
                disabled={!selectedUser || granting}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold shadow-vault-sm transition-all disabled:opacity-40"
              >
                {granting ? 'Authorizing...' : 'Grant Access'}
              </button>
            </div>
          </form>

          {/* Active Authorizations List */}
          <div>
            <h4 className="font-bold text-slate-200 text-xs mb-3 flex items-center justify-between">
              <span>Currently Authorized Collaborators ({activePermissions.length})</span>
              <span className="text-[10px] text-cyan-400 font-normal">Immediate Revocation Active</span>
            </h4>

            {loading ? (
              <div className="p-6 text-center text-slate-400">Loading access authorizations...</div>
            ) : activePermissions.length === 0 ? (
              <div className="p-6 text-center text-slate-500 bg-vault-surface/20 rounded-xl border border-vault-border">
                No external collaborators authorized. Only document owner has access.
              </div>
            ) : (
              <div className="space-y-2">
                {activePermissions.map((perm) => (
                  <div
                    key={perm._id}
                    className="p-3 rounded-xl bg-vault-surface/40 border border-vault-border flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-xs text-slate-200 uppercase">
                        {perm.userId?.name?.slice(0, 1) || 'U'}
                      </div>
                      <div>
                        <div className="font-semibold text-slate-200 text-xs flex items-center gap-2">
                          <span>{perm.userId?.name || 'Unknown User'}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              perm.permission === 'edit'
                                ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                                : 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20'
                            }`}
                          >
                            {perm.permission}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                          <span>{perm.userId?.email}</span>
                          <span>•</span>
                          <span>
                            {perm.expiresAt
                              ? `Expires ${new Date(perm.expiresAt).toLocaleDateString()}`
                              : 'Permanent'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleRevoke(perm._id, perm.userId?.email || 'User')}
                      title="Instantly Revoke Access"
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 font-semibold text-[11px] transition-colors"
                    >
                      <UserX className="w-3.5 h-3.5" />
                      <span>Revoke</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Historical Revocations */}
          {revokedPermissions.length > 0 && (
            <div className="pt-2 border-t border-vault-border">
              <h5 className="font-semibold text-slate-400 text-[11px] uppercase tracking-wider mb-2">
                Permission History (Audit Preserved)
              </h5>
              <div className="space-y-1.5">
                {revokedPermissions.map((rev) => (
                  <div
                    key={rev._id}
                    className="p-2.5 rounded-lg bg-slate-900/40 border border-vault-border/60 flex items-center justify-between text-[11px] text-slate-400"
                  >
                    <span>
                      {rev.userId?.name} ({rev.userId?.email}) — <span className="capitalize">{rev.permission}</span>
                    </span>
                    <span className="text-rose-400 font-medium">
                      Revoked {rev.revokedAt ? new Date(rev.revokedAt).toLocaleDateString() : ''}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
