import React, { useState } from 'react';
import { Search, Bell, ShieldCheck, Plus, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface TopBarProps {
  onSearch?: (query: string) => void;
  onOpenUpload?: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onSearch, onOpenUpload }) => {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [showNotifications, setShowNotifications] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchTerm(val);
    if (onSearch) {
      onSearch(val);
    }
  };

  const roleBadgeColors: Record<string, string> = {
    admin: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    owner: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
    viewer: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
  };

  return (
    <header className="h-16 border-b border-vault-border bg-vault-card/80 backdrop-blur-md sticky top-0 z-20 px-8 flex items-center justify-between">
      {/* Global Search */}
      <div className="relative w-96">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={searchTerm}
          onChange={handleSearchChange}
          placeholder="Search encrypted vault by title or content..."
          className="w-full bg-vault-surface/70 border border-vault-border rounded-xl pl-10 pr-4 py-2 text-xs text-slate-200 placeholder-slate-400 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/30 transition-all"
        />
      </div>

      {/* Right Controls & Status */}
      <div className="flex items-center gap-4">
        {/* Zero-Trust Compliance Badge */}
        <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-700/80 text-[11px] font-medium text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Zero-Trust Policy Enforced</span>
        </div>

        {/* Upload Button */}
        {onOpenUpload && (
          <button
            onClick={onOpenUpload}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-semibold text-xs transition-all shadow-vault-sm"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            <span>Upload Document</span>
          </button>
        )}

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="p-2 rounded-xl border border-vault-border bg-vault-surface hover:bg-vault-hover text-slate-400 hover:text-slate-200 transition-colors relative"
          >
            <Bell className="w-4 h-4" />
            <span className="w-2 h-2 rounded-full bg-cyan-400 absolute top-1.5 right-1.5"></span>
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 rounded-xl bg-vault-card border border-vault-border shadow-vault-md p-4 z-50 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-vault-border mb-3 font-semibold text-slate-200">
                <span>Security Notifications</span>
                <span className="text-[10px] text-cyan-400 font-normal">Real-Time</span>
              </div>
              <div className="space-y-2.5">
                <div className="p-2.5 rounded-lg bg-vault-surface border border-vault-border">
                  <div className="font-medium text-slate-200">Encrypted Session Established</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">TLS 1.3 / HTTP-only token issued</div>
                </div>
                <div className="p-2.5 rounded-lg bg-vault-surface border border-vault-border">
                  <div className="font-medium text-slate-200">Audit Daemon Active</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">Append-only compliance logging running</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User Pill */}
        <div className="flex items-center gap-3 pl-2 border-l border-vault-border">
          <div className="text-right hidden sm:block">
            <div className="text-xs font-medium text-slate-200">{user?.name}</div>
            <div className="text-[10px] text-slate-400">{user?.email}</div>
          </div>
          <span
            className={`px-2.5 py-0.5 rounded-full text-[10px] uppercase font-bold tracking-wider border ${
              user?.role ? roleBadgeColors[user.role] : ''
            }`}
          >
            {user?.role}
          </span>
        </div>
      </div>
    </header>
  );
};
