import React from 'react';
import {
  FileText,
  FileSpreadsheet,
  Presentation,
  Image as ImageIcon,
  File,
  Download,
  Share2,
  Trash2,
  RotateCcw,
  Eye,
  History,
  Lock,
  Copy,
  Check,
} from 'lucide-react';
import { DocumentItem } from '../types';

interface DocumentTableProps {
  documents: DocumentItem[];
  loading: boolean;
  onSelectDocument: (doc: DocumentItem) => void;
  onDownload: (doc: DocumentItem) => void;
  onManageAccess?: (doc: DocumentItem) => void;
  onDelete?: (doc: DocumentItem) => void;
  onRestore?: (doc: DocumentItem) => void;
  isTrashView?: boolean;
}

export const DocumentTable: React.FC<DocumentTableProps> = ({
  documents,
  loading,
  onSelectDocument,
  onDownload,
  onManageAccess,
  onDelete,
  onRestore,
  isTrashView = false,
}) => {
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  const copyChecksum = (hash: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(hash);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getFileIcon = (mimeType: string) => {
    if (mimeType.includes('pdf')) return <FileText className="w-5 h-5 text-rose-400" />;
    if (mimeType.includes('word') || mimeType.includes('document'))
      return <FileText className="w-5 h-5 text-cyan-400" />;
    if (mimeType.includes('sheet') || mimeType.includes('excel'))
      return <FileSpreadsheet className="w-5 h-5 text-emerald-400" />;
    if (mimeType.includes('presentation') || mimeType.includes('powerpoint'))
      return <Presentation className="w-5 h-5 text-amber-400" />;
    if (mimeType.includes('image')) return <ImageIcon className="w-5 h-5 text-purple-400" />;
    return <File className="w-5 h-5 text-slate-400" />;
  };

  const getSensitivityBadge = (level: string) => {
    const config: Record<string, { bg: string; text: string; border: string }> = {
      Public: { bg: 'bg-slate-500/10', text: 'text-slate-300', border: 'border-slate-500/20' },
      Internal: { bg: 'bg-cyan-500/10', text: 'text-cyan-400', border: 'border-cyan-500/20' },
      Confidential: { bg: 'bg-amber-500/10', text: 'text-amber-400', border: 'border-amber-500/20' },
      Restricted: { bg: 'bg-rose-500/10', text: 'text-rose-400', border: 'border-rose-500/20' },
    };
    const c = config[level] || config.Internal;
    return (
      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold border ${c.bg} ${c.text} ${c.border}`}>
        {level}
      </span>
    );
  };

  const getAccessBadge = (access: string) => {
    if (access === 'owner') {
      return (
        <span className="px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[10px] font-medium">
          Owner
        </span>
      );
    }
    if (access === 'edit') {
      return (
        <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-medium">
          Editor
        </span>
      );
    }
    if (access === 'admin_meta') {
      return (
        <span className="px-2 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 text-[10px] font-medium">
          Audit Only
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded bg-slate-500/10 text-slate-400 border border-slate-500/20 text-[10px] font-medium">
        Viewer
      </span>
    );
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  if (loading) {
    return (
      <div className="w-full p-12 text-center text-slate-400 bg-vault-card rounded-2xl border border-vault-border">
        <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
        <p className="text-sm font-medium">Decrypting and loading documents...</p>
      </div>
    );
  }

  if (documents.length === 0) {
    return (
      <div className="w-full p-16 text-center text-slate-400 bg-vault-card rounded-2xl border border-vault-border">
        <Lock className="w-10 h-10 text-slate-600 mx-auto mb-3" />
        <h3 className="text-base font-semibold text-slate-200">No documents found</h3>
        <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
          {isTrashView
            ? 'The trash bin is currently empty.'
            : 'No documents match the active filter or scope in this vault.'}
        </p>
      </div>
    );
  }

  return (
    <div className="w-full bg-vault-card rounded-2xl border border-vault-border overflow-hidden shadow-vault-md">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-vault-border bg-vault-surface/40 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              <th className="py-3.5 px-4">Document</th>
              <th className="py-3.5 px-4">Category</th>
              <th className="py-3.5 px-4">Sensitivity</th>
              <th className="py-3.5 px-4">Owner</th>
              <th className="py-3.5 px-4">Access</th>
              <th className="py-3.5 px-4">SHA-256 Checksum</th>
              <th className="py-3.5 px-4">Modified</th>
              <th className="py-3.5 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-vault-border/60 text-xs">
            {documents.map((doc) => (
              <tr
                key={doc.id}
                onClick={() => onSelectDocument(doc)}
                className="hover:bg-vault-surface/50 transition-colors cursor-pointer group"
              >
                {/* Document Name & Type */}
                <td className="py-3.5 px-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-xl bg-vault-surface border border-vault-border">
                      {getFileIcon(doc.mimeType)}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-100 group-hover:text-cyan-300 transition-colors truncate max-w-xs">
                        {doc.title}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                        <span>{doc.originalFilename}</span>
                        <span>•</span>
                        <span>{formatFileSize(doc.fileSize)}</span>
                        <span>•</span>
                        <span className="font-mono text-[10px] text-cyan-400">v{doc.version}</span>
                      </div>
                    </div>
                  </div>
                </td>

                {/* Category */}
                <td className="py-3.5 px-4 text-slate-300 font-medium">
                  {doc.category}
                </td>

                {/* Sensitivity */}
                <td className="py-3.5 px-4">
                  {getSensitivityBadge(doc.sensitivity)}
                </td>

                {/* Owner */}
                <td className="py-3.5 px-4">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center text-[10px] text-slate-300 font-bold uppercase">
                      {doc.owner?.name?.slice(0, 1) || 'O'}
                    </div>
                    <span className="text-slate-300 truncate max-w-[120px]">
                      {doc.owner?.name || 'Owner'}
                    </span>
                  </div>
                </td>

                {/* Access */}
                <td className="py-3.5 px-4">
                  {getAccessBadge(doc.userAccess)}
                </td>

                {/* SHA-256 Checksum Tag */}
                <td className="py-3.5 px-4">
                  <button
                    onClick={(e) => copyChecksum(doc.sha256Checksum, doc.id, e)}
                    title="Click to copy SHA-256 Checksum"
                    className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-900 border border-slate-800 font-mono text-[10px] text-slate-400 hover:text-cyan-400 hover:border-cyan-500/40 transition-all"
                  >
                    <span>{doc.sha256Checksum.slice(0, 10)}...</span>
                    {copiedId === doc.id ? (
                      <Check className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </button>
                </td>

                {/* Updated At */}
                <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                  {new Date(doc.updatedAt).toLocaleDateString(undefined, {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric',
                  })}
                </td>

                {/* Action Buttons */}
                <td className="py-3.5 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                  <div className="flex items-center justify-end gap-1.5">
                    {/* View Details */}
                    <button
                      onClick={() => onSelectDocument(doc)}
                      title="Inspect Document Details"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {/* Download (If authorized) */}
                    {doc.userAccess !== 'admin_meta' && (
                      <button
                        onClick={() => onDownload(doc)}
                        title="Download Document"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    )}

                    {/* Manage Access (Owner only) */}
                    {doc.userAccess === 'owner' && onManageAccess && (
                      <button
                        onClick={() => onManageAccess(doc)}
                        title="Manage Document Permissions"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-slate-800 transition-colors"
                      >
                        <Share2 className="w-4 h-4" />
                      </button>
                    )}

                    {/* Soft Delete or Restore */}
                    {isTrashView && onRestore && doc.userAccess === 'owner' ? (
                      <button
                        onClick={() => onRestore(doc)}
                        title="Restore Document"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition-colors"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    ) : (
                      doc.userAccess === 'owner' &&
                      onDelete && (
                        <button
                          onClick={() => onDelete(doc)}
                          title="Move to Trash"
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
