/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        vault: {
          bg: '#080C16',
          card: '#0E1729',
          surface: '#131F38',
          hover: '#192849',
          border: '#1E2D4A',
          borderLight: '#283B60',
          muted: '#64748B',
          text: '#F1F5F9',
        },
        cyanAccent: {
          DEFAULT: '#00F2FE',
          dim: '#06B6D4',
          glow: 'rgba(0, 242, 254, 0.15)',
        },
        tealAccent: {
          DEFAULT: '#0EA5E9',
          light: '#38BDF8',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'Courier New', 'monospace'],
      },
      boxShadow: {
        'vault-sm': '0 2px 8px -2px rgba(0, 0, 0, 0.5), 0 1px 4px -1px rgba(0, 242, 254, 0.05)',
        'vault-md': '0 8px 24px -4px rgba(0, 0, 0, 0.6), 0 2px 8px -2px rgba(0, 242, 254, 0.08)',
        'vault-glow': '0 0 20px -3px rgba(0, 242, 254, 0.25)',
      },
    },
  },
  plugins: [],
};
